<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();

$Markid = $_GET['mark_id'];
$res = $admin->get_allMarks($Markid);

?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/form-bootstrap-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:06 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>MNTC || Edit Marks</title>
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">

    <!-- sweet alert starts -->
    <link href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    
    <link href="bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!-- <link href="select2.min.css" rel="stylesheet" type="text/css" media="all" /> -->

    <link href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css" rel="stylesheet" />

    <style>
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
    background-color: #e4e4e4;
    border: 1px solid #aaa;
    border-radius: 4px;
    cursor: default;
    float: left;
    margin-right: 5px;
    margin-top: 5px;
    padding: 0 5px;
    color: black;
}
    </style>


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
   
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Edit Marks</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                           
                            <button type="button" id='btnViewMarks' class="btn btn-info d-none d-lg-block m-l-15"> View Marks</button>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                
                                <form class="needs-validation" method='POST' action='controller/marks_controller.php' novalidate>                                    
                                    <div class="form-row">                                        
                                        <div class="col-md-4 mb-3" id='normalSubDiv'>
                                            <label for="validationCustom04">Course</label>
                                            <select name="course1" id="course" class='form-control'>
                                                    <option value="" selected disabled>SELECT COURSE</option>                                                  
                                                    <?php
                                                        $stmt = $admin->get_course();
                                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { 
                                                            if($row["KeyCode"] == $res['CourseKeyCode'])  
                                                            {  
                                                                                                                     
                                                    ?>
                                                     <option value='<?php echo $row["KeyCode"] ?>' selected > <?php echo $row["CourseName"] ?> </option>
                                                     <?php }  else { ?> 
                                                        <option value='<?php echo $row["KeyCode"] ?>' > <?php echo $row["CourseName"] ?> </option>
                                                     <?php } } ?>
                                                </select>
                                            <div class="invalid-feedback">
                                                Please Select Course Name.
                                            </div>                                           
                                        </div>

                                        <div class="col-md-4 mb-3" id='BatchDiv' >
                                            <label for="validationCustom04">Batch Name</label>
                                            <select name="batch1" id="batch_select" class='form-control' required>   
                                            <option value="" selected disabled>SELECT BATCH</option>                        
                                                    <?php
                                                        $courseID= $res['CourseKeyCode'];
                                                        $stmt = $admin->get_batchID($courseID);
                                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { 
                                                            if($row["KeyCode"] == $res['BatchKeyCode'])  
                                                            {                                                                                                                       
                                                    ?>
                                                     <option value='<?php echo $row["KeyCode"] ?>' selected > <?php echo $row["BatchName"] ?> </option>
                                                     <?php }  else { ?> 
                                                        <option value='<?php echo $row["KeyCode"] ?>' > <?php echo $row["BatchName"] ?> </option>
                                                     <?php } } ?>
                                                </select>
                                            <div class="invalid-feedback">
                                                Please Select Batch Name.
                                            </div>                                           
                                        </div> 
                                        <div class="col-md-4 mb-3" id='StudentDiv' >
                                            <label for="validationCustom04">Student Name</label>
                                            <select name="student1" id="student_select" class='form-control' required>                                               
                                            <option value="" selected disabled>SELECT STUDENT</option>
                                                    <?php
                                                        $batchID= $res['BatchKeyCode'];
                                                        $stmt = $admin->get_student_ID($batchID);
                                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { 
                                                            if($row["KeyCode"] == $res['StudentKeyCode'])  
                                                            {                                                                                                                       
                                                    ?>
                                                     <option value='<?php echo $row["KeyCode"] ?>' selected > <?php echo $row["StudentName"] ?> </option>
                                                     <?php }  else { ?> 
                                                        <option value='<?php echo $row["KeyCode"] ?>' > <?php echo $row["StudentName"] ?> </option>
                                                     <?php } } ?>
                                                </select>
                                            <div class="invalid-feedback">
                                                Please Select Student Name.
                                            </div>                                           
                                        </div>                                                                              
                                    </div>
                                    <div class="form-row">
                                    <div class="col-md-6 mb-3" id='SubjectDiv' >
                                            <label for="validationCustom04">Subject Name</label>
                                            <select name="subject1" id="subject" class='form-control' required>   
                                            <option value="" selected disabled>SELECT SUBJECT</option>
                                                    <?php
                                                      /*  $studentID= $res['StudentKeyCode'];
                                                        $stmt = $admin->get_corse_ID($studentID);
                                                        $Course_key=$stmt['CourseKeyCode'];
                                                        $stmt1 = $admin->get_sub_ID($Course_key);
                                                        while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
                                                        $subarray =explode(',',$row['SubjectKeyCode']);
                                                        foreach($subarray as $s)
                                                        {
                                                            $stmt2 = $admin->get_sub_name($s);
                                                            while ($row = $stmt2->fetch(PDO::FETCH_ASSOC)) { 
                                                            if($row["KeyCode"] == $res['SubjectKeyCode'])  
                                                            {                                                                                                                       
                                                    ?>
                                                     <option value='<?php echo $row["KeyCode"] ?>' selected > <?php echo $row["SubjectName"] ?> </option>
                                                     <?php }  else { ?> 
                                                        <option value='<?php echo $row["KeyCode"] ?>' > <?php echo $row["SubjectName"] ?> </option>
                                                     <?php } } }}*/
                                                     //$Course_key = $_POST['get_sub'];  
                                                      
                                                      $stmt1 = $admin->get_sub_ID($res['CourseKeyCode']);
                                                      while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
                                                          $subarray =explode(',',$row['SubjectKeyCode']);
                                                          foreach($subarray as $s)
                                                          {
                                                                $stmt2 = $admin->get_sub_name($s);
                                                                while ($row1 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                                                                    if($row1["KeyCode"] == $res['SubjectKeyCode'])  
                                                            {                                                                                                                       
                                                    ?>
                                                     <option value='<?php echo $row1["KeyCode"] ?>' selected > <?php echo $row1["SubjectName"] ?> </option>
                                                     <?php }  else { ?> 
                                                        <option value='<?php echo $row1["KeyCode"] ?>' > <?php echo $row1["SubjectName"] ?> </option>
                                                     <?php }
                                                                      
                                                                 }
                                                          }     
                                                    }?>
                                                </select>
                                            <div class="invalid-feedback">
                                                Please Select Subject Name.
                                            </div>                                           
                                        </div>   
                                        <div class="col-md-6 mb-3">
                                            <label for="validationCustom01">Mark</label>
                                            <input type="text" class="form-control" id='mark' name="std_mark1" placeholder="Mark"  required autocomplete='off' value=<?php echo $res["Mark"] ?>>
                                            <input type="hidden" class="form-control" id='mark' name="mark_keycode" placeholder="Mark"  required autocomplete='off' value=<?php echo $res["KeyCode"] ?>>
                                            <div class="invalid-feedback">
                                                Please Enter the student Mark.
                                            </div>
                                        </div>                                       
                                    </div>                                   
                                    <button class="btn btn-primary" name='edit_mark' type="submit">Update</button>
                                </form>
                                <script>
                                // Example starter JavaScript for disabling form submissions if there are invalid fields
                                (function() {
                                    'use strict';
                                    window.addEventListener('load', function() {
                                        // Fetch all the forms we want to apply custom Bootstrap validation styles to
                                        var forms = document.getElementsByClassName('needs-validation');
                                        // Loop over them and prevent submission
                                        var validation = Array.prototype.filter.call(forms, function(form) {
                                            form.addEventListener('submit', function(event) {
                                                if (form.checkValidity() === false) {
                                                    event.preventDefault();
                                                    event.stopPropagation();
                                                }
                                                form.classList.add('was-validated');
                                            }, false);
                                        });
                                    }, false);
                                })();
                                </script>
                            </div>
                        </div>
                    </div>                    
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>

    <!-- Sweet-Alert starts  -->
    <script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <script src="assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
    <!-- sweet alert ends -->

    
                            <script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js"></script>

  
<!-- 
    <script type="text/javascript" src='select2.min.js'></script> 
    <script src="bootstrap.min.js"></script> -->

    <?php $control->sessionMessage(); ?>

    <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
    </script>

    <script>
        $(document).ready(function(){

            //course changes
            $('#course').change( function(){
            var course =$(this).val();
            $('#batch_select').empty();
            //alert(course);
                $.ajax({
                    url: "controller/marks_controller.php",
                    type: "POST", //send it through get method
                    data: {course_selected: course},                    
                    success: function(response) {
                    $('#batch_select').append('<option value="" selected disabled>SELECT BATCH</option>');
                    $('#batch_select').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                });
            })

            //batch changes
            $('#batch_select').change( function(){
            var batch =$(this).val();
            $('#student_select').empty();
            //alert(batch);
                $.ajax({
                    url: "controller/marks_controller.php",
                    type: "POST", //send it through get method
                    data: {batch_selected: batch},
                    
                    success: function(response) {
                    $('#student_select').append('<option value="" selected disabled>SELECT STUDENT</option>');
                    $('#student_select').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                });
            })

            //student changes
            $('#student_select').change( function(){
             var course =$('#course').val();
            $('#subject').empty();
            //alert(student);
                // $.ajax({
                //     url: "controller/marks_controller.php",
                //     type: "POST", //send it through get method
                //     data: {student_selected: student},
                    
                //     success: function(response) {
                //     $('#subject').append('<option value="" selected disabled>SELECT SUBJECT</option>');
                //     $('#subject').append(response);
                //     //Do Something
                //     },
                //     error: function(result) {                     
                //         //Do Something to handle error
                //     }
                // });
                $.ajax({
                    url: "controller/marks_controller.php",
                    type: "POST", //send it through get method
                    data: {get_sub: course},
                    
                    success: function(response) {
                    $('#subject').append('<option value="" selected disabled>-- SELECT SUBJECT --</option>');
                    $('#subject').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                });

            })

            $('#btnViewMarks').click(function(){
                window.open('ViewMarks.php','_self'); 
            })            
            
        }) //Doc End
    </script>
</body>


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/form-bootstrap-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:06 GMT -->
</html>