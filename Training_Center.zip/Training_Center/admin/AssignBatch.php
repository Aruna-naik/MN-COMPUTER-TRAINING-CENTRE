<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();

?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/table-data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:23 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>MNTC || Assign Batch</title>
    <!-- This Page CSS -->
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <link href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
   
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Assign Batch</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            
                           
                            <button type="button" id="addnew" class="btn btn-info d-none d-lg-block m-l-15" data-toggle="modal" data-target="#exampleModal" data-whatever="@fat">
                                <i class="fa fa-plus-circle"></i> Create New</button>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><!--Data Export--></h4>
                                <h6 class="card-subtitle"><!--Export data to Copy, CSV, Excel, PDF & Print--></h6>
                                <div class="table-responsive m-t-40">
                                    <table id="example23"
                                        class="display nowrap table table-hover table-striped table-bordered"
                                        cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                            <th>Sl No</th>
                                                <th>Course Name</th>
                                                <th>Course Code</th>
                                                <th>Batch</th>
                                                <th>Action</th>
                                                <th style='display:none;'>Action</th>
                                                <th style='display:none;'>Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                 <th>Sl No</th>
                                                <th>Course Name</th>
                                                <th>Course Code</th>
                                                <th>Batch</th>
                                                <th>Action</th>
                                                <th style='display:none;'>Action</th>
                                                <th style='display:none;'>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        <?php $i=1;
                                                $stmt1 = $admin->get_all_batch();
                                                while ($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)) {
                                                    ?>
                                            <tr>
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo $row1['CourseName'] ?></td>
                                            <td><?php echo $row1['CourseCode'] ?></td>
                                            <td><?php echo $row1['BatchName'] ?></td>
                                            <td>  
                                            <a title="Update" class="btn btn-info edit"><i class="fa fa-edit" id= style='color:white;'></i></a> 
                                                <a href="controller/batch_controller.php?Batchiddelete=<?php echo $row1['KeyCode'] ?>" title="Delete" onclick="return confirm('Are you Sure want to Delete the Subject'); " class="btn btn-warning"><i class="fa fa-trash"></i></a></td>
                                            <td style='display:none;'><?php echo $row1['KeyCode']; ?></td>
                                            <td style='display:none;'><?php echo $row1['CourseKeyCode']; ?></td>
                                            </tr>
                                      <?php } ?>
                                            <?php ?>
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    
                       
                        <!-- table responsive -->
                        <!--model -->
                        <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                        <form class="needs-validation" novalidate method='POST' id="assignbatch" action="controller/batch_controller.php">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="exampleModalLabel1">Assign Batch </h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            </div>
                                            <div class="modal-body">
                                           
                                    <div class="form-row">
                                        <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Select Course</label>
                                            <select class="form-control" id="addCOURSE" placeholder="Select Course" name="addCOURSE" required>
                                            <option value="" selected disabled>---SELECT COURSE--</option>
                                            <?php
                                                $stmt = $admin->get_course();
                                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                    ?>
                                            <option value="<?php echo $row['KeyCode'] ?>"><?php echo  $row['CourseName'] ?></option>
                                      <?php } ?>
                                            <?php ?>
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a course.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                    <div class="col-md-12 mb-12">
                                            <label for="validationCustom03">Course Code</label>
                                            <input type="text" class="form-control" id="Course_Code" placeholder="Course Code" required readonly>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide a valid city.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Batch</label>
                                            <select class="form-control" id="batch" placeholder="Select batch" name="addBATCH" required>
                                            <option value="" selected disabled>---SELECT BATCH--</option>
                                            <option value="A">A</option>
                                            <option value="B">B</option>
                                            <option value="C">C</option>
                                            <option value="D">D</option>
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a username.
                                            </div>
                                        </div>
                                    </div>

                                
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                               
                                                <button class="btn btn-primary" type="submit"name="addassignbatch">Submit form</button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>

                                <div class="modal" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                        <form class="needs-validation" novalidate method='POST' id="assignbatch" action="controller/batch_controller.php">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="exampleModalLabel1">Assign Batch </h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            </div>
                                            <div class="modal-body">
                                           
                                    <div class="form-row">
                                        <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Select Course</label>
                                            <select class="form-control" id="editCOURSE" placeholder="Select Course" name="editCOURSE" required>
                                            <option value="" selected disabled>---SELECT COURSE--</option>
                                            <?php
                                                $stmt = $admin->get_course();
                                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                    ?>
                                            <option value="<?php echo $row['KeyCode'] ?>"><?php echo  $row['CourseName'] ?></option>
                                      <?php } ?>
                                            <?php ?>
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a course.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                    <div class="col-md-12 mb-12">
                                            <label for="validationCustom03">Course Code</label>
                                            <input type="text" class="form-control" id="editCourse_Code" placeholder="Course Code" required readonly>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide a valid city.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Batch</label>
                                            <select class="form-control" id="editbatch" placeholder="Select batch" name="editBATCH" required>
                                            <option value="" selected disabled>---SELECT BATCH--</option>
                                            <option value="A">A</option>
                                            <option value="B">B</option>
                                            <option value="C">C</option>
                                            <option value="D">D</option>
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a username.
                                            </div>
                                        </div>
                                    </div>

                                    <input type="hidden" id="editKey" name="editKey" >

                                    
                                
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                               
                                                <button class="btn btn-primary" type="submit"name="editassignbatch" name="editassignbatch">Submit form</button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                         <!--model -->
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
               
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
    <!--This page plugins -->
    <script src="assets/node_modules/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="assets/node_modules/datatables.net-bs4/js/dataTables.responsive.min.js"></script>
    <!-- start - This is for export functionality only -->
    <script src="cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
    <!-- end - This is for export functionality only -->

    <!-- Sweet-Alert starts  -->
    <script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <script src="assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
    <!-- sweet alert ends -->
    <script>
        $(function () {
            $('#myTable').DataTable();
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function (settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;
                    api.column(2, {
                        page: 'current'
                    }).data().each(function (group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group + '</td></tr>');
                            last = group;
                        }
                    });
                }
            });
            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function () {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
            // responsive table
            $('#config-table').DataTable({
                responsive: true
            });
            $('#example23').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel').addClass('btn btn-primary mr-1');
        });

        (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
    
    $('#addCOURSE').change( function(){
        var course =$(this).val();
        $.ajax({
  url: "controller/batch_controller.php",
  type: "POST", //send it through get method
  data: { 
    course: course, 
  },
  success: function(response) {
     // alert(response);
      $('#Course_Code').val(response)
    //Do Something
  },
  error: function(xhr) {
    //Do Something to handle error
  }
});
    })

    $('#editCOURSE').change( function(){
        var course =$(this).val();
        $.ajax({
  url: "controller/batch_controller.php",
  type: "POST", //send it through get method
  data: { 
    course: course, 
  },
  success: function(response) {
     // alert(response);
       $('#editCourse_Code').val(response);
    //Do Something
  },
  error: function(xhr) {
    //Do Something to handle error
  }
});
    })

    $('#addnew').click( function(){
        $('#Course_Code').val('')
        $('#Course_Code').val('')
        $('#Course_Code').val('')

    })

    $('#example23 tbody tr').on('click','td:nth-child(5) .edit',function(){
               var Keycode=$(this).parent().parent().find('td:nth-child(6)').text();
               var code=$(this).parent().parent().find('td:nth-child(3)').text();
               var key=$(this).parent().parent().find('td:nth-child(7)').text();
               var batch=$(this).parent().parent().find('td:nth-child(4)').text();
               $('#editCOURSE').val(key);
                $('#editCourse_Code').val(code);
                $('#editbatch').val(batch);
               $('#editKey').val(Keycode);
                $('#exampleModal1').modal('show');
            });


    </script>
    <?php $control->sessionMessage(); ?>
</body>


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/table-data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:33 GMT -->
</html>