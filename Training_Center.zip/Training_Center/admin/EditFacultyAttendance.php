<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();

?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/table-data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:23 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>MNTC || Attendence</title>
    <!-- This Page CSS -->
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <link href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style type="text/css">
    .switch {
  position: relative;
  display: inline-block;
  width: 110px;
  height: 34px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ca2222;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2ab934;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(55px);
  -ms-transform: translateX(75px);
  transform: translateX(75px);
}

/*------ ADDED CSS ---------*/
.on
{
  display: none;
}

.on, .off
{
  color: white;
  position: absolute;
  transform: translate(-50%,-50%);
  top: 50%;
  left: 50%;
  font-size: 10px;
  font-family: Verdana, sans-serif;
}

input:checked+ .slider .on
{display: block;}

input:checked + .slider .off
{display: none;}

/*--------- END --------*/

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;}

  input:checked + .slider:before {
    -webkit-transform: translateX(55px);
    -ms-transform: translateX(75px);
    transform: translateX(75px);
    border-radius: 54px;
}
   .slider:before {
    
    border-radius: 54px;
}

.slider{
    border-radius: 54px;
}

  </style>

</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
   
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">View Attendence</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            
                           
                              <a href="ViewStudentAttendence.php"><button type="button" id="view attendance" class="btn btn-info d-none d-lg-block m-l-15" data-toggle="modal" data-target="" data-whatever="@fat">
                                <i class="fa fa-plus-circle"></i> View Attendence</button></a>
                            <a href="EditAttendance.php"><button type="button"  class="btn btn-info d-none d-lg-block m-l-15" data-toggle="modal" data-target="" data-whatever="@fat">
                                <i class="fa fa-plus-circle"></i> Edit Attendence</button></a>
                            <a href="AddAttendance.php"><button type="button"  class="btn btn-info d-none d-lg-block m-l-15" data-toggle="modal" data-target="" data-whatever="@fat">
                                <i class="fa fa-plus-circle"></i> Edit Attendence</button></a>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                 <?php include "EditAttendanceModel.php"; ?>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                               <!--<form>
                                 <div class="form-row">
                                        <div class="col-md-2 mb-12">
                                            <label for="validationCustom01">Select Course</label>
                                            <select class="form-control gettime hidetable" id="course" placeholder="Select course" name="addCOURSE" required>
                                            <option value="" selected disabled>---SELECT COURSE--</option>
                                            <?php
                                                $stmt = $admin->get_course();
                                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                    ?>
                                            <option value="<?php echo $row['KeyCode'] ?>"><?php echo  $row['CourseName'] ?></option>
                                      <?php } ?>
                                            <?php ?>
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a course.
                                            </div>
                                        </div>

                                        <div class="col-md-2 mb-12">
                                            <label for="validationCustom01">Batch</label>
                                            <select class="form-control gettime hidetable" id="batch" placeholder="Select batch" name="batch" required>
                                           
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a Batch.
                                            </div>
                                        </div>
                                        <div class="col-md-2 mb-12"  >
                                            <label for="validationCustom01">Subject Name</label>
                                            <select name="subject " id="subject" class='form-control gettime hidetable' required placeholder="Select subject">                                               
                                           
                                                </select>
                                                 <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please Select Subject Name.
                                            </div>                                           
                                        </div>

                                         <div class="col-md-2 mb-12"  >
                                            <label for="validationCustom04">Date</label>
                                             <input type="date" class="form-control gettime hidetable" id='attendancedate' name="attendancedate"  required>
                                                 <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please Select Subject Name.
                                            </div>                                           
                                        </div>

                                        <div class="col-md-2 mb-12" id='SubjectDiv' >
                                            <label for="validationCustom04">Time</label>
                                            <select name="time" id="time" class='form-control hidetable' required>                                               
                                           
                                                </select>
                                                 <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please Select Subject Name.
                                            </div>                                           
                                        </div>

                                         <div class="col-md-2 mb-12">
                                            <label for="validationCustom01"><br></label>
                                        <button type="button" id="search" class="btn btn-info d-none d-lg-block m-l-15" >
                                <i class="fa fa-plus-circle"></i> Search</button>
                                        </div>

                                    </div>

                                </form> -->
                                <?php if(isset($_POST['filterAtt']))

                          {
                             $Course_key=$_POST['course'];
                             $Batch_key=$_POST['batch']; 
                             $Subject_key=$_POST['subject']; 
                             
                             $attendancedate=$_POST['attendancedate']; 
                              $Time_key=$_POST['time']; 
                             ?>
                                <form class="needs-validation" method='POST' action='controller/attendance_controler.php' novalidate>
                                  <div class="form-row">
                                    <div class="col-md-2 mb-12"  >
                                            <label for="validationCustom04">Course</label>
                                            <?php $stmt7 = $admin->getCourseID($Course_key)?>
                                             <input type="text" class="form-control gettime hidetable" id='course_name' name="course_name"  readonly value="<?php echo $stmt7['CourseName']; ?>">
                                                                                           
                                        </div>
                                        <div class="col-md-2 mb-12"  >
                                          <?php $stmt2 = $admin->get_coursebatch($Batch_key)?>
                                          
                                            <label for="validationCustom04">Batch</label>
                                             <input type="text" class="form-control gettime hidetable" id='batch_name' name="batch_name" value="<?php echo $stmt2['BatchName']; ?>" readonly>
                                                                                           
                                        </div>
                                        <div class="col-md-2 mb-12"  >
                                          <?php $stmt3 = $admin-> get_subjectID($Subject_key)?>
                                            <label for="validationCustom04">Subject Name</label>
                                             <input type="text" class="form-control gettime hidetable" id='subject_name' name="subject_name" value="<?php echo $stmt3['SubjectName']; ?>" readonly>
                                                                                           
                                        </div>
                                        <div class="col-md-2 mb-12"  >
                                            <label for="validationCustom04">Date</label>
                                             <input type="text" class="form-control gettime hidetable" id='at_date' name="at_date" value="<?php echo $attendancedate; ?>"  readonly>
                                                                                           
                                        </div>
                                        <div class="col-md-2 mb-12"  >
                                          <?php $stmt4 = $admin-> get_course_time_id_S($Time_key)?>
                                            <label for="validationCustom04">Time</label>
                                             <input type="text" class="form-control gettime hidetable" id='at_time' name="at_time" value="<?php echo $stmt4['ST'].' TO '.$stmt4['ET']; ?>"  readonly>
                                                                                           
                                        </div>
                                    
                                  </div>
                                    <div class="form-row" id="tblhed" >
                                         <div class="col-md-12 mb-12" style="padding-top: 13px;" >
                                    <a  class="btn btn-info btn-block" style="border-radius: 20px;" onclick="fn3();">Select/Deselect all</a ></div></div>
                                <h4 class="card-title"><!--Data Export--></h4>
                                <h6 class="card-subtitle"><!--Export data to Copy, CSV, Excel, PDF & Print--></h6>
                                <div class="table-responsive m-t-40">
                                    
                                    <table id="example23"
                                        class="display nowrap table table-hover table-striped table-bordered"
                                        cellspacing="0" width="100%" >
                                        <thead >
                                            <tr>
                                             <th>Sl No</th>
                                                <th> Register No</th>
                                                <th>Name</th>
                                                
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <tfoot>
                                            <tr>
                                                 <th>Sl No</th>
                                                <th> Register No</th>
                                                <th>Name</th>
                                                
                                                <th>Action</th>
                                               
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                          <?php 
                                          $stmt5 = $admin->get_student_attendence_ById($Batch_key,$Subject_key,$attendancedate,$Time_key);
                                          $i=0;
                                          while ($row1 = $stmt5->fetch(PDO::FETCH_ASSOC)) {
                                            ?>
                                            <tr>
                                                 <td><?php echo ++$i ?><?php echo $row1['KeyCode']; ?>
                                                    <input type="hidden" name="StudentKeyCodeID[]" value="<?php echo $row1['KeyCode']; ?>" >
                                                 </td>
                                               
                                                <td><?php echo $row1['RegisterNo']; ?>
                                                  <input type="hidden" name="reg_number[]" value="<?php echo $row1['RegisterNo']; ?>" > 
                                                </td>
                                                 <td><?php echo $row1['StudentName']; ?>
                                                  <input type="hidden" name="cand_name[]" value="<?php echo $row1['StudentName'] ?>" >
                                                </td>
                                               
                                                <td>
                                                  <?php
                                                   if($row1['Status']=="Present"){
                                                    ?>
                                                    <label class="switch"><input type="checkbox" value='<?php echo $row1['KeyCode']; ?>'  checked name="attendance_status[]"  id="togBtn" class="togBtn"><div class="slider"><span class="on">Prasant</span><span class="off">Absant</span></div></label>
                                                  <?php }else{
                                                      ?>
                                                          <label class="switch"><input type="checkbox" name="attendance_status[]" value='<?php echo $row1['KeyCode']; ?>' id="togBtn" class="togBtn"><div class="slider"><span class="on">Present</span><span class="off">Absent</span></div></label>
                                                      <?php
                                                  } ?>
                                                 <!--  <label class="switch"><input type="checkbox" name="attendance_status[]"  id="togBtn" class="togBtn"><div class="slider"><span class="on">Prasant</span><span class="off">Absant</span></div></label> -->
                                                </td>
                                               
                                            </tr>

                                          <?php }
                                          
                                          ?>
                                          
                                           
                                        </tbody>
                                    </table>
                                 
                                </div>
                                <input type="submit" class="btn" style="background-color:#17c4bb;color:white;" name="EditAttendance_btton" value="Apply" id="EditAttendance_btton" />
                                </form>
                              <?php
                               echo '<input type="text" id="txtdata" value="data" style="display:none;">'; }?>
                            </div>
                        </div>
                    
                       
                        <!-- table responsive -->
                        <!--model -->
                        

                                
                         <!--model -->
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
               
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
    <!--This page plugins -->
    <script src="assets/node_modules/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="assets/node_modules/datatables.net-bs4/js/dataTables.responsive.min.js"></script>
    <!-- start - This is for export functionality only -->
    <script src="cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
    <!-- end - This is for export functionality only -->

    <!-- Sweet-Alert starts  -->
    <script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <script src="assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
    <!-- sweet alert ends -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js'></script>
    <script>
        $(function () {
            $('#myTable').DataTable();
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function (settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;
                    api.column(2, {
                        page: 'current'
                    }).data().each(function (group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group + '</td></tr>');
                            last = group;
                        }
                    });
                }
            });
            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function () {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
            // responsive table
            $('#config-table').DataTable({
                responsive: true
            });
          /* $('#example23').DataTable({
                dom: 'Bfrtip'
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });*/
            $('.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel').addClass('btn btn-primary mr-1');
        });

        (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();


    

     $('#course').change( function(){
            var course =$(this).val();
            //alert(batch);
                $.ajax({
                    url: "controller/attendance_controler.php",
                    type: "POST", //send it through get method
                    data: {select_course: course},
                    
                    success: function(response) {
                    $('#batch').html('');
                    $('#batch').append(response);
                  /*   $('#example23').hide();
                     $('#tblhed').hide();
                     $('#saveAssign').hide();*/
                    //Do Something
                    },
                    error: function(result) {
                    alert(result);                     
                        //Do Something to handle error
                    }
                });

            })

      $('#batch').change( function(){
         
                     /*$('#example23').hide();
                     $('#tblhed').hide();
                    $('#saveAssign').hide();*/
                     

                     var course =$('#course').val();
                    // alert(course);
            $('#subject').empty();
            //alert(student);
                $.ajax({
                    url: "controller/attendance_controler.php",
                    type: "POST", //send it through get method
                    data: {select_batch: course},
                    
                    success: function(response) {
                    $('#subject').append('<option value="" selected disabled>-- SELECT SUBJECT --</option>');
                    $('#subject').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                });


                    //Do Something
                 

            })

      $('.gettime').change( function(){
            var attendancedate =$('#attendancedate').val();
            var batch =$('#batch').val();
            var subject =$('#subject').val();
        
            if(attendancedate!="" && batch!="" && subject!=""){
            var day=moment(attendancedate).format("dddd");

               
                $.ajax({
                    url: "controller/attendance_controler.php",
                    type: "POST", //send it through get method
                    data: {attendancedateedit: day,selected_day_batch: batch,selected_subject: subject,Adate: attendancedate},
                    
                    success: function(response) {
                   $('#time').empty();
                  // alert(day);
                  
                    $('#time').append(response);
                     
                    //Do Something
                    },
                    error: function(result) {
                    alert(result);                     
                        //Do Something to handle error
                    }
                });
            }


            })

      /* $('#batch').change( function(){
            var student =$(this).val();
            $('#subject').empty();
            //alert(student);
                $.ajax({
                    url: "controller/marks_controller.php",
                    type: "POST", //send it through get method
                    data: {student_selected: student},
                    
                    success: function(response) {
                    $('#subject').append('<option value="" selected disabled>-- SELECT SUBJECT --</option>');
                    $('#subject').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                });
            })*/



      $('#search').click( function(){
      
         //var course =$('#course').val();
         var batch =$('#batch').val();
         var course =$('#course').val();
         var subject =$('#subject').val();
         var time =$('#time').val();
         var attendancedate =$('#attendancedate').val();
         if(batch!='' && course!='' && subject!='' && time!='' && attendancedate!='')
         {
        $('#example23').show();
         $('#example23 tbody').html('');
        $('#tblhed').show();
        $('#saveAssign').show();
        $.ajax({
                    url: "controller/attendance_controler.php",
                    type: "POST", //send it through get method
                    data: {selrcted_batch: batch},
                    
                    success: function(response) {
                      
                        $('#tblhed tbody').html('');
                    
                   // $('#batch').append(response);
                     
                     $('#example23 tbody').append(response)
                    //Do Something
                    },
                    error: function(result) {
                    alert('result');                     
                        //Do Something to handle error
                    }
                });
    }else{
        alert("file all info")
    }
       /* $('#Course_Code').val('')
        $('#Course_Code').val('')*/



    })

      var fn3 = (function() {
    var first = true;
    return function() {
      first ? handleChange1() : handleChange2();
      first = !first;
    }
  })();
  
  function handleChange1() 
  {
    var allCB = document.querySelectorAll("input[id='togBtn']");
    for(var i=0; i< allCB.length; i++){
      allCB[i].checked=true;
    }
  }

    function handleChange2() 
    {
    var allCB = document.querySelectorAll("input[id='togBtn']");
    for(var i=0; i< allCB.length; i++){
      allCB[i].checked=false;
    }
}




  $('.hidetable').change( function(){
            
        $('#example23').hide();
                     $('#tblhed').hide();
                     $('#saveAssign').hide();

            })

  $('#saveAssign').click(function (){
    var tbllength=$('#example23 tbody').find('tr').length;
    var std_key = [];
    var status=[];
    var course =$('#course').val();
    var batch =$('#batch').val();
    var subject =$('#subject').val();
    var time =$('#time').val();
    var attendancedate_at =$('#attendancedate').val();

    for(i=0;i<tbllength;i++)
    {
        
        std_key.push($('#example23 tbody').find('tr:eq('+i+')').find('td:nth-child(1)').text());
        //status.push( $('#example23 tbody').find('tr:eq('+i+')').find('td:nth-child(5) input').prop('checked'));
        if($('#example23 tbody').find('tr:eq('+i+')').find('td:nth-child(5) input').prop('checked')){
            status.push('Present');
        
        }else{
            status.push('Absent');
        }
   // alert($('#example23 tbody').find('tr:eq('+i+')').find('td:nth-child(5) input').text())
       //var std_key= ;
       //var status= $('#example23 tbody').find('tr:eq('+i+')').find('td:nth-child(5) input').prop('checked');

    }


    $.ajax({
                    url: "controller/attendance_controler.php",
                    type: "POST", //send it through get method
                    data: {std_key: std_key,status: status,course: course,batch: batch,subject: subject,time: time,attendancedate_at: attendancedate_at},
                    
                    success: function(response) {
                        alert(response);
                      
                       /* $('#tblhed tbody').html('');
                    $('#batch').html('');
                    $('#batch').append(response);
                     
                     $('#example23 tbody').append(response)*/
                    //Do Something
                   },
                    error: function(result) {
                    alert('result');                     
                        //Do Something to handle error
                    }
                });
})

  $(document).ready(function(){ 

          var str = $("#txtdata").val();
          //alert(str);
          if(str == undefined){
           
            $('#myModal').modal({backdrop: 'static', keyboard: false});
          }else{
            $('#myModal').modal("hide"); //Open Modal
          }

          $('#edit').click( function(){
         
            $('#myModal').modal({backdrop: 'static', keyboard: false});
        
          });
        }); 

    </script>
    <?php $control->sessionMessage(); ?>
</body>


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/table-data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:33 GMT -->
</html>