<!-- Modal content-->
    <!-- Modal -->
    <?php date_default_timezone_set('Asia/Calcutta'); ?>
    <div class="modal fade bs-modal-sm" id="myModal" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm">                         
        <!-- Modal content-->
            <div class="modal-content">
                <form method="POST" action="">
                    <div class="modal-header">
                    <!--  <button type="button" class="close" data-dismiss="modal">&times;</button>-->
                        <h4 class="modal-title">Edit Attendance </h4>
                    </div>
                                        
                    <div class="modal-body" id="refmodel">                                      
                        <div class="row">
                            <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Select Course</label>
                                            <select class="form-control gettime hidetable" id="course" placeholder="Select course" name="course" required>
                                            <option value="" selected disabled>---SELECT COURSE--</option>
                                            <?php
                                                $stmt = $admin->get_course();
                                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                    ?>
                                            <option value="<?php echo $row['KeyCode'] ?>"><?php echo  $row['CourseName'] ?></option>
                                      <?php } ?>

                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a course.
                                            </div>
                                        </div>  
                                        <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Batch</label>
                                            <select class="form-control gettime hidetable" id="batch" placeholder="Select batch" name="batch" required>
                                           <!-- <option value="" selected disabled>---SELECT BATCH--</option>
                                            <option value="A">A</option>
                                            <option value="B">B</option>
                                            <option value="C">C</option>
                                            <option value="D">D</option>-->
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a Batch.
                                            </div>
                                        </div>  

                                        <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Subject Name</label>
                                            <select class="form-control gettime hidetable" id="subject" placeholder="Select batch" name="subject" required>
                                           <!-- <option value="" selected disabled>---SELECT BATCH--</option>
                                            <option value="A">A</option>
                                            <option value="B">B</option>
                                            <option value="C">C</option>
                                            <option value="D">D</option>-->
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a Batch.
                                            </div>
                                        </div>  


                                         <!-- <div class="col-md-12 mb-12"  >
                                            <label for="validationCustom01">Subject Name</label>
                                            <select  class="form-control gettime hidetable" id="subject" required placeholder="Select subject" name="sub">
                                            	
                                            </select>
                                                 <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please Select Subject Name.
                                            </div>                                           
                                        </div>   --> 
                                        <div class="col-md-12 mb-12"  >
                                            <label for="validationCustom04">Date</label>
                                             <input type="date" class="form-control gettime hidetable" id='attendancedate' name="attendancedate"  required>
                                                 <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please Select Subject Name.
                                            </div>                                           
                                        </div>

                                        <div class="col-md-12 mb-12" id='SubjectDiv' >
                                            <label for="validationCustom04">Time</label>
                                            <select name="time" id="time" class='form-control hidetable' required>                                               
                                           
                                                </select>
                                                 <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please Select Subject Name.
                                            </div>                                           
                                        </div>                               
                        </div>
                    </div>
                    <div class="modal-footer">                            
                        <input type="submit" class="btn" style="background-color:#17c4bb;color:white;" name="filterAtt" value="Apply" id="filterAtt" />
                        <button type="button" class="btn" style="background-color:#17c4bb;color:white;" data-dismiss="modal">Close</button> 
                    </div>
                </form>
            </div>                        
        </div>
        <!-- End Model Content-->
        <!-- END CONTENT -->
    </div>
<!-- END CONTENT -->