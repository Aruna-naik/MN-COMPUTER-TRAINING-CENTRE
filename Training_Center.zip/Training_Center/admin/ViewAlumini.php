<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();
?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/table-data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:23 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>MNTC || View Alumini</title>
    <!-- This Page CSS -->
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- sweet alert starts -->
    <link href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- sweet alert ends -->

    <style>
        .table td, .table th {
    padding: 0.5rem;
    vertical-align: top;
    border-top: 1px solid #e9ecef;
}
    </style>
</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">View Alumini Student</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            
                           
                      <a href="Report.php"> <button type="button" class="btn btn-info">Add Student To Alumini</button> </a>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"></h4>
                               
                                <div class="table-responsive m-t-40">
                                    <table id="example23"
                                        class="display nowrap table table-hover table-striped table-bordered"
                                        cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                            <th>Sl No</th>
                                                <th>Register No</th>
                                                <th>Student Name</th>
                                                <th>Date Of Birth</th> 
                                                <th>Gender</th>
                                                <th>Phone Number</th>
                                                <th>Email</th> 
                                                <th>Address</th> 
                                                <th>Qualification</th>
                                                <th>Course Type</th>
                                                <th>Course</th>
                                                <th>Fees</th>
                                                  <th>Total Marks</th> 
                                                  <th>Average</th> 
                                                  <th>Grade</th> 
                                                <th>Join Date</th>
                                                <th>Balance</th> 
                                                <th>Action</th>
                                            </tr>
                                        </thead>                                        
                                        <tbody>
                                        <?php
                                        $stmt = $admin->get_alumini();
                                        $i=1;
                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                            ?>
                                            <tr>
                                            <td> <?php echo $i++; ?></td>
                                            <td><?php echo $row['RegisterNo']; ?></td>
                                            <td><?php echo $row['StudentName']; ?></td>
                                            <td><?php echo $row['DateOfBirth']; ?></td> 
                                            <td><?php echo $row['Gender']; ?></td>
                                            <td><?php echo $row['PhoneNo']; ?></td>
                                            <td><?php echo $row['Email']; ?></td>
                                            <td><?php echo $row['Address']; ?></td>
                                            <td><?php  echo $row['Qualification']; ?></td> 
                                            <td><?php  echo $row['CourseType']; ?></td> 
                                            <td>
                                            <?php 
                                            $courseKeyArray=explode(",",$row['CourseName']);
                                             $i=0;
                                             foreach($courseKeyArray as $s)
                                            {
                                                if($s !=" "){ 
                                                    ?>

                                                    <label onclick="printImg('<?php echo 'assets/certificate/'.$row['RegisterNo'].'_'.$row['StudentName'].'_'.trim($s," ").'.jpg';?>')"><?php  echo $s; ?> ,</label>
                                              <?php  }
                                            }
                                            ?>
                                             </td>
                                             <td><?php echo $row['Fees']; ?></td>
                                             <td><?php echo $row['Marks']; ?></td>
                                            <td><?php echo $row['Avg']; ?></td>
                                             <td><?php echo $row['Grade']; ?></td>
                                            <td><?php  echo $row['JoinDate']; ?></td>
                                            <td><?php  echo $row['Balance']; ?></td>

                                            <td>  <a href="controller/alumni_controller.php?delete_alumini_id=<?php echo $row['KeyCode'] ?>" title="Delete" onclick="return confirm('Are you Sure want to Delete the Student'); " class="btn btn-warning"><i class="fa fa-trash"></i></a></td>

                                        </tr>
                                        <?php }?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>                        
                        
                        <!-- table responsive -->
                       
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
       
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
    <!--This page plugins -->
    <script src="assets/node_modules/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="assets/node_modules/datatables.net-bs4/js/dataTables.responsive.min.js"></script>
    <!-- start - This is for export functionality only -->
    <script src="cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
    <!-- end - This is for export functionality only -->

    <!-- Sweet-Alert starts  -->
    <script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <script src="assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
    <!-- sweet alert ends -->

    <?php $control->sessionMessage(); ?>

    <script>
        $(function () {
            $('#myTable').DataTable();
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function (settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;
                    api.column(2, {
                        page: 'current'
                    }).data().each(function (group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group + '</td></tr>');
                            last = group;
                        }
                    });
                }
            });
            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function () {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
            // responsive table
            $('#config-table').DataTable({
                responsive: true
            });
            $('#example23').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel').addClass('btn btn-primary mr-1');
        });

        (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();

    </script>

    <script>
        $(document).ready(function(){
            $('#add_close').click(function(){
                $('#S_Code').val('');
                $('#S_Name').val('');
            });
            $('.close').click(function(){
                $('#S_Code').val('');
                $('#S_Name').val('');
            });

            $('#btnCreteNew').click(function(){
                window.open('AddStudent.php','_self'); 
               
            })
        });
         function printImg(srt){        
    var URL = srt;
    var W = window.open(URL);
    W.window.print();
}
    </script>
</body>



</html>