<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();

?>


<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/form-bootstrap-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:06 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>MNTC || Add Faculty</title>
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">

    <!-- sweet alert starts -->
    <link href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    
    <link href="bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!-- <link href="select2.min.css" rel="stylesheet" type="text/css" media="all" /> -->

    <link href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css" rel="stylesheet" />

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <style>
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
    background-color: #e4e4e4;
    border: 1px solid #aaa;
    border-radius: 4px;
    cursor: default;
    float: left;
    margin-right: 5px;
    margin-top: 5px;
    padding: 0 5px;
    color: black;
}
    </style>

   

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
   
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Add Faculty</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                           
                            <button type="button" id='btnViewFaculty' class="btn btn-info d-none d-lg-block m-l-15"> View Faculty </button>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                
                                <form class="needs-validation" method='POST' action='controller/faculty_controller.php' novalidate>
                                    <div class="form-row">
                                        <div class="col-md-4 mb-3">
                                            <label for="validationCustom01">Faculty Code.</label>
                                            <input type="text" class="form-control" id='validationCustom01' name="faculty_code" placeholder="Faculty Code." required>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>

                                            <div class="invalid-feedback">
                                                Please enter Faculty Code.
                                            </div>

                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="validationCustom02">Faculty Name</label>
                                            <input type="text" class="form-control" id='validationCustom02' name="faculty_name" pattern="^[a-zA-Z][a-zA-Z0-9-_\.]{5,3}$" placeholder="Faculty Name"  required>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please enter Faculty Name..
                                            </div>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="faculty_type">Faculty Type</label>
                                            <select name="faculty_type" id="faculty_type" class='form-control' required>
                                                     <option value="">Faculty Type</option>
                                                     <option value="Temporary">Temporary</option>
                                                     <option value="Permenent">Permenent</option>
                                                </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please Faculty Type..
                                            </div>

                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="joindate">Date Of Birth</label>
                                            <input type="date" class="form-control" id='dob' name="dob" max="2005-12-30" required>
                                            
                                                <div class="invalid-feedback">
                                                    Choose DOB.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>


                                        

                                        <div class="col-md-4 mb-3">
                                            <label for="validationCustomUsername">Phone No</label>
                                            <input type="text" class="form-control" id='validationCustomUsername' name="phone_no" pattern="^\d{10}$" placeholder="Phone No"  required>
                                                <div class="invalid-feedback">
                                                    Choose Phone No.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="faculty_gender">Gender</label>
                                            <select name="faculty_gender" id="faculty_gender" class='form-control' required>
                                                     <option value="">Gender</option>
                                                     <option value="male">Male</option>
                                                     <option value="female">Female</option>
                                                </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please choose Gender..
                                            </div>

                                        </div>

                                        <div class="col-md-3 mb-3">
                                            <label for="email">Email</label>
                                            <input type="email" class="form-control"  id='email' name="email" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
                                                <div class="invalid-feedback">
                                                    Choose Email.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                        <div class="col-md-3 mb-3">
                                            <label for="address">Address</label>
                                            <input type="text" class="form-control" id='address' name="address" placeholder="Address" pattern="[A-Za-z]+" required>
                                                <div class="invalid-feedback">
                                                    Choose Address.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                      

                                      

                                        <div class="col-md-3 mb-3">
                                            <label for="salary">Salary</label>
                                            <input type="number" min='0'  class="form-control" id='salary' name="salary" placeholder="Salary Amount" pattern="[0-9]+" required>
                                            
                                                <div class="invalid-feedback">
                                                    Choose Salary..
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                        <div class="col-md-3 mb-3">
                                            <label for="joindate">Join Date</label>
                                            <input type="date" class="form-control" id='joindate' name="joindate" min="2008-01-01" required>
                                            
                                                <div class="invalid-feedback">
                                                    Choose Join Date.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                        <div class="col-md-11 mb-3" id='Select2FacultyDiv' >
                                            <label class="col-md-11 mb-3 for="FacultySelect2">Available Days</label>
                                            <select name="FacultySelect2[]" id="FacultySelect2" class='form-control' required multiple style='width:72%;'>
                                                <option value="">Faculty Available On</option>
                                                <option value="Sunday">Sunday</option>
                                                <option value="Monday">Monday</option>
                                                <option value="Tuesday">Tuesday</option>
                                                <option value="Wednesday">Wednesday</option>
                                                <option value="Thursday">Thursday</option>
                                                <option value="Friday">Friday</option>
                                                <option value="Saturday">Saturday</option>
                                                </select> 
                                                <button class='btn btn-success' id='btnpickAll' type='button'>Pick All Days</button>
                                                <button class='btn btn-danger' id='btnpickRemove' type='button'>Remove All Days</button>
                                            <div class="invalid-feedback">
                                                Please choose Available Days.
                                            </div>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                        </div>
                                        
                                    </div>
                                   
                                    <button class="btn btn-primary" name='add_faculty' type="submit">Save Faculty</button>
                                </form>
                                <script>
                                // Example starter JavaScript for disabling form submissions if there are invalid fields
                                (function() {
                                    'use strict';
                                    window.addEventListener('load', function() {
                                        // Fetch all the forms we want to apply custom Bootstrap validation styles to
                                        var forms = document.getElementsByClassName('needs-validation');
                                        // Loop over them and prevent submission
                                        var validation = Array.prototype.filter.call(forms, function(form) {
                                            form.addEventListener('submit', function(event) {
                                                if (form.checkValidity() === false) {
                                                    event.preventDefault();
                                                    event.stopPropagation();
                                                }
                                                form.classList.add('was-validated');
                                            }, false);
                                        });
                                    }, false);
                                })();
                                </script>
                            </div>
                        </div>
                    </div>
                    
                </div>

                 
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>

    <!-- Sweet-Alert starts  -->
    <script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <script src="assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
    <!-- sweet alert ends -->

 <script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js"></script>

  
<!-- 
    <script type="text/javascript" src='select2.min.js'></script> 
    <script src="bootstrap.min.js"></script> -->

    <?php $control->sessionMessage(); ?>


    <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
    </script>

    <script>
        $(document).ready(function(){
           

            $('#FacultySelect2').select2({
            placeholder: "SELECT DAYS"
            
          }).change(function () {
            var selectedIDs = $.map($('#FacultySelect2').select2('data'), function (val, i) {
              return val.id;
            }).join(",");
         //   $('#selectedIDs').text(selectedIDs);
          });

            $('#btnpickAll').click(function()
            {
                $('#FacultySelect2 > option').prop("selected",true).trigger("change");
            });
            $('#btnpickRemove').click(function()
            {
                $('#FacultySelect2 > option').prop("selected",false).trigger("change");
            });
         
            $('#btnViewFaculty').click(function(){
                window.open('ViewFaculty.php','_self');
              
            })


        }) //Doc End
    </script>
</body>


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/form-bootstrap-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:06 GMT -->
</html>