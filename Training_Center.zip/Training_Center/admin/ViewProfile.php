a<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();

$id = $_GET['keycode'];
$res = $admin->getStudentID_H($id);

?>




<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon.png"> 
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <title>MNTC || View Student Profile</title>
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <style type="text/css">
        b, strong {
                font-weight: bolder;
                font-variant: petite-caps;
                font-weight: bold;
                font-size: 14px;
                font-family: verdana;
            }
            .h1 {text-align: center;}
    </style>

</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
 
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
         <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Student Profile</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                         
                         <a href="Report.php"> <button type="button" class="btn btn-info d-none d-lg-block m-l-15">Return to Report</button> </a>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30"> 
                                    <h3 class="card-title  m-t-10" style='font-variant: petite-caps;'><?php echo $res['StudentName'] ?></h3>
                                    <h6 class="card-subtitle">Roll No: <?php echo $res['RegisterNo'] ?></h6>
                                    <div class="row text-center justify-content-md-center">
                                      
                                    </div>
                                </center>
                            </div>
                            <div>
                                <hr> </div>
                            <div class="card-body"> <small class="text-muted" style='color: #33a5f9 !important;'>Email address </small>
                                <h6><?php echo $res['Email'] ?></h6> <small class="text-muted p-t-30 db" style='color: #33a5f9 !important;'>Phone</small>
                                 <h6><?php echo $res['PhoneNumber'] ?></h6> <small class="text-muted p-t-30 db" style='color: #33a5f9 !important;'>Address</small>
                                <h6><?php echo $res['Address'] ?></h6>
                                
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Details</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Marks</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Attendence</a> </li>
                                 </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                     <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Register No.</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['RegisterNo'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Full Name</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['StudentName'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Date Of Birth</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['DateOfBirth'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6"> <strong>Gender</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['Gender'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Phone Number</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['PhoneNumber'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Email</strong>
                                                <br>
                                                <p class="text-muted"> <?php echo $res['Email'] ?> </p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Address</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['Address'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6"> <strong>Qualification</strong>
                                                <br>

                                                 <?php
                                                        $stmt = $admin->get_qualification();
                                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                          if($row["KeyCode"]==$res['QualificationKeyCode'])
                                                            {
                                                            
                                                           ?>

                                                <p class="text-muted"><?php echo $row["Qualification"] ?></p>
                                            <?php }}  ?>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Course Type</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['CourseType'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Course</strong>
                                                <br>
                                                <?php 
                                                $courseName='';
                                                $courseKey=$res['CourseKeyCode'];
                                                $courseKeyArray=explode(",",$courseKey);
                                                foreach($courseKeyArray as $s)
                                                {
                                                    $stmtCourse = $admin->get_course_by_id($s);
                                                    while ($row1 = $stmtCourse->fetch(PDO::FETCH_ASSOC)) {
                                                        $courseName=$courseName.$row1['CourseName']."   , ";
                                                    }
                                                }
                                            ?>

                                                <p class="text-muted"><?php echo $courseName ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Fees</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['Fees'] ?></p>
                                            </div>
                                        
                                            <div class="col-md-4 col-xs-6"> <strong>Join Date </strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['JoinDate'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6"> <strong>Student Registered On</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['SavedDate'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6"> <strong>Balance Amount</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['Balance'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6"> <strong>Fees Status</strong>
                                                <br>
                                                <p class="text-muted"><?php 
                                                if($res['Balance'] > 0){
                                                    echo "Payment Remaining"; // text cheng manpi
                                                }else{
                                                    echo "Fees Paid"; // ok finish

                                                }

                                                ?></p>
                                            </div>
                                        </div>
                                        <hr>
                                       
                                       
                                    </div>
                                </div>
                                <!--second tab-->
                                <div class="tab-pane" id="profile" role="tabpanel">
                                    <div class="card-body">

                                       <div class='col-md-12'>
                                        <?php 
                                         $stmtCourse1 = $admin->get_stu_name_cor($res['CourseKeyCode']);
                                         while ($row1 = $stmtCourse1->fetch(PDO::FETCH_ASSOC)) {
                                            $stmtCou = $admin->get_stu_name_sub_mar($row1['SubjectKeyCode'],$id);
                                            ?>
                                            
                                            <h6 class="m-t-30 h1" style='margin-top: 10px ;font-size: 18px;font-weight: 600;'><?php echo $row1['CourseName'] ?></h6>
                                            <?php 
                                            $toatmar=0;
                                            $fin=0;

                                            while ($row11 = $stmtCou->fetch(PDO::FETCH_ASSOC)) {
                                                 $fin+=100;


                                                 // $subjectKeycode3=$row1['SubjectKeyCode'];
                                                 // $stmt33=$admin->view_marks($subjectKeycode3);
                                                 // $row12=$stmt33->fetch(PDO::FETCH_ASSOC);

                                                 $toatmar+=$row11['mark'];

                                                 if ($row11['mark']=='') { ?>
                                                    
                                                     <h5 class="m-t-30" style='margin-top: 13px;'><?php echo $row11['SubjectName'] ?>
                                                 <span class="pull-right"> NOT ADD</span><?php
                                                  
                                                 }else{?>
                                                     <h5 class="m-t-30" style='margin-top: 13px;'><?php echo $row11['SubjectName'] ?>
                                                 <span class="pull-right"> <?php echo $row11['mark']; ?> / 100</span>
                                                  <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $row11['mark']?>%; height:6px;"> </div>
                                            </div>
                                                    <?php 
                                                    ?>
                                                    <?php 
                                                 }
                                             ?>
                                               
                                                
                                               <?php /*
                                                $stmt3 = $admin->get_student_attendencePRO($id,$row11['KeyCode']); 
                                                 if($stmt3['PresentCount']!=''){
                                                 $pesent= $stmt3['PresentCount'];
                                                  $absent= $stmt3['AbsentCount'];
                                                   $m=(($pesent*100)/($pesent+$absent));

                                               }else{
                                                 $pesent= 0;
                                                  $absent=0;
                                                  $m=100;
                                                }?>
                                                <h5 class="m-t-30" style='margin-top: 13px;'><?php echo $row11['SubjectName'] ?>
                                            <span class="pull-right"> <?php echo $pesent; ?> / <?php echo $pesent+$absent; ?></span>
                                            
                                            <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $m?>%; height:6px;"> </div>
                                            </div>    
                                            </h5>
                                               
                                               <?php 

*/
                                            }

                                            ?>
                                            <hr>
                                            <h5 class="m-t-30" style='margin-top: 13px;font-size: 18px;font-weight: 600;;'>Total Marks : 
                                           <span class="pull-right"><?php echo  $toatmar.' / '.$fin ?></span> 
                                            </h5><hr>
                                            <?php
                                         }
                                       
                                        ?>
                                    </div>


                                    </div>
                                </div>
                            



                                <div class="tab-pane" id="settings" role="tabpanel">
                                    <div class="card-body">
                                        <div class='col-md-12'>
                                        <?php 
                                         $stmtCourse1 = $admin->get_stu_name_cor($res['CourseKeyCode']);
                                         while ($row1 = $stmtCourse1->fetch(PDO::FETCH_ASSOC)) {
                                            $stmtCou = $admin->get_stu_name_sub($row1['SubjectKeyCode']);
                                            ?>
                                            
                                            <h4 class="font-medium m-t-30" style='margin-top: 10px;'><?php echo $row1['CourseName'] ?></h4><hr>
                                            <?php 
                                            while ($row11 = $stmtCou->fetch(PDO::FETCH_ASSOC)) {
                                                
                                               
                                                $stmt3 = $admin->get_student_attendencePRO($id,$row11['KeyCode']); 
                                                 if($stmt3['PresentCount']!=''){
                                                 $pesent= $stmt3['PresentCount'];
                                                  $absent= $stmt3['AbsentCount'];
                                                   $m=(($pesent*100)/($pesent+$absent));

                                               }else{
                                                 $pesent= 0;
                                                  $absent=0;
                                                  $m=100;
                                                }?>
                                                <h5 class="m-t-30" style='margin-top: 13px;'><?php echo $row11['SubjectName'] ?>
                                            <span class="pull-right"> <?php echo $pesent; ?> / <?php echo $pesent+$absent; ?></span>
                                            
                                            <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $m?>%; height:6px;"> </div>
                                            </div>    
                                            </h5>
                                               
                                               <?php 


                                            }

                                            ?>
                                            <hr>
                                            <?php
                                         }
                                       
                                        ?>
                                    </div>

                                       <!--  <form class="form-horizontal form-material">
                                            <div class="form-group">
                                                <label class="col-md-12">Full Name</label>
                                                <div class="col-md-12">
                                                    <input type="text" placeholder="Johnathan Doe" class="form-control form-control-line">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="example-email" class="col-md-12">Email</label>
                                                <div class="col-md-12">
                                                    <input type="email" placeholder="johnathan@admin.com" class="form-control form-control-line" name="example-email" id="example-email">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Password</label>
                                                <div class="col-md-12">
                                                    <input type="password" value="password" class="form-control form-control-line">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Phone No</label>
                                                <div class="col-md-12">
                                                    <input type="text" placeholder="123 456 7890" class="form-control form-control-line">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Message</label>
                                                <div class="col-md-12">
                                                    <textarea rows="5" class="form-control form-control-line"></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-12">Select Country</label>
                                                <div class="col-sm-12">
                                                    <select class="form-control form-control-line">
                                                        <option>London</option>
                                                        <option>India</option>
                                                        <option>Usa</option>
                                                        <option>Canada</option>
                                                        <option>Thailand</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-12">
                                                    <button class="btn btn-success">Update Profile</button>
                                                </div>
                                            </div>
                                        </form> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
               
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>

      <script>
        $(document).ready(function(){
          

            $('#btnCreteNew').click(function(){
                window.open('AddStudent.php','_self'); 
               
            })
        });
    </script>

</body>

</html>