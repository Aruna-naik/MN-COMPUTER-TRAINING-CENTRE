<?php

	define('DIR', '../');
	require_once DIR . 'config.php';

	$controller = new Controller();

	session_destroy();

	$controller->redirect('../index');

?>