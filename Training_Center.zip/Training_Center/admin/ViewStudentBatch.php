<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();
?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/table-data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:23 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>MNTC || View Course</title>
    <!-- This Page CSS -->
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- sweet alert starts -->
    <link href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- sweet alert ends -->
</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">View Student Batch</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            
                           
                         <button type="button" class="btn btn-info" id='btnCreteNew'>Create New</button>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"></h4>
                               
                                <div class="table-responsive m-t-40">
                                    <table id="example23"
                                        class="display nowrap table table-hover table-striped table-bordered"
                                        cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sl No</th>
                                                <th>Course Code</th>
                                                <th>Course Name</th>
                                                <th>Bacth Name</th>
                                                <th>Register No</th>
                                                <th>Student Name</th>
                                                <th>Action</th>
                                                <th style="display: none;"></th>
                                                <th style="display: none;"></th>
                                                <th style="display: none;"></th>
                                                 <th style="display: none;"></th>
                                            </tr>
                                        </thead>                                        
                                        <tbody>
                                        <?php
                                        $stmt = $admin->get_student_batch();
                                        $i=1;
                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                            ?>
                                            <tr>
                                            <td> <?php echo $i++; ?></td>
                                            <td><?php echo $row['CourseCode']; ?></td>
                                            <td><?php echo $row['CourseName']; ?></td>
                                            <td><?php echo $row['BatchName']; ?></td>
                                            <td><?php echo $row['RegisterNo']; ?></td>
                                            <td><?php echo $row['StudentName']; ?></td>
                                           
                                            <td><a title="Update" class="btn btn-info edit"><i class="fa fa-edit" id= style='color:white;'></i></a> 
                                                <a href="controller/batch_controller.php?delete_batch_id=<?php echo $row['KeyCode'] ?>" title="Delete" onclick="return confirm('Are you Sure want to Delete the Course'); " class="btn btn-warning"><i class="fa fa-trash"></i></a></td>
                                                <td style='display:none;'><?php echo $row['CourseKeyCode']; ?></td>
                                                <td style='display:none;'><?php echo $row['BatchKeyCode']; ?></td>
                                                <td style='display:none;'><?php echo $row['KeyCode']; ?></td>
                                                <td style='display:none;'><?php echo $row['StudentKeyCode']; ?></td>
                                        </tr>
                                         
                                        <?php }?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>                        
                        
                        <!-- table responsive -->
                       
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                        <form class="needs-validation" novalidate method='POST' id="assignbatchstudent" action="controller/batch_controller.php">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="exampleModalLabel1">Edit only Batch</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            </div>
                                            <div class="modal-body">
                                           
                                    <div class="form-row">
                                        <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Select Course</label>
                                            <select class="form-control" id="course" placeholder="Select course" name="courseedit" required>
                                            <option value="" selected disabled>---SELECT COURSE--</option>
                                            <?php
                                                $stmt = $admin->get_course();
                                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                    ?>
                                            <option value="<?php echo $row['KeyCode'] ?>"><?php echo  $row['CourseName'] ?></option>
                                      <?php } ?>
                                            <?php ?>
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a course.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row" style="margin-top: 15px">

                                    <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Select Batch</label>
                                            <select class="form-control" id="batch" placeholder="Select Batch" name="batchedit" required>
                                            
                                     
                                            </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a batch.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row" style="margin-top: 15px">
                                    <div class="col-md-12 mb-12">
                                            <label for="validationCustom01">Select Sudents Roll NO</label>
                                            <input type="text" class="form-control" id="Student_rno" name="Student_rno" placeholder="Student Roll No" required readonly>
                                        
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                    Please choose a Sudents Roll NO.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-row" style="margin-top: 15px">
                                    <div class="col-md-12 mb-12">
                                            <label for="validationCustom03">Student Name</label>
                                            <input type="text" class="form-control" id="student_name" name="student_name"placeholder="Student Name" required readonly>
                                        
                                        </div>
                                    </div>

                                    <input type="hidden" id="hiddenstudentkeycode" name="hiddenstudentkeycode" value="">
                                    <input type="hidden" id="hiddenrole" name="hiddenrole" value="">
                                    <input type="hidden" id="hidencoures" name="hidencoures" value="">
                                    
                                    <input type="hidden" id="assig" name="assig" value="">
                                    

                                
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                               
                                                <button class="btn btn-primary" type="submit"name="addassignbatchstudent">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
    <!--This page plugins -->
    <script src="assets/node_modules/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="assets/node_modules/datatables.net-bs4/js/dataTables.responsive.min.js"></script>
    <!-- start - This is for export functionality only -->
    <script src="cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
    <!-- end - This is for export functionality only -->

    <!-- Sweet-Alert starts  -->
    <script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <script src="assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
    <!-- sweet alert ends -->

    <?php $control->sessionMessage(); ?>

    <script>
        $(function () {
            $('#myTable').DataTable();
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function (settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;
                    api.column(2, {
                        page: 'current'
                    }).data().each(function (group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group + '</td></tr>');
                            last = group;
                        }
                    });
                }
            });
            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function () {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
            // responsive table
            $('#config-table').DataTable({
                responsive: true
            });
            $('#example23').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel').addClass('btn btn-primary mr-1');
        });

        (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();


    $('#example23 tbody tr').on('click','td:nth-child(7) .edit',function(){

        var course =$(this).parent().parent().find('td:nth-child(8)').text();
        var batch =$(this).parent().parent().find('td:nth-child(9)').text();
        var keycode =$(this).parent().parent().find('td:nth-child(10)').text();
        var keycodestudent =$(this).parent().parent().find('td:nth-child(11)').text();

        var s_roll =$(this).parent().parent().find('td:nth-child(5)').text();
        var s_name =$(this).parent().parent().find('td:nth-child(6)').text();

        $('#hidencoures').val(course);
        $('#hiddenrole').val(s_roll);
        $('#hiddenstudentkeycode').val(keycodestudent);
        $('#assig').val(keycode);
        $('#course').val(course);
         $('#Student_rno').val(s_roll);
          $('#Student_rno').val(s_roll);
           $('#student_name').val(s_name);
       $.ajax({
                    url: "controller/batch_controller.php",
                    type: "POST", //send it through get method
                    data: {course_assign: course},
                    
                    success: function(response) {
                    $('#batch').html('');
                    $('#batch').append(response);
                    $('#batch').val(batch);
                     
                    //Do Something
                    },
                    error: function(result) {
                    alert(result);                     
                        //Do Something to handle error
                    }
                });

       // $.ajax({
       //              url: "controller/batch_controller.php",
       //              type: "POST", //send it through get method
       //              data: {edit_course_student: course},
                    
       //              success: function(response) {
       //              $('#Student_rno').html('');
       //             // $('#Student_rno').append('<option value='.keycodestudent.' selected >'.s_roll.'</option>');
       //              $('#Student_rno').append(response);
       //              $('#Student_rno').append('<option value='+keycodestudent+' selected>'+s_roll+'</option>');
       //              $('#student_name').val(s_name);
                  
       //              },
       //              error: function(result) {
       //              alert(result);                     
                       
       //              }
       //          });
        
                $('#exampleModal').modal('show');
            });

            $('#course').change(function(){
                $('#student_name').val('');
                var course=$('#course').val();
                var hidencoures=$('#hidencoures').val();
                var hiddenrole=$('#hiddenrole').val();
                var hiddenstudentkeycode=$('#hiddenstudentkeycode').val();

                $.ajax({
                    url: "controller/batch_controller.php",
                    type: "POST", //send it through get method
                    data: {course_assign: course},
                    
                    success: function(response) {
                    $('#batch').html('');
                    $('#batch').append(response);
                    $('#batch').val('');
                     
                    //Do Something
                    },
                    error: function(result) {
                    alert(result);                     
                        //Do Something to handle error
                    }
                });

              //   $.ajax({
              //       url: "controller/batch_controller.php",
              //       type: "POST", //send it through get method
              //       data: {edit_course_student: course},
                    
              //       success: function(response) {
              //       $('#Student_rno').html('');
                    
              // // a
              //  $('#Student_rno').append('<option value="" selected>-- SELECT STUDENT --</option>');
              //   if(course==hidencoures){
              //       $('#Student_rno').append('<option value='+hiddenstudentkeycode+'>'+hiddenrole+'</option>');
              //   }
              //       $('#Student_rno').append(response);
                  
                  
              //       },
              //       error: function(result) {
              //       alert(result);                     
                       
              //       }
              //   });
            });
            // $('#Student_rno').change(function(){
            //     var student_key=$('#Student_rno').val();
            //     $.ajax({
            //         url: "controller/batch_controller.php",
            //         type: "POST", //send it through get method
            //         data: {Student_rno_by_id: student_key},
                    
            //         success: function(response) {

            //        $('#student_name').val(response);
                  
            //         },
            //         error: function(result) {
            //         alert(result);                     
                       
            //         }
            //     });

            //     });
    </script>

    <script>
       
    </script>
</body>



</html>