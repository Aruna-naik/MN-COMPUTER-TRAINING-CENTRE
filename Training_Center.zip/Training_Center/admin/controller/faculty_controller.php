<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();



if (isset($_POST['add_faculty'])) 
{
  $select2_faculty='';
  $facultySelect2='';

  $faculty_code = $_POST['faculty_code']; 
  $dob = $_POST['dob'];  
 
  $faculty_name = $_POST['faculty_name']; 
  $faculty_gender = $_POST['faculty_gender']; 
  $phone_no = $_POST['phone_no']; 
  $email = $_POST['email']; 
  $address = $_POST['address']; 
  $salary = $_POST['salary']; 
  $join_date = $_POST['joindate']; 
  $faculty_type = $_POST['faculty_type']; 

  

 
  if(isset($_POST['FacultySelect2']))
  {
    $facultySelect2 = $_POST['FacultySelect2']; 
    $select2_faculty= implode(",",$facultySelect2);
  }

  


   

    
$isCode=$admin->is_faculty_code_exist($faculty_code);


if($isCode == 0)
{
   $res = $admin->add_faculty($faculty_code,$faculty_name,$dob,$faculty_gender,$phone_no,$email,$address,$salary,$select2_faculty,$faculty_type,$join_date);
    
    
    if ($res == true) {
        $_SESSION['success_message'] = "Successfully Added";
        $admin->redirect('../AddFaculty');
    }else{
        $_SESSION['error_message'] = "Sorry not inserted!!!!";
        $admin->redirect('../AddFaculty');
    }
}
else if($isCode == -1)
{
    $_SESSION['error_message'] = "Sorry not inserted!!";
    $admin->redirect('../AddFaculty');
}
else
{
    $_SESSION['error_message'] = "Faculty Code Already Exits!!";
    $admin->redirect('../AddFaculty');
}
}


if(isset($_GET['delete_faculty_id']))
{
    $id=$_GET['delete_faculty_id'];
        $res=$admin->delete_faculty_id_H($id);
        if($res==true)
        {
          $_SESSION['success_message'] = "Your record has been deleted";
        }
        else
        {
            $_SESSION['error_message'] = "Sorry still not deleted!!!!!!!!!!";
        }

$admin->redirect('../ViewFaculty');
}

if (isset($_POST['edit_faculty'])) 
{
    $select2_faculty='';
    $facultySelect2='';
  
    $faculty_code = $_POST['faculty_code']; 
    $dob = $_POST['dob'];  
   
    $faculty_name = $_POST['faculty_name']; 
    $faculty_gender = $_POST['faculty_gender']; 
    $phone_no = $_POST['phone_no']; 
    $email = $_POST['email']; 
    $address = $_POST['address']; 
    $salary = $_POST['salary']; 
    $join_date = $_POST['joindate']; 
    $faculty_type = $_POST['faculty_type'];
    $keycode = $_POST['keycode'];  
  
    
  
   
    if(isset($_POST['FacultySelect2']))
    {
      $facultySelect2 = $_POST['FacultySelect2']; 
      $select2_faculty= implode(",",$facultySelect2);
    }
  
    
  
  
     
   

$isCode=$admin->is_faculty_code_exist_edit($faculty_code,$keycode);


if($isCode == 0)
{
   $res = $admin->edit_faculty($faculty_code,$faculty_name,$dob,$faculty_gender,$phone_no,$email,$address,$salary,$select2_faculty,$faculty_type,$join_date,$keycode);
  
    
    if ($res == true) {
        $_SESSION['success_message'] = "Successfully Updated";
        $admin->redirect('../ViewFaculty');
    }else{
        $_SESSION['error_message'] = "Sorry not updated!!!!";
        $admin->redirect('../ViewFaculty');
    }
}
else if($isCode == -1)
{
    $_SESSION['error_message'] = "Sorry not inserted!!";
    $admin->redirect('../ViewFaculty');
}
else
{
    $_SESSION['error_message'] = "Faculty Code Already Exits!!";
    $admin->redirect('../ViewFaculty');
}
}














?>


     