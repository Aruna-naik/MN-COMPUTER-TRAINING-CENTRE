<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();

//course selected
if (isset($_POST['course_selected'])) 
{
 $batchname='';
  $course_selected = $_POST['course_selected'];  
  $stmt = $admin->get_batchID($course_selected);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $batchname.='<option value='.$row['KeyCode'].'>'.$row['BatchName'].'</option>';      
  }
  echo  $batchname;
}

//batch selected
if (isset($_POST['batch_selected'])) 
{
 $student='';
  $batch_selected = $_POST['batch_selected'];  
  $stmt = $admin->get_student_ID($batch_selected);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $student.='<option value='.$row['KeyCode'].'>'.$row['StudentName'].'</option>';      
  }
  echo  $student;
}

//get the fees based on student
if (isset($_POST['student_selected'])) 
{
  $fees='';
  $student_selected = $_POST['student_selected'];  
  $stmt = $admin->get_studentDetail($student_selected);

   $fees=$stmt['Fees'];      
  echo $fees;
}

//get the Remaining amount based on Total Fees
if (isset($_POST['student_selected1'])) 
{
  $balance='';
  $fees='';
  $remain='';
  $std = $_POST['student_selected1']; 
  $stmt = $admin->get_balance($std);
  $fees=$stmt['Fees']; 
  $balance=$stmt['Balance'];  
   //$remain=($fees-$balance);
  echo $balance;
}

//Student print details selected
if (isset($_POST['student_key'])) 
{
 $student='';
  $std_key = $_POST['student_key'];  
  $stmt = $admin->get_student_dtl($std_key);
  $a =array();
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
   // $student=$row['RegisterNo']; 
   $a =$row;
        
}
 
  echo json_encode( $a );
}

//add subject
if (isset($_POST['Create_Receipt'])) 
{  
    $Batch = $_POST['batch']; 
    $Student = $_POST['student'];    
    $paid = $_POST['paid_Amount']; 
    $balance = $_POST['bal_fees'];
    //$remain_fees= $_POST['remain_fees'];
    $Tot_fees = $_POST['tot_fees'];
    $get_balance='';

    // $res1=$admin->check_balance($Student);
    // $get_balance=$res1['Balance'];   
    // if($paid>$balance){
    //     $_SESSION['error_message'] = "Sorry ! All Fees Paid ";
    //     $admin->redirect('../GenerateReceipt');
    // }
    // else{     
        $res=$admin->pay_fees($Batch,$Student,$paid,$balance);
        if($res){
            $_SESSION['success_message'] = "Fees Paid SuccessFully";
            $admin->redirect('../GenerateReceipt');
            }else{
                $_SESSION['error_message'] = "Sorry ! Not Paid";
            $admin->redirect('../GenerateReceipt');
            }
    //}    
}

//delete subject
if (isset($_GET['mark_id'])) 
{
$mark_key= $_GET['mark_id'];
//$res2=$admin->delete_mark($mark_key);
    if($res2){
         $_SESSION['success_message'] = "Mark has been Deleted ";
       $admin->redirect('../ViewMarks');
    }else{
          $_SESSION['error_message'] = "Sorry ! Cannot Deleted";
       $admin->redirect('../ViewMarks');
    }
}


//edit marks
if (isset($_POST['edit_mark'])) 
{
    $Course1 = $_POST['course1'];  
    $Batch1 = $_POST['batch1']; 
    $Student1 = $_POST['student1']; 
    $Subject1 = $_POST['subject1']; 
    $Mark1 = $_POST['std_mark1'];
    $Mark_keycode = $_POST['mark_keycode'];

    //$res=$admin->edit_mark($Course1,$Batch1,$Student1,$Subject1,$Mark1,$Mark_keycode);
    if($res){
         $_SESSION['success_message'] = "Updated SuccessFully";
       $admin->redirect('../ViewMarks');
    }else{
          $_SESSION['error_message'] = "Sorry ! Not Updated";
       $admin->redirect('../ViewMarks');
    }

    
}

?>