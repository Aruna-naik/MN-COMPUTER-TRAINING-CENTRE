<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();

if (isset($_POST['addassignbatch'])) 
{
  $batch = $_POST['addBATCH'];  
  $course = $_POST['addCOURSE']; 

   $stmt = $admin->get_course_batch($batch,$course);
   if($stmt){
       $_SESSION['error_message'] = "Sorry already batch created!!!!!!!!!!";
        $admin->redirect('../AssignBatch');
      
    }else{
      $res=$admin->add_assignbatch($batch,$course);
      if($res){
        
         $_SESSION['success_message'] = "Added Successfully";
         $admin->redirect('../AssignBatch');
      }else{
        $_SESSION['error_message'] = "Sorry not inserted!!!!!!!!!!";
         $admin->redirect('../AssignBatch');
      }
    }
   
}

if (isset($_POST['course'])) 
{
  $course = $_POST['course'];  
  $stmt = $admin->get_course_code($course);
  echo $stmt['CourseCode'];
      
   
   
}
if (isset($_POST['batchcount'])) 
{
  $batchkeycode = $_POST['batchcount'];  
  $stmt = $admin->get_batch_student_count($batchkeycode);
 echo $stmt;
      
   
   
}

if (isset($_GET['Batchiddelete'])) 
{
   
  $batch = $_GET['Batchiddelete'];  
  

   
      $res=$admin->delete_batch($batch);
     /* echo $res;
      exit();*/
      if($res){
         $_SESSION['success_message'] = "Deleted Successfully";
         $admin->redirect('../AssignBatch');
      }else{
        $_SESSION['error_message'] = "Sorry not inserted!!!!!!!!!!";
         $admin->redirect('../AssignBatch');
      }
   
}

if (isset($_POST['editassignbatch'])) 
{
   
 $BatchName = $_POST['editBATCH'];  
  $CourseKeyCode = $_POST['editCOURSE']; 
 $KeyCode = $_POST['editKey']; 
  
     $stmt=$admin->get_course_batch_KeyCode($CourseKeyCode,$BatchName,$KeyCode);
     
   if($stmt){
       $_SESSION['error_message'] = "Sorry already batch created!!!!!!!!!!";
        $admin->redirect('../AssignBatch');
      
    }else{
      $res=$admin->update_assignbatch($CourseKeyCode,$BatchName,$KeyCode);
      if($res){
        
         $_SESSION['success_message'] = "Update Successfully";
         $admin->redirect('../AssignBatch');
      }else{
        $_SESSION['error_message'] = "Sorry not Update!!!!!!!!!!";
         $admin->redirect('../AssignBatch');
      }
    }
   
}

if (isset($_POST['course_assign'])) 
{
 $batch='';
 $batch.='<option value="">-- SELECT BATCH --</option>';
  $course = $_POST['course_assign'];  
  $stmt = $admin->get_Batch_ID_S($course);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $batch.='<option value='.$row['KeyCode'].'>'.$row['BatchName'].'</option>';      
  }
  echo  $batch;
}

if (isset($_POST['course_student'])) 
{
 $student='';
 
  $course = $_POST['course_student']; 
  $batch = $_POST['batch'];  
  $stmt = $admin->get_student_H();
  $i=0;
   while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
     $courseName='';
     $courseKey=$row['CourseKeyCode'];
      $courseKeyArray=explode(",",$courseKey);
      foreach($courseKeyArray as $s)
       {
        if($s==$course){
        $stmtCourse = $admin->get_id_assignstudent($row['KeyCode'],$s);
       if($stmtCourse == 0){
           $student.='<tr><td style="display:none">'.$row['KeyCode'].'</td> <td>'.++$i.'</td><td>'.$row['RegisterNo'].'</><td>'.$row['StudentName'].'</><td>
        <label class="switch"><input type="checkbox"  id="togBtn" class="togBtn"><div class="slider"><!--ADDED HTML --><span class="on">Assign on'.$batch.'</span><span class="off">Not Assign</span><!--END--></div></label>
        

        
      </td></tr>';


       }
      }

       }

   }
   echo  $student;
  /*$stmt = $admin->get_course_student_S();
  $i=0;
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
     $student.='<tr><td style="display:none">'.$row['KeyCode'].'</td> <td>'.++$i.'</td><td>'.$row['RegisterNo'].'</><td>'.$row['StudentName'].'</><td>
        <label class="switch"><input type="checkbox"   class="togBtn"><div class="slider"><!--ADDED HTML --><span class="on">Assign on'.$batch.'</span><span class="off">Not Assign</span><!--END--></div></label>
        

        
      </td></tr>';  
  }
  echo  $student;*/
}

if (isset($_POST['std_key'])) 
{

  $std_key = $_POST['std_key'];  
  $status = $_POST['status'];  
  $batch = $_POST['batch'];  
  $course = $_POST['course'];  
  
  $count=1;
  foreach($std_key as $value) {
     $stmt = $admin->add_student_batch($value,$course,$batch);
     if(!$stmt){
        
        $_SESSION['error_message'] = "Sorry not Update!!!!!!!!!!";
         $admin->redirect('../AssignBatch');
      }else{
        $count++;
      }

      
  }
  if( $count==sizeof($std_key)){
    $_SESSION['success_message'] = "Update Successfully";
    $admin->redirect('../AssignBatch');
  }

  /*$stmt = $admin->add_student_batch($course);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $batch.='<option value='.$row['KeyCode'].'>'.$row['BatchName'].'</option>';      
  }
  echo  $batch;*/
}


if (isset($_GET['delete_batch_id'])) 
{
   
  $batch = $_GET['delete_batch_id'];  
  

   
      $res=$admin->delete_batch_student($batch);
    
      if($res){
         $_SESSION['success_message'] = "Deleted Successfully";
         $admin->redirect('../ViewStudentBatch');
      }else{
        $_SESSION['error_message'] = "Sorry not inserted!!!!!!!!!!";
         $admin->redirect('../ViewStudentBatch');
      }
   
}

if (isset($_POST['get_course_id'])) 
{
 $batch='';
 $batch.='<option value="">-- SELECT BATCH --</option>';
  $course = $_POST['get_course_id'];  
  $batchKey = $_POST['batch'];  
  //echo $batchKey;
  $stmt = $admin->get_Batch_ID_S($course);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      if($batchKey==$row['KeyCode']){
         $batch.='<option value='.$row['KeyCode'].' selected >'.$row['BatchName'].'</option>';  
      }else{
         $batch.='<option value='.$row['KeyCode'].'>'.$row['BatchName'].'</option>';  
      }   
  }
  echo  $batch;
}

if (isset($_POST['edit_course_student'])) 
{
 $student='';
 
  $course = $_POST['edit_course_student']; 
  
  $stmt = $admin->get_student_H();
 // $i=0;
   while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
     $courseName='';
     $courseKey=$row['CourseKeyCode'];
      $courseKeyArray=explode(",",$courseKey);
      foreach($courseKeyArray as $s)
       {
        if($s==$course){
        $stmtCourse = $admin->get_id_assignstudent($row['KeyCode'],$s);
       if($stmtCourse == 0){

          $student.='<option value='.$row['KeyCode'].' >'.$row['RegisterNo'].'</option>';
           /*$student.='<tr><td style="display:none">'.$row['KeyCode'].'</td> <td>'.++$i.'</td><td>'.$row['RegisterNo'].'</><td>'.$row['StudentName'].'</><td>
        <label class="switch"><input type="checkbox"   class="togBtn"><div class="slider"><!--ADDED HTML --><span class="on">Assign on'.$batch.'</span><span class="off">Not Assign</span><!--END--></div></label>
        

        
      </td></tr>';*/


       }
      }

       }



   }

   echo  $student;
  
}


if (isset($_POST['Student_rno_by_id'])) 
{
  $KeyCode = $_POST['Student_rno_by_id']; 
  


  $stmt = $admin->getStudentID_H($KeyCode);
 // $i=0;
   echo $stmt['StudentName'];

}


if (isset($_POST['addassignbatchstudent'])) 
{
   
 $CourseKeyCode = $_POST['courseedit'];  
  $BatchName = $_POST['batchedit'];  
  echo $StudentKeyCode = $_POST['hiddenstudentkeycode'];  
 $KeyCode = $_POST['assig']; 
 $isCode=$admin->countstudentbach($BatchName,$StudentKeyCode);
 if($isCode < 5)
{
  $res=$admin->update_assignbatchStudent($CourseKeyCode,$BatchName,$StudentKeyCode,$KeyCode);
      if($res){
        
         $_SESSION['success_message'] = "Update Successfully";
         $admin->redirect('../ViewStudentBatch');
      }
      else{
        $_SESSION['error_message'] = "Sorry not Update!!!!!!!!!!";
         $admin->redirect('../ViewStudentBatch');
      }

  
//ok done

  }else{
    $_SESSION['error_message'] = "Sorry batch is full!!!!!!!!!!";
         $admin->redirect('../ViewStudentBatch');
}
     /* $res=$admin->update_assignbatchStudent($CourseKeyCode,$BatchName,$StudentKeyCode,$KeyCode);
      if($res){
        
         $_SESSION['success_message'] = "Update Successfully";
         $admin->redirect('../ViewStudentBatch');
      }
      else{
        $_SESSION['error_message'] = "Sorry not Update!!!!!!!!!!";
         $admin->redirect('../ViewStudentBatch');
      }*/
   
   
}
if (isset($_POST['count_batch'])) 
{
  $course = $_POST['course'];  
  $stmt = $admin->get_course_code($course);
  echo $stmt['CourseCode'];
      
   
   
}
?>


     