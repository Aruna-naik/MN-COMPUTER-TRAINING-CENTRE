<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();

//course selected
if (isset($_POST['course_selected'])) 
{
 $batchname='';
  $course_selected = $_POST['course_selected'];  
  $stmt = $admin->get_batchID($course_selected);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $batchname.='<option value='.$row['KeyCode'].'>'.$row['BatchName'].'</option>';      
  }
  echo  $batchname;
}


//batch selected
if (isset($_POST['batch_selected'])) 
{
 $student='';
  $batch_selected = $_POST['batch_selected'];  
  $stmt = $admin->get_student_ID($batch_selected);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $student.='<option value='.$row['KeyCode'].'>'.$row['StudentName'].'</option>';      
  }
  echo  $student;
}
/*

if (isset($_POST['student_selected'])) 
{
 $subject='';
  $student_selected = $_POST['student_selected'];  
  $stmt = $admin->get_corse_ID($student_selected);
  $Course_key=$stmt['CourseKeyCode'];
  $stmt1 = $admin->get_sub_ID($Course_key);
  while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
      $subarray =explode(',',$row['SubjectKeyCode']);
      foreach($subarray as $s)
      {
            $stmt2 = $admin->get_sub_name($s);
            while ($row1 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                 $subject.='<option value='.$row1['KeyCode'].'>'.$row1['SubjectName'].'</option>';
            }
      }     
}
echo  $subject;
}

*/

if (isset($_POST['get_sub'])) 
{
 $subject='';
  $Course_key = $_POST['get_sub'];  
  
  $stmt1 = $admin->get_sub_ID($Course_key);
  while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
      $subarray =explode(',',$row['SubjectKeyCode']);
      foreach($subarray as $s)
      {
            $stmt2 = $admin->get_sub_name($s);
            while ($row1 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                 $subject.='<option value='.$row1['KeyCode'].'>'.$row1['SubjectName'].'</option>';
            }
      }     
}
echo  $subject;
}
//add subject
if (isset($_POST['assign_mark'])) 
{
    $Course = $_POST['course'];  
    $Batch = $_POST['batch']; 
    $Student = $_POST['student']; 
    $Subject = $_POST['subject']; 
    $Mark = $_POST['std_mark']; 
  
    $res1=$admin->check_mark($Student,$Subject);

    if($res1==-1)
    {
        $_SESSION['error_message'] = "Sorry ! something went wrong";
            $admin->redirect('../AssignMarks');
    }
    else if($res1==0){
        $res=$admin->add_mark($Course,$Batch,$Student,$Subject,$Mark);
        if($res){
            $_SESSION['success_message'] = "Marks Added SuccessFully";
        $admin->redirect('../AssignMarks');
        }else{
            $_SESSION['error_message'] = "Sorry ! Not Added";
        $admin->redirect('../AssignMarks');
        }
    }
    else{
        $_SESSION['error_message'] = "Sorry ! Marks Already Entered for this student";
        $admin->redirect('../AssignMarks');
    }    
}

//delete subject
if (isset($_GET['mark_id'])) 
{
$mark_key= $_GET['mark_id'];
$res2=$admin->delete_mark($mark_key);
    if($res2){
         $_SESSION['success_message'] = "Mark has been Deleted ";
       $admin->redirect('../ViewMarks');
    }else{
          $_SESSION['error_message'] = "Sorry ! Cannot Deleted";
       $admin->redirect('../ViewMarks');
    }
}


//edit marks
if (isset($_POST['edit_mark'])) 
{
    $Course1 = $_POST['course1'];  
    $Batch1 = $_POST['batch1']; 
    $Student1 = $_POST['student1']; 
    $Subject1 = $_POST['subject1']; 
    $Mark1 = $_POST['std_mark1'];
    $Mark_keycode = $_POST['mark_keycode'];

    $res=$admin->edit_mark($Course1,$Batch1,$Student1,$Subject1,$Mark1,$Mark_keycode);
    if($res){
         $_SESSION['success_message'] = "Updated SuccessFully";
       $admin->redirect('../ViewMarks');
    }else{
          $_SESSION['error_message'] = "Sorry ! Not Updated";
       $admin->redirect('../ViewMarks');
    }

    
}




?>