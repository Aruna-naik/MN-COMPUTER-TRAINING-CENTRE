<?php
define('DIR', '../../');

require_once DIR . 'config.php';

$admin = new Admin();



//new h timetable//

//course_selected_subject
if (isset($_POST['course_selected_subject'])) 
{
 $subject='';
  $course_selected = $_POST['course_selected_subject'];  
  $stmt = $admin->get_subject_by_course($course_selected);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

  
   
      $subarray =explode(',',$row['SubjectKeyCode']);
      foreach($subarray as $s)
      {
            $stmt2 = $admin->get_sub_name($s);
            while ($row1 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                 $subject.='<option value='.$row1['KeyCode'].'>'.$row1['SubjectName'].'</option>';
            }
      }     
echo  $subject;     
  }
 
}

////new h timetable//

//15/03/2020 starts//
if (isset($_POST['faculty_selected'])) 
{
 $faculty='';

  $faculty_selected = $_POST['faculty_selected'];  
  $stmt = $admin->get_faculty_days($faculty_selected);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
     $days=explode(',',$row['Available']);
     foreach ($days as  $d) {
        $faculty.='<option value='.$d.'>'.$d.'</option>';
     }
   
  }     
echo  $faculty;     
}




if (isset($_POST['btntimetableSave'])) 
{
 
  $add_course = $_POST['add_course'];  
  $batch_select = $_POST['batch_select']; 
  $subject_select = $_POST['subject_select']; 
  $faculty_select = $_POST['faculty_select']; 
  $day_select = $_POST['day_select']; 
  $start_time = $_POST['start_time'].':00'; 
  $end_time = $_POST['end_time'] .':00'; 

  $isValidTimeFaculty = 'true';
  $isValidTimeBatch = 'true';
  $start_time1 = DateTime::createFromFormat('H:i:s', $start_time);
  $end_time1 = DateTime::createFromFormat('H:i:s', $end_time);
  
 
    
$Isfaculty_day_exists=$admin->is_faculty_day_exists($faculty_select,$batch_select,$day_select);
$IsBatch_day_exists=$admin->is_Batch_day_exists($faculty_select,$batch_select,$day_select);

while ($row1 = $Isfaculty_day_exists->fetch(PDO::FETCH_ASSOC)) {
      $dbStartTime = DateTime::createFromFormat('H:i:s', $row1['StartTime']);
      $dbEndTime = DateTime::createFromFormat('H:i:s', $row1['EndTime']);
      if ($start_time1 > $dbStartTime && $start_time1 < $dbEndTime)
      {
        $isValidTimeFaculty = 'false';
      }
      else if($end_time1 > $dbStartTime && $end_time1 < $dbEndTime)
      {
        $isValidTimeFaculty = 'false';
      }
     if($start_time1 < $dbStartTime &&  $end_time1 > $dbEndTime )
      {
        $isValidTimeFaculty = 'false';
      }
     if($start_time1 == $dbStartTime &&  $end_time1 == $dbEndTime )
      {
        $isValidTimeFaculty = 'false';
      }
       if($end_time1 == $start_time1 )
      {
        $isValidTimeFaculty = 'false';
      }
  } 

  while ($row2 = $IsBatch_day_exists->fetch(PDO::FETCH_ASSOC)) {
      $dbStartTime = DateTime::createFromFormat('H:i:s', $row2['StartTime']);
      $dbEndTime = DateTime::createFromFormat('H:i:s', $row2['EndTime']);
      if ($start_time2 > $dbStartTime && $start_time2 < $dbEndTime)
      {
        $isValidTimeBatch = 'false';
      }
      else if($end_time2 > $dbStartTime && $end_time2 < $dbEndTime)
      {
        $isValidTimeBatch = 'false';
      }
     if($start_time2 < $dbStartTime &&  $end_time2 > $dbEndTime )
      {
        $isValidTimeBatch = 'false';
      }
     if($start_time2 == $dbStartTime &&  $end_time2 == $dbEndTime )
      {
        $isValidTimeBatch = 'false';
      }
       if($end_time2 == $start_time2 )
      {
        $isValidTimeBatch = 'false';
      }
  }



if($isValidTimeFaculty == 'false')
{


    $_SESSION['error_message'] = "This Time is Already Assign To Different Faculty  On ".$day_select;
    $admin->redirect('../AddTimeTable');
}

if($isValidTimeBatch == 'false')
{
   

    $_SESSION['error_message'] = "This Time is Already Assign To Different Batch  On ".$day_select;
    $admin->redirect('../AddTimeTable');
}

 if($Isfaculty_day_exists == -1 || $isValidTimeBatch==-1 )
{
    $_SESSION['error_message'] = "Sorry not inserted!!";
    $admin->redirect('../AddTimeTable');
}

if($isValidTimeBatch == 'true' && $isValidTimeFaculty == 'true')
{
     $res = $admin->add_time_table($add_course,$batch_select,$subject_select,$faculty_select,$day_select,$start_time,$end_time);
    
    if ($res == true) {
        $_SESSION['success_message'] = "Successfully Added";
        $admin->redirect('../AddTimeTable');
    }else{
        $_SESSION['error_message'] = "Sorry not inserted!!!!";
        $admin->redirect('../AddTimeTable');
    }
}

}

if(isset($_GET['TimeTableDelete']))
{
    $id=$_GET['TimeTableDelete'];
        $res=$admin->delete_timetable_id_H($id);
        if($res==true)
        {
          $_SESSION['success_message'] = "Your record has been deleted";
        }
        else
        {
            $_SESSION['error_message'] = "Sorry still not deleted!!!!!!!!!!";
        }

$admin->redirect('../ViewFaculty');
}


 


//15/03/2020 ends//

//16/03/2020 starts//   
if (isset($_POST['btntimetableEdit'])) 
{

  $KeyCode = $_POST['hiddenKeyCode'];  
  $CourseKeyCode = $_POST['edit_course']; 
  $BatchKeyCode = $_POST['edit_batch_select']; 
  $SubjectKeyCode = $_POST['edit_subject_select']; 
  $FacultyKeyCode = $_POST['edit_faculty_select']; 
  $day = $_POST['edit_day_select']; 
  
  $start_time = $_POST['edit_start_time']; 
  $end_time = $_POST['edit_end_time']; 

  $isValidTimeFaculty = 'true';
  $isValidTimeBatch = 'true';
  $start_time1 = DateTime::createFromFormat('H:i:s', $start_time);
  $end_time1 = DateTime::createFromFormat('H:i:s', $end_time);
  
 
    
$Isfaculty_day_exists=$admin->is_faculty_day_exists_edit($FacultyKeyCode,$day,$KeyCode);
$IsBatch_day_exists=$admin->is_Batch_day_exists_edit($BatchKeyCode,$day,$KeyCode);

while ($row1 = $Isfaculty_day_exists->fetch(PDO::FETCH_ASSOC)) {
      $dbStartTime = DateTime::createFromFormat('H:i:s', $row1['StartTime']);
      $dbEndTime = DateTime::createFromFormat('H:i:s', $row1['EndTime']);
      if ($start_time1 > $dbStartTime && $start_time1 < $dbEndTime)
      {
        $isValidTimeFaculty = 'false';
      }
      else if($end_time1 > $dbStartTime && $end_time1 < $dbEndTime)
      {
        $isValidTimeFaculty = 'false';
      }
     if($start_time1 < $dbStartTime &&  $end_time1 > $dbEndTime )
      {
        $isValidTimeFaculty = 'false';
      }
     if($start_time1 == $dbStartTime &&  $end_time1 == $dbEndTime )
      {
        $isValidTimeFaculty = 'false';
      }
       if($end_time1 == $start_time1 )
      {
        $isValidTimeFaculty = 'false';
      }
  } 

  while ($row2 = $IsBatch_day_exists->fetch(PDO::FETCH_ASSOC)) {
      $dbStartTime = DateTime::createFromFormat('H:i:s', $row2['StartTime']);
      $dbEndTime = DateTime::createFromFormat('H:i:s', $row2['EndTime']);
      if ($start_time2 > $dbStartTime && $start_time2 < $dbEndTime)
      {
        $isValidTimeBatch = 'false';
      }
      else if($end_time2 > $dbStartTime && $end_time2 < $dbEndTime)
      {
        $isValidTimeBatch = 'false';
      }
     if($start_time2 < $dbStartTime &&  $end_time2 > $dbEndTime )
      {
        $isValidTimeBatch = 'false';
      }
     if($start_time2 == $dbStartTime &&  $end_time2 == $dbEndTime )
      {
        $isValidTimeBatch = 'false';
      }
       if($end_time2 == $start_time2 )
      {
        $isValidTimeBatch = 'false';
      }
  }

if($isValidTimeFaculty == 'false')
{
    $_SESSION['error_message'] = "This Time is Already Assign To Different Faculty  On ".$day;
    $admin->redirect('../AddTimeTable');
     // echo 'false3';
     // exit();
}

if($isValidTimeBatch == 'false')
{
    $_SESSION['error_message'] = "This Time is Already Assign To Different Batch  On ".$day;
    $admin->redirect('../AddTimeTable');
    // echo 'false2';
    // exit();
}

//  if($Isfaculty_day_exists == -1 || $isValidTimeBatch==-1 )
// {
//     // $_SESSION['error_message'] = "Sorry not inserted!!";
//     // $admin->redirect('../AddTimeTable');
//     echo 'false';
//     exit();
// }

if($isValidTimeBatch == 'true' && $isValidTimeFaculty == 'true')
{
     $res = $admin->edit_time_table($CourseKeyCode,$BatchKeyCode,$SubjectKeyCode,$FacultyKeyCode,$day,$start_time,$end_time,$KeyCode);
    
    if ($res == true) {
        $_SESSION['success_message'] = "Successfully Updated";
        $admin->redirect('../AddTimeTable');
        // echo 'true';
        // exit();

    }else{
        $_SESSION['error_message'] = "Sorry not Updated!!!!";
        $admin->redirect('../AddTimeTable');
         // echo 'false1';
         // exit();
    }
}

}




//16/03/2020 Ends//

?>