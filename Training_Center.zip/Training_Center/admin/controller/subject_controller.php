<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();


//add subject
if (isset($_POST['subject_save'])) 
{
  $SubjectCode = $_POST['sub_code'];  
  $SubjectName = $_POST['sub_name']; 

  
  $res1=$admin->check_subject($SubjectCode);

if($res1==-1)
{
    $_SESSION['error_message'] = "Sorry ! something went wrong";
         $admin->redirect('../Subject');
}
else if($res1==0){
    $res=$admin->add_subject($SubjectCode,$SubjectName);
    if($res){
         $_SESSION['success_message'] = "Inserted SuccessFully";
       $admin->redirect('../Subject');
    }else{
          $_SESSION['error_message'] = "Sorry ! Not Inserted";
       $admin->redirect('../Subject');
    }
}
else{
    $_SESSION['error_message'] = "Sorry ! Subject Code Already exists";
       $admin->redirect('../Subject');
}
    
}

//delete subject
if (isset($_GET['sub_id'])) 
{
$sub_key= $_GET['sub_id'];
$res2=$admin->delete_sub($sub_key);
    if($res2){
         $_SESSION['success_message'] = "Subject has been Deleted ";
       $admin->redirect('../Subject');
    }else{
          $_SESSION['error_message'] = "Sorry ! Cannot Deleted";
       $admin->redirect('../Subject');
    }
}

//edit subject
    if (isset($_POST['subject_edit'])) 
    {
      $SubjectCode = $_POST['sub_code1'];  
      $SubjectName = $_POST['sub_name1']; 
      $sub_keycode = $_POST['sub_key'];


        $res=$admin->edit_subject($SubjectCode,$SubjectName,$sub_keycode);
        if($res){
             $_SESSION['success_message'] = "Updated SuccessFully";
           $admin->redirect('../Subject');
        }else{
              $_SESSION['error_message'] = "Sorry ! Not Updated";
           $admin->redirect('../Subject');
        }
   
        
    }

?>


     