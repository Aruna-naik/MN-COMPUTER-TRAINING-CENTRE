<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();

if (isset($_POST['add_course'])) 
{
  $select2_course='';
  $finalSubject='';
  $subject='';
  $subject='';
  $subjectSelect2='';
  $course_code = $_POST['course_code'];  
 
  $course_name = $_POST['course_name']; 
  $course_type = $_POST['course_type']; 
  $course_fees = $_POST['course_fees']; 

  if(isset($_POST['subject']))
  {
  $subject = $_POST['subject']; 
  }
  if(isset($_POST['subjectSelect2']))
  {
    $subjectSelect2 = $_POST['subjectSelect2']; 
    $select2_course= implode(",",$subjectSelect2);
  }

  $duration = $_POST['duration']; 

  
    if ($select2_course == '') {
        $finalSubject=$subject;
       
    }
	if ($subject == '') {
        $finalSubject=$select2_course;
	}
		
	if ($finalSubject == '') {
		$_SESSION['warning_message'] = "please Enter Subject";
 		die($admin->redirect('../AddCourse'));
    }


   

    
$isCode=$admin->is_course_code_exist($course_code);

if($isCode == 0)
{
   $res = $admin->add_course($course_code,$course_name,$course_type,$finalSubject,$duration,$course_fees);
    
    if ($res == true) {
        $_SESSION['success_message'] = "Successfully Added";
        $admin->redirect('../ViewCourse');
    }else{
        $_SESSION['error_message'] = "Sorry not inserted!!!!";
        $admin->redirect('../AddCourse');
    }
}
else if($isCode == -1)
{
    $_SESSION['error_message'] = "Sorry not inserted!!";
    $admin->redirect('../AddCourse');
}
else
{
    $_SESSION['error_message'] = "Course Code Already Exits!!";
    $admin->redirect('../AddCourse');
}
}

if(isset($_GET['delete_course_id'])){
    $id=$_GET['delete_course_id'];
    $isbatchDeleted=$admin->delete_batch_from_course($id);
  
	if ($isbatchDeleted == true) {
        $isbatchDeleted=$admin->delete_batch_from_course($id);
        $res=$admin->delete_course($id);
        if($res==true)
        {
          $_SESSION['success_message'] = "Your record has been deleted";
        }
        else{
            $_SESSION['error_message'] = "Sorry still not deleted!!!!!!!!!!";
        }
	}else{
		$_SESSION['error_message'] = "Sorry still not deleted!!!!!!!!!!";
	}
$admin->redirect('../ViewCourse');
}


if (isset($_POST['edit_course'])) 
{
  $select2_course='';
  $finalSubject='';
  $subject='';
  $subject='';
  $subjectSelect2='';
  $course_code = $_POST['course_code'];  
 
  $course_name = trim($_POST['course_name']); 
  $course_type = $_POST['course_type']; 
  $course_fees = $_POST['course_fees']; 

  if(isset($_POST['subject']))
  {
  $subject = $_POST['subject']; 
  }
  if(isset($_POST['subjectSelect2']))
  {
    $subjectSelect2 = $_POST['subjectSelect2']; 
    $select2_course= implode(",",$subjectSelect2);
  }

  $duration = $_POST['duration']; 
  $keycode = $_POST['keycode']; 

  
    if ($select2_course == '') {
        $finalSubject=$subject;
       
    }
	if ($subject == '') {
        $finalSubject=$select2_course;
	}
		
	if ($finalSubject == '') {
		$_SESSION['warning_message'] = "please Enter Subject";
 		die($admin->redirect('../ViewCourse'));
    }


   

    
$isCode=$admin->is_course_code_exist_edit($course_code,$keycode);

if($isCode == 0)
{
   $res = $admin->edit_course($course_code,$course_name,$course_type,$finalSubject,$duration,$course_fees,$keycode);
    
    if ($res == true) {
        $_SESSION['success_message'] = "Successfully Updated";
        $admin->redirect('../ViewCourse');
    }else{
        $_SESSION['error_message'] = "Sorry not updated!!!!";
        $admin->redirect('../ViewCourse');
    }
}
else if($isCode == -1)
{
    $_SESSION['error_message'] = "Sorry not inserted!!";
    $admin->redirect('../ViewCourse');
}
else
{
    $_SESSION['error_message'] = "Course Code Already Exits!!";
    $admin->redirect('../ViewCourse');
}
}



?>


     