<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();



if(isset($_GET['add_alumini']))
{
  $id = $_GET['add_alumini'];
$res = $admin->getStudentID_Alumini($id);
 $courseName='';
  $mrks=0;
 $subcount=0;
 $cname=[];
    $courseKey=$res['CourseKeyCode'];
    if($res['Balance']>0)
    {
     $_SESSION['error_message'] = $row2['Balance']."Fees Not Paid!!!!";
        die($admin->redirect('../GenerateReceipt'));

    }
    $courseKeyArray=explode(",",$courseKey);
    $i=0;
    foreach($courseKeyArray as $s)
     {

       $stmtCourse = $admin->get_course_by_id($s);
      while ($row1 = $stmtCourse->fetch(PDO::FETCH_ASSOC)) {
      $courseName=$courseName.$row1['CourseName']."   , ";
      $cname=$row1['CourseName'];

       $stmtCourse1 = $admin->get_student_markaddalu($id,$row1['SubjectKeyCode']);
      while ($row2 = $stmtCourse1->fetch(PDO::FETCH_ASSOC)) {
      //echo $row2['markes']."   , ";
        if ($row2['markes']==null) {
       $_SESSION['error_message'] = $row2['SubjectName']."This Subject is not assigned any marks!!!!";
        die($admin->redirect('../AssignMarks'));

        }
      $mrks+=$row2['markes'];
      $subcount++;
     }
     }

 }
 
$avg= round($mrks*100/($subcount*100),2);
 $m=$avg; 
if ($m<35)
    {
      $grade="C";
     } 
     if ($m>=90) 
    {
     $grade="A+";
    }
    if ($m>=75 && $m<90) 
    {
     $grade="A";
    }
                                             if ($m>=60 && $m<75) 
                                             {
                                                $grade="B+";
                                             }
                                             if ($m>=55 && $m<60) 
                                             {
                                                $grade="B";
                                             }
                                             if ($m>=35 && $m<55)
                                             {
                                                 $grade="C+";
                                             }
       foreach($courseKeyArray as $s)
     {

       $stmtCourse = $admin->get_course_by_id($s);
      while ($row1 = $stmtCourse->fetch(PDO::FETCH_ASSOC)) {

header('content-type: image/jpeg');
$font=realpath('../assets/font/BRUSHSCI.ttf');
$font1=realpath('../assets/font/AGENCYR.ttf');

$size = 75;
$image=imagecreatefromjpeg("../assets/images/A4.jpg");

$color=imagecolorallocate($image,19,21,22);
$white = imagecolorallocate($image, 255, 255, 255);
$name=$res['StudentName'];
$name1=$row1['CourseName'];
$sing="Herald Pinto";
date_default_timezone_set('Asia/Kolkata');
$date = date('d-m-y');
$box = imagettfbbox($size, 0, $font, $name);
$text_width = abs($box[2]) - abs($box[0]);
$text_height = abs($box[5]) - abs($box[3]);
$image_width = imagesx($image);
$image_height = imagesy($image);
$x = ($image_width - $text_width) / 2;
$y = ($image_height + $text_height) / 2;

imagettftext($image, $size, 0, $x-45, $y+40, $white, $font, $name);
imagettftext($image, 50, 0, 740, $y+550, $white, $font, $date);
imagettftext($image, 70, 0, $x+400, $y+550, $white, $font, $sing);

$box = imagettfbbox($size, 0, $font, $name1);
$text_width = abs($box[2]) - abs($box[0]);
$text_height = abs($box[5]) - abs($box[3]);
$image_width = imagesx($image);
$image_height = imagesy($image);
$x = ($image_width - $text_width) / 2;
$y = ($image_height + $text_height) / 2;


imagettftext($image, $size, 0, $x+650, $y+220, $white, $font, $name1);




$file=$res['RegisterNo']."_".$res['StudentName']."_".$name1;
   // imagejpeg($image,"../assets/certificate/".$file.".jpg");
imagejpeg($image,"../assets/certificate/".$file.".jpg");
//imagejpeg($image);
imagedestroy($image);
     }
   }

 //echo ($mrks*100/($subcount*100));

 $res = $admin->add_alumini($res['RegisterNo'],$res['StudentName'],$res['DateOfBirth'],$res['Gender'],$res['PhoneNumber'],$res['Email'],$res['Address'],$res['Qualification'],$courseName,$res['Fees'],$res['JoinDate'],$res['CourseType'],$mrks,$grade,$avg);
        

    
    if ($res == true) {
        $res=$admin->delete_student_H($id);
        if($res==true)
        {
          /*header('content-type:image/jpeg');
  
  $font=realpath('../assets/font/BRUSHSCI.ttf');
$font1=realpath('../assets/font/AGENCYR.ttf');
  $image=imagecreatefromjpeg("../assets/images/certificate.jpg");
  $color=imagecolorallocate($image,19,21,22);
  
    $name=$res['StudentName'];
    imagettftext($image,50,0,365,420,$color,$font,$name);
    $date="6th may 2020";
    imagettftext($image,20,0,450,595,$color,$font1,$date);
    $file=time().'sushu_'.$res['KeyCode'];
    imagejpeg($image,"../assets/certificate/".$file.".jpg");
    imagedestroy($image);*/

       $_SESSION['success_message'] = "Successfully Added";

          $admin->redirect('../ViewAlumini');
        }
        else{
            $_SESSION['error_message'] = "Something went wrong!!!!!!!!!!";
                           die($admin->redirect('../Report'));

        }


    }else{
  
        $_SESSION['error_message'] = "Not inserted to Alumini!!!!";
           die($admin->redirect('../Report'));

    }

  
    
  


}

if(isset($_GET['delete_alumini_id']))
{
    $id=$_GET['delete_alumini_id'];
        $res=$admin->delete_alumini($id);
        if($res==true)
        {
          $_SESSION['success_message'] = "Your record has been deleted";
        }
        else{
            $_SESSION['error_message'] = "Sorry still not deleted!!!!!!!!!!";
        }

$admin->redirect('../ViewAlumini');
}
?>