<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();


if (isset($_POST['faculty_selected'])) 
{
  $faculty_code = $_POST['faculty_selected']; 
    $stmt2 = $admin->get_faculty_code($faculty_code);
            while ($row1 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                // $subject.='<option value='.$row1['KeyCode'].'>'.$row1['SubjectName'].'</option>';
                 echo $row1['FacultyName'];
            }

}
if (isset($_POST['faculty_selecteddate'])) 
{
  $faculty_selecteddate = $_POST['faculty_selecteddate']; 
    $stmt2 = $admin->get_faculty_code_st($faculty_selecteddate);
            while ($row1 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                // $subject.='<option value='.$row1['KeyCode'].'>'.$row1['SubjectName'].'</option>';
                 echo $row1['Status'];
            }

}
if (isset($_POST['getdate'])) 
{
  $faculty_code = $_POST['getdate']; 
  $f_date='';
  $f_date.='<option value="">-- SELECT DATE --</option>';
    $stmt2 = $admin->get_faculty_getdate($faculty_code);
            while ($row1 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                 $f_date.='<option value='.$row1['KeyCode'].'>'.$row1['AttendanceDate'].'</option>';
               
            }
              echo $f_date;

}

if (isset($_POST['save_faculty_attendance'])) 
{
  $faculty_date = $_POST['faculty_date'];  
  $faculty_KeyCode = $_POST['faculty_name']; 
  $attendance_status = $_POST['faculty_status']; 

  
  $res1=$admin->check_faculty_attendance($faculty_KeyCode,$faculty_date);

if($res1==-1)
{
    $_SESSION['error_message'] = "Sorry ! something went wrong";
         $admin->redirect('../facultyattendance');
}
else if($res1==0){
    $res=$admin->add_faculty_attendance($faculty_KeyCode,$faculty_date,$attendance_status);
    if($res){
         $_SESSION['success_message'] = "Inserted SuccessFully";
       $admin->redirect('../facultyattendance');
    }else{
          $_SESSION['error_message'] = "Sorry ! Not Inserted";
       $admin->redirect('../facultyattendance');
    }
}
else{
    $_SESSION['error_message'] = "Sorry ! Attendance is already inserted";
       $admin->redirect('../facultyattendance');
}
    
}



 if (isset($_POST['edit_fac_Att'])) 
    {
      $edit_faculty_status = $_POST['edit_faculty_status'];  
      $keycode = $_POST['edit_faculty_attDate']; 
    //  $sub_keycode = $_POST['sub_key'];


        $res=$admin->edit_fac_Att($edit_faculty_status,$keycode);
        if($res){
             $_SESSION['success_message'] = "Updated SuccessFully";
           $admin->redirect('../facultyattendance');
        }else{
              $_SESSION['error_message'] = "Sorry ! Not Updated";
           $admin->redirect('../facultyattendance');
        }
   
        
    }














?>


     