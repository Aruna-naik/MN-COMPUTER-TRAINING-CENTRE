<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();

if (isset($_POST['course_selected_normal'])) 
{
 $fees='';
  $course_selected_normal = $_POST['course_selected_normal'];  
  $stmt = $admin->get_course_fee($course_selected_normal);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
       $fees=$row['Fees'];      
  }
  echo  $fees;

}


if (isset($_POST['add_student'])) 
{
  $select2_course='';
  $finalCourse='';
  $course='';
 
  $courseSelect2='';
  $reg_no = $_POST['reg_no']; 
  $dob = $_POST['dob'];  
 
  $std_name = $_POST['std_name']; 
  $std_gender = $_POST['std_gender']; 
  $phone_no = $_POST['phone_no']; 
  $email = $_POST['email']; 
  $address = $_POST['address']; 
  $qualification = $_POST['qualification']; 
  $course_type = $_POST['course_type']; 
  

  if(isset($_POST['normal_course']))
  {
  $course = $_POST['normal_course']; 
  }
  if(isset($_POST['CourseSelect2']))
  {
    $courseSelect2 = $_POST['CourseSelect2']; 
    $select2_course= implode(",",$courseSelect2);
  }

  $fees = $_POST['fees']; 
  $joindate = $_POST['joindate']; 

  
    if ($select2_course == '') {
        $finalCourse=$course;
       
    }
	if ($course == '') {
        $finalCourse=$select2_course;
	}
		
	if ($finalCourse == '') {
		$_SESSION['warning_message'] = "Please Enter Course";
 		die($admin->redirect('../AddStudent'));
    }


   

    
$isReg=$admin->is_reg_no_exist($reg_no);


if($isReg == 0)
{
   $res = $admin->add_student($reg_no,$std_name,$dob,$std_gender,$phone_no,$email,$address,$qualification,$finalCourse,$fees,$joindate,$course_type);


    
    if ($res == true) {
        $_SESSION['success_message'] = "Successfully Added";
        $admin->redirect('../AddStudent');
    }else{
        $_SESSION['error_message'] = "Sorry not inserted!!!!";
        $admin->redirect('../AddStudent');
    }
}
else if($isReg == -1)
{
    $_SESSION['error_message'] = "Sorry not inserted!!";
    $admin->redirect('../AddStudent');
}
else
{
    $_SESSION['error_message'] = "Register Number Already Exits!!";
    $admin->redirect('../AddStudent');
}
}


if(isset($_GET['delete_student_id']))
{
    $id=$_GET['delete_student_id'];
        $res=$admin->delete_student_H($id);
        if($res==true)
        {
          $_SESSION['success_message'] = "Your record has been deleted";
        }
        else{
            $_SESSION['error_message'] = "Sorry still not deleted!!!!!!!!!!";
        }

$admin->redirect('../ViewStudent');
}


if (isset($_POST['edit_student'])) 
{
    $select2_course='';
    $finalCourse='';
    $course='';
   
    $courseSelect2='';
    $reg_no = $_POST['reg_no']; 
    $dob = $_POST['dob'];  
   
    $std_name = $_POST['std_name']; 
    $std_gender = $_POST['std_gender']; 
    $phone_no = $_POST['phone_no']; 
    $email = $_POST['email']; 
    $address = $_POST['address']; 
    $qualification = $_POST['qualification']; 
    $course_type = $_POST['course_type']; 
    $keycode = $_POST['keycode']; 
    
  
    if(isset($_POST['normal_course']))
    {
    $course = $_POST['normal_course']; 
    }
    if(isset($_POST['CourseSelect2']))
    {
      $courseSelect2 = $_POST['CourseSelect2']; 
      $select2_course= implode(",",$courseSelect2);
    }
  
    $fees = $_POST['fees']; 
    $joindate = $_POST['joindate']; 
  
    
      if ($select2_course == '') {
          $finalCourse=$course;
         
      }
      if ($course == '') {
          $finalCourse=$select2_course;
      }
          
      if ($finalCourse == '') {
          $_SESSION['warning_message'] = "Please Enter Course";
           die($admin->redirect('../ViewStudent'));
      }
  
  
     
   

$isReg=$admin->is_reg_no_exist_edit($reg_no,$keycode);


if($isReg == 0)
{
   $res = $admin->edit_student($reg_no,$std_name,$dob,$std_gender,$phone_no,$email,$address,$qualification,$finalCourse,$fees,$joindate,$course_type,$keycode);
  
    
    if ($res == true) {
        $_SESSION['success_message'] = "Successfully Updated";
        $admin->redirect('../ViewStudent');
    }else{
        $_SESSION['error_message'] = "Sorry not updated!!!!";
        $admin->redirect('../ViewStudent');
    }
}
else if($isReg == -1)
{
    $_SESSION['error_message'] = "Sorry not inserted!!";
    $admin->redirect('../ViewStudent');
}
else
{
    $_SESSION['error_message'] = "Register Number Already Exits!!";
    $admin->redirect('../ViewStudent');
}
}











?>


     