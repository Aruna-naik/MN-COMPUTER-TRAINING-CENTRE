<?php define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();

if (isset($_POST['add_qualification'])) 
{

  $qualification_name = $_POST['qualification_name'];   
   $res = $admin->add_qualification(toupper($qualification_name));
    
    if ($res == true) {
      
        $admin->redirect('../AddStudent');
    }else{
        $_SESSION['error_message'] = "Sorry not inserted!!!!";
        $admin->redirect('../AddStudent');
    }

}





?>


     