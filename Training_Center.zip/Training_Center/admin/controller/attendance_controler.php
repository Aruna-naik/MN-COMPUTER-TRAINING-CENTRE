
<?php 

 define('DIR', '../../');
require_once DIR . 'config.php';

$admin = new Admin();

if (isset($_POST['select_course'])) 
{
 $batch='';
 $batch.='<option value="">-- SELECT BATCH --</option>';
  $course = $_POST['select_course'];  
  $stmt = $admin->get_Batch_ID_S($course);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $batch.='<option value='.$row['KeyCode'].'>'.$row['BatchName'].'</option>';      
  }
  echo  $batch;
}


if (isset($_POST['select_batch'])) 
{
 $subject='';
  $Course_key = $_POST['select_batch'];  
  
  $stmt1 = $admin->get_sub_ID($Course_key);
  while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
      $subarray =explode(',',$row['SubjectKeyCode']);
      foreach($subarray as $s)
      {
            $stmt2 = $admin->get_sub_name($s);
            while ($row1 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                 $subject.='<option value='.$row1['KeyCode'].'>'.$row1['SubjectName'].'</option>';
            }
      }     
}
echo  $subject;
}

if (isset($_POST['attendancedate'])) 
{
 $time='';
 $time.='<option value="">-- SELECT TIME --</option>';
   $day = $_POST['attendancedate'];  

 
  $batch = $_POST['selected_day_batch'];
  $subject = $_POST['selected_subject'];
  $Adate = $_POST['Adate'];
  
 
  $stmt = $admin->get_Batch_ID_TIME($day,$batch,$subject,$Adate);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $time.='<option value='.$row['KeyCode'].'>'.$row['ST'].' to '.$row['ET'].'</option>';      
  }
  echo  $time;
}

if (isset($_POST['attendancedateedit'])) 
{
 $time='';
 $time.='<option value="">-- SELECT TIME --</option>';
   $day = $_POST['attendancedateedit'];  
  
  $batch = $_POST['selected_day_batch'];
  $subject = $_POST['selected_subject'];
  $Adate = $_POST['Adate'];
  
 
  $stmt = $admin->get_Batch_ID_TIME_EDIT($day,$batch,$subject,$Adate);
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $time.='<option value='.$row['KeyCode'].'>'.$row['ST'].' to '.$row['ET'].'</option>';      
  }
  echo  $time;
}




if (isset($_POST['selrcted_batch'])) 
{
 $student='';
 
  //$course = $_POST['course_student']; 
  $batch = $_POST['selrcted_batch'];  
  $stmt = $admin->get_student_assign($batch);
  $i=0;
   while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      
           $student.='<tr><td style="display:none">'.$row['StudentKeyCode'].'</td> <td>'.++$i.'</td><td>'.$row['RegisterNo'].'</><td>'.$row['StudentName'].'</><td>
        <label class="switch"><input type="checkbox" id="togBtn"  class="togBtn"><div class="slider"><!--ADDED HTML --><span class="on">Present</span><span class="off">Absent</span><!--END--></div></label>
        

        
      </td></tr>';


       

   }
   echo  $student;
 
}

	if (isset($_POST['std_key'])) 
	{
			$std_key = $_POST['std_key'];  
		  $status = $_POST['status'];  
		  $batch = $_POST['batch'];  
		  $course = $_POST['course']; 
		  $subject = $_POST['subject']; 
		  $time = $_POST['time']; 
		  $attendancedate_at = $_POST['attendancedate_at'];  
		  
		  $count=1;
		  for($i=0;$i<sizeof($std_key);$i++) {
		     $stmt = $admin->put_attendance($std_key[$i],$status[$i],$course,$batch,$subject,$time,$attendancedate_at);
		     if(!$stmt){
		       // echo "not";
		       $_SESSION['error_message'] = "Sorry not Update!!!!!!!!!!";
		       //  $admin->redirect('../AssignBatch');
		      }else{
		        $count++;
		      }

		      
		  }
		  if( $count==sizeof($std_key)){
		    $_SESSION['success_message'] = "Update Successfully";
		   // $admin->redirect('../AssignBatch');
		  }

	}


if (isset($_POST['view_getstudent_course'])) 
{
 $subject='';
 $subjectrow='';
 
  $Course_key=$_POST['view_getstudent_course'];
  $subjectrow.='<tr>';
  $stmt1 = $admin->get_sub_ID($Course_key);
  while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {

      $subarray =explode(',',$row['SubjectKeyCode']);
      $count=sizeof($subarray)*2;
      $subject.='<thead><tr><th rowspan="3">Sl No</th><th colspan="'.$count.'">Subject Name</th></tr><tr>';
      foreach($subarray as $s)
      {
            $stmt2 = $admin->get_sub_name($s);
           // $count=$stmt2->rowCount();
            while ($row1 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
            	 $subject.='<th colspan="2">'.$row1['SubjectName'].'</th>';
            	   $subjectrow.='<th>aa</th><th>aa</th>';
            	  //$subject.=$row1['SubjectName'].$count;
               //  $subject.='<option value='.$row1['KeyCode'].'>'.$row1['SubjectName'].'</option>';
            }
      }     
}
echo  $subject.'</tr>'. $subjectrow.'</tr></thead>';
}

if (isset($_POST['EditAttendance_btton'])) 
{

	$Atd_key = $_POST['StudentKeyCodeID'];
	$status = $_POST['attendance_status'];  
	$isAnyError = false;

	

	// foreach ($status as $s) {
	// 	echo $s;
	// }

	
	 for($i=0;$i<sizeof($Atd_key);$i++) {
	 	$stause_name='';
	 	if (in_array($Atd_key[$i], $status)) {
			    $stause_name='Present' ;
			}
			else
			{
				 $stause_name='Absent' ;
			}
		$res = $admin->edit_StudentAttendance($Atd_key[$i],$stause_name);
		if($res == false)
		{
			$isAnyError = true;
		}

    

	 	//echo $std_key[$i];
	 	// if($std_key[$i] == $_POST['attendance_status'][$i] )
	 	// if(isset($_POST['attendance_status'][$i]))
	 	// {
	 	// 	echo "Present";
	 	// }
	 	// else
	 	// {
	 	// 	echo 'false';
	 	// }
	 	

	 }  


    if ($isAnyError == false) {
        $_SESSION['success_message'] = "Successfully Updated";
        $admin->redirect('../EditAttendance');
    }else{
        $_SESSION['error_message'] = "Sorry not updated!!!!";
        $admin->redirect('../EditAttendance');
    }
}
?>