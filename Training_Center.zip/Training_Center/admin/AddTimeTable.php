<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>MNTC || Add Time Table</title>
    <!-- This Page CSS -->
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <link href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <link href="assets/node_modules/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">
    <!-- Page plugins css -->
    <link href="assets/node_modules/clockpicker/dist/jquery-clockpicker.min.css" rel="stylesheet">
    <!-- Color picker plugins css -->
    <link href="assets/node_modules/jquery-asColorPicker-master/dist/css/asColorPicker.css" rel="stylesheet">
    <!-- Date picker plugins css -->
    <link href="assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker plugins css -->
    <link href="assets/node_modules/timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
    <link href="assets/node_modules/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">


    <style>
       
            .modal-dialog {
                max-width: 70%;
                margin: 1.75rem auto;
            }
    </style>


   
  
</head>

<body class="skin-default fixed-layout">

    <div id="main-wrapper">
     
        <?php include '../header.html';?>

        <?php include '../nav.html';?>
     
        <div class="page-wrapper">
      
            <div class="container-fluid">
              
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Add Time Table</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            
                           
                            <button type="button" id="addnew" class="btn btn-info d-none d-lg-block m-l-15" data-toggle="modal" data-target="#exampleModal" data-whatever="@fat">
                                <i class="fa fa-plus-circle"></i> Create New</button>
                        </div>
                    </div>
                </div>
        
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><!--Data Export--></h4>
                                <h6 class="card-subtitle"><!--Export data to Copy, CSV, Excel, PDF & Print--></h6>
                                <div class="table-responsive m-t-40">
                                    <table id="example23"
                                        class="display nowrap table table-hover table-striped table-bordered"
                                        cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sl No</th>
                                                <th>Course Name</th>
                                                <th>Batch</th>
                                                <th>Subject</th>
                                                <th>Faculty Name</th>
                                                <th>Day</th>
                                                <th>Start Time</th>
                                                <th>End Time</th>
                                                <th>Action</th>
                                                <th style='display:none;'></th>
                                                <th style='display:none;'></th>
                                                <th style='display:none;'></th>
                                                <th style='display:none;'></th>
                                                <th style='display:none;'></th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>Sl No</th>
                                                <th>Course Name</th>
                                                <th>Batch</th>
                                                <th>Subject</th>
                                                <th>Faculty Name</th>
                                                <th>Day</th>
                                                <th>Start Time</th>
                                                <th>End Time</th>
                                                <th>Action</th>

                                                <th style='display:none;'></th>
                                                <th style='display:none;'></th>
                                                <th style='display:none;'></th>
                                                <th style='display:none;'></th>
                                                <th style='display:none;'></th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        <?php $i=1;
                                                $stmt1 = $admin->get_all_time_table();
                                                while ($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)) {
                                                    ?>
                                            <tr>
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo $row1['CourseName'] ?></td>
                                            <td><?php echo $row1['BatchName'] ?></td>
                                            <td><?php echo $row1['SubjectName'] ?></td>
                                            <td><?php echo $row1['FacultyName'] ?></td>
                                            <td><?php echo $row1['Day'] ?></td>
                                            <td><?php echo $row1['StartTime'] ?></td>
                                            <td><?php echo $row1['EndTime'] ?></td>
                                            <td>  
                                            <a title="Update"   class="btn btn-info edit"><i class="fa fa-edit" style='color:white;'></i></a> 
                                                <a href="controller/timetable_controller.php?TimeTableDelete=<?php echo $row1['KeyCode'] ?>" title="Delete" onclick="return confirm('Are you Sure want to Delete the Timetable?'); " class="btn btn-warning"><i class="fa fa-trash"></i></a></td>
                                            <td style='display:none;'><?php echo $row1['KeyCode']; ?></td>
                                            <td style='display:none;'><?php echo $row1['CourseKeyCode']; ?></td>
                                            <td style='display:none;'><?php echo $row1['BatchKeyCode']; ?></td>
                                            <td style='display:none;'><?php echo $row1['SubjectKeyCode']; ?></td>
                                            <td style='display:none;'><?php echo $row1['FacultyKeyCode']; ?></td>
                                            </tr>
                                      <?php } ?>
                                           
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    
                       
                        <!-- table responsive -->
                       
                    </div>
                </div>

             
            </div>
           
        </div>
      
        <?php include '../footer.html';?>
      
    </div>


    

     <!--model -->
    <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
     <form class="needs-validation" novalidate method='POST' id="assignbatch" action="controller/timetable_controller.php">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel1">Add Time Table</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">

                       
               

               <div class="form-row">                                        
                    <div class="col-md-6 mb-3" id='normalSubDiv'>
                        <label for="add_course">Course</label>
                        <select name="add_course" id="add_course" class='form-control'>
                                <option value="" selected disabled>SELECT COURSE</option>                                                  
                                <?php
                                    $stmt = $admin->get_course();
                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {                                                            
                                ?>
                                 <option value=<?php echo $row["KeyCode"] ?>> <?php echo $row["CourseName"] ?> </option>
                                 <?php } ?>
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Course Name.
                        </div>                                           
                    </div>

                    <div class="col-md-6 mb-3" id='BatchDiv' >
                        <label for="batch_select">Batch Name</label>
                        <select name="batch_select" id="batch_select" class='form-control' required>                                               
                        
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Batch Name.
                        </div>                                           
                    </div> 

                     <div class="col-md-6 mb-3" id='SubjectDiv' >
                        <label for="subject_select">Subject</label>
                        <select name="subject_select" id="subject_select" class='form-control' required>                                               
                        
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Subject.
                        </div>                                           
                    </div> 

                    <div class="col-md-6 mb-3" id='FacultyDiv' >
                        <label for="faculty_select">Faculty</label>
                        <select name="faculty_select" id="faculty_select" class='form-control' required> 

                              <option value="">--SELECT FACULTY--</option>


                                 <?php
                                    $stmt = $admin->get_faculty();
                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
                                    { 
                                ?>
                                 <option value=<?php echo $row["KeyCode"] ?>> <?php echo $row["FacultyName"] ?> </option>
                                 <?php } ?>
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Faculty.
                        </div>                                           
                    </div>


                    <div class="col-md-6 mb-3" id='DayDiv' >
                        <label for="day_select">Day</label>
                        <select name="day_select" id="day_select" class='form-control' required>                                               
                           
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Subject.
                        </div>                                           
                    </div> 

                     <div class="col-md-6">
                    <label for="start_time">Start Time</label>
                    <input class="form-control" name='start_time' id="start_time" placeholder="Start time" required>

                     <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Start Time.
                        </div> 
                   
                   </div>

                    <div class="col-md-6">
                    <label for="end_time">End Time</label>
                    <input class="form-control" name='end_time' id="end_time" placeholder="End time" required>

                     <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select End Time.
                        </div> 
                   
                   </div>

                        </div>
                        <div class="modal-footer" style='margin-top: 23px !important;'>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                           
                            <button class="btn btn-primary" type="submit" name="btntimetableSave">Save Time Table</button>
                        </div>
                    </div>
                </div>
            </div>
                </form>
    </div>

      
     <!--model -->

     <!--model edit starts -->
    <div class="modal" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
     <form class="needs-validation" novalidate method='POST' id="assignbatch1" action="controller/timetable_controller.php">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel">Edit Time Table</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">

                       
               

               <div class="form-row">                                        
                    <div class="col-md-6 mb-3" id='normalSubDiv1'>
                        <label for="edit_course">Course</label>
                        <select name="edit_course" id="edit_course" class='form-control'>
                                <option value="" selected disabled>SELECT COURSE</option>                                                  
                                <?php
                                    $stmt = $admin->get_course();
                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {                                                            
                                ?>
                                 <option value=<?php echo $row["KeyCode"] ?>> <?php echo $row["CourseName"] ?> </option>
                                 <?php } ?>
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Course Name.
                        </div>                                           
                    </div>

                    <div class="col-md-6 mb-3" id='BatchDiv1' >
                        <label for="edit_batch_select">Batch Name</label>
                        <select name="edit_batch_select" id="edit_batch_select" class='form-control' required>                                               
                        
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Batch Name.
                        </div>                                           
                    </div> 

                     <div class="col-md-6 mb-3" id='SubjectDiv1' >
                        <label for="edit_subject_select">Subject</label>
                        <select name="edit_subject_select" id="edit_subject_select" class='form-control' required>                                               
                        
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Subject.
                        </div>                                           
                    </div> 

                    <div class="col-md-6 mb-3" id='FacultyDiv1' >
                        <label for="edit_faculty_select">Faculty</label>
                        <select name="edit_faculty_select" id="edit_faculty_select" class='form-control' required> 

                              <option value="">--SELECT FACULTY--</option>


                                 <?php
                                    $stmt = $admin->get_faculty();
                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
                                    { 
                                ?>
                                 <option value=<?php echo $row["KeyCode"] ?>> <?php echo $row["FacultyName"] ?> </option>
                                 <?php } ?>
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Faculty.
                        </div>                                           
                    </div>


                    <div class="col-md-6 mb-3" id='DayDiv1' >
                        <label for="edit_day_select">Day</label>
                        <select name="edit_day_select" id="edit_day_select" class='form-control' required>                                               
                           
                            </select>
                            <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Subject.
                        </div>                                           
                    </div> 

                     <div class="col-md-6">
                    <label for="edit_start_time">Start Time</label>
                    <input class="form-control" name='edit_start_time' id="edit_start_time" placeholder="Start time" required>

                     <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select Start Time.
                        </div> 
                   
                   </div>

                    <div class="col-md-6">
                    <label for="edit_end_time">End Time</label>
                    <input class="form-control" name='edit_end_time' id="edit_end_time" placeholder="End time" required>

                     <div class="valid-feedback">
                            Looks good!
                          </div>
                        <div class="invalid-feedback">
                            Please Select End Time.
                        </div> 
                   
                   </div>

                   <input type="hidden" name="hiddenKeyCode" id='hiddenKeyCode' value="">

                        </div>
                        <div class="modal-footer" style='margin-top: 23px !important;'>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                           
                            <button class="btn btn-primary" type="submit" value='submit' value='btntimetableEdit' id='btntimetableEdit' name="btntimetableEdit">Update Time Table</button>
                        </div>
                    </div>
                </div>
            </div>
                </form>
    </div>
     <!--model edit ends -->

</body>

<script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
    <!--This page plugins -->
    <script src="assets/node_modules/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="assets/node_modules/datatables.net-bs4/js/dataTables.responsive.min.js"></script>
    <!-- start - This is for export functionality only -->
    <script src="cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
    <!-- end - This is for export functionality only -->

    <!-- Sweet-Alert starts  -->
    <script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <script src="assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
    <!-- sweet alert ends -->

     <!-- Plugin JavaScript -->
    <script src="assets/node_modules/moment/moment.js"></script>
    <script src="assets/node_modules/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
     <script src="assets/node_modules/clockpicker/dist/jquery-clockpicker.min.js"></script>
    <!-- Clock Plugin JavaScript -->
     <script src="assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <!-- Date range Plugin JavaScript -->
    <script src="assets/node_modules/timepicker/bootstrap-timepicker.min.js"></script>
    <script src="assets/node_modules/bootstrap-daterangepicker/daterangepicker.js"></script>
    <script>
        
    $('#start_time').bootstrapMaterialDatePicker({ format: 'HH:mm', time: true, date: false });
    $('#end_time').bootstrapMaterialDatePicker({ format: 'HH:mm', time: true, date: false });
    $('#edit_end_time').bootstrapMaterialDatePicker({ format: 'HH:mm', time: true, date: false });
    $('#edit_start_time').bootstrapMaterialDatePicker({ format: 'HH:mm', time: true, date: false });
   


  
</script>
    <script>
        $(function () {
            $('#myTable').DataTable();
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function (settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;
                    api.column(2, {
                        page: 'current'
                    }).data().each(function (group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group + '</td></tr>');
                            last = group;
                        }
                    });
                }
            });
            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function () {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
            // responsive table
            $('#config-table').DataTable({
                responsive: true
            });
            $('#example23').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel').addClass('btn btn-primary mr-1');
        });

        (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
    


   


    </script>
    <?php $control->sessionMessage(); ?>

    <script>
         $(document).ready(function(){

            //course changes
            $('#add_course').change( function(){
            var course =$(this).val();
            $('#batch_select').empty();
            //alert(course);
                $.ajax({
                    url: "controller/marks_controller.php",
                    type: "POST", //send it through get method
                    data: {course_selected: course},
                    
                    success: function(response) {

                    $('#batch_select').append('<option value="" selected disabled>SELECT BATCH</option>');
                    $('#batch_select').append(response);
                    //Do Something
                    },
                    error: function(result) {        
                     //Do Something to handle error
                    }
                });
            })

            //batch changes
            $('#add_course').change( function(){
            var course =$(this).val();
            $('#subject_select').empty();
            //alert(batch);
                $.ajax({
                    url: "controller/timetable_controller.php",
                    type: "POST", //send it through get method
                    data: {course_selected_subject: course},
                    
                    success: function(response) {
                       // console.log(response)
                    $('#subject_select').append('<option value="" selected disabled>SELECT SUBJECT</option>');
                    $('#subject_select').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                });
            })


             $('#faculty_select').change( function(){
            var faculty =$(this).val();
           
               //alert(batch);
                $.ajax({
                    url: "controller/timetable_controller.php",
                    type: "POST", //send it through get method
                    data: {faculty_selected: faculty},
                    
                    success: function(response) {
                        $('#day_select').empty();
                    
                    $('#day_select').append('<option value="" selected disabled>SELECT DAY</option>');
                    $('#day_select').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                })
            })

             $('.edit').click(function(){
                var KeyCode=$(this).parent().parent().find('td:nth-child(10)').text()
                var CourseKeyCode=$(this).parent().parent().find('td:nth-child(11)').text()
                var BatchKeyCode=$(this).parent().parent().find('td:nth-child(12)').text()
                var SubjectKeyCode=$(this).parent().parent().find('td:nth-child(13)').text()
                var FacultyKeyCode=$(this).parent().parent().find('td:nth-child(14)').text()
                var day=$(this).parent().parent().find('td:nth-child(6)').text()

                 var startTime=$(this).parent().parent().find('td:nth-child(7)').text()
                 var endTime=$(this).parent().parent().find('td:nth-child(8)').text()

                  $.ajax({
                    url: "controller/marks_controller.php",
                    type: "POST", //send it through get method
                    async:false,
                    data: {course_selected: CourseKeyCode},
                    success: function(response) {
                    $('#edit_batch_select').append('<option value="" selected disabled>SELECT BATCH</option>');
                    $('#edit_batch_select').append(response);
                    //Do Something
                    },
                    error: function(result) {        
                     //Do Something to handle error
                    }
                  })

                   $.ajax({
                    url: "controller/timetable_controller.php",
                    type: "POST", //send it through get method
                     async:false,
                    data: {course_selected_subject: CourseKeyCode},
                    
                    success: function(response) {
                       // console.log(response)
                    $('#edit_subject_select').append('<option value="" selected disabled>SELECT SUBJECT</option>');
                    $('#edit_subject_select').append(response)
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                })

                 $.ajax({
                    url: "controller/timetable_controller.php",
                    type: "POST", //send it through get method
                     async:false,
                    data: {faculty_selected: FacultyKeyCode},
                    
                    success: function(response) {
                    $('#edit_day_select').empty();
                    $('#edit_day_select').append('<option value="" selected disabled>SELECT DAY</option>');
                    $('#edit_day_select').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                })   
                   

                  $('#edit_batch_select').val(BatchKeyCode)
                  $('#edit_subject_select').val(SubjectKeyCode)
                  $('#edit_course').val(CourseKeyCode)
                  $('#edit_faculty_select').val(FacultyKeyCode)
                  $('#edit_day_select').val(day)
                  $('#edit_start_time').val(startTime)
                  $('#edit_end_time').val(endTime)
                  $('#hiddenKeyCode').val(KeyCode)

                  $('#exampleModal1').modal('show')

             })

             // $('#btntimetableEdit').click(function(){
             //      var BatchKeyCode =$('#edit_batch_select').val()
             //      var SubjectKeyCode =$('#edit_subject_select').val()
             //      var CourseKeyCode =$('#edit_course').val()
             //      var FacultyKeyCode=$('#edit_faculty_select').val()
             //      var day=$('#edit_day_select').val()
             //      var startTime =$('#edit_start_time').val()
             //      var endTime=$('#edit_end_time').val()
             //      var edit_keycode_selected=$('#hiddenKeyCode').val()

             //     $.ajax({
             //        url: "controller/timetable_controller.php",
             //        type: "POST", //send it through get method
             //        data: {edit_keycode_selected: edit_keycode_selected,CourseKeyCode:CourseKeyCode,BatchKeyCode:BatchKeyCode,SubjectKeyCode:SubjectKeyCode,FacultyKeyCode:FacultyKeyCode,Day:day,startTime:startTime,endTime:endTime},
                    
             //        success: function(response) {
             //            alerts(response)
             //            if(response == 'true')
             //            {
             //                 Swal.fire({
             //                    type: 'success',
             //                    title: 'Succeesully Updated',
             //                    showConfirmButton: false,
             //                    timer: 3000
             //                    })
             //            }
             //            else if(response == 'false1')
             //            {
             //                Swal.fire({
             //                    type: 'error',
             //                    title: 'Something went Wrong',
             //                    showConfirmButton: false,
             //                    timer: 3000
             //                    })
             //            }
             //            else if(response == 'false2')
             //            {
             //               Swal.fire({
             //                    type: 'warning',
             //                    title: 'This Time is Already Assign To Different Batch  On this day',
             //                    showConfirmButton: false,
             //                    timer: 3000
             //                    }) 
             //            }

             //            else if(response == 'false3')
             //            {
             //                Swal.fire({
             //                    type: 'warning',
             //                    title: 'This Time is Already Assign To Different Faculty  On this day',
             //                    showConfirmButton: false,
             //                    timer: 3000
             //                    })
             //            }
             //            else
             //            {
             //                Swal.fire({
             //                    type: 'error',
             //                    title: 'Something went Wrong',
             //                    showConfirmButton: false,
             //                    timer: 3000
             //                    })
             //            }
                        
             //        //Do Something
             //        },
             //        error: function(result) {                     
             //            //Do Something to handle error
             //             Swal.fire({
             //                    type: 'error',
             //                    title: 'Something went Wrong',
             //                    showConfirmButton: false,
             //                    timer: 3000
             //            })

             //        }
             //    });
             // })



             //EDIT SATRTS

              //course changes
            $('#edit_course').change( function(){
            var course =$(this).val();
            $('#edit_batch_select').empty();
            //alert(course);
                $.ajax({
                    url: "controller/marks_controller.php",
                    type: "POST", //send it through get method
                    data: {course_selected: course},
                    
                    success: function(response) {

                    $('#edit_batch_select').append('<option value="" selected disabled>SELECT BATCH</option>');
                    $('#edit_batch_select').append(response);
                    //Do Something
                    },
                    error: function(result) {        
                     //Do Something to handle error
                    }
                });
            })

            //batch changes
            $('#edit_course').change( function(){
            var course =$(this).val();
            $('#edit_subject_select').empty();
            //alert(batch);
                $.ajax({
                    url: "controller/timetable_controller.php",
                    type: "POST", //send it through get method
                    data: {course_selected_subject: course},
                    
                    success: function(response) {
                       // console.log(response)
                    $('#edit_subject_select').append('<option value="" selected disabled>SELECT SUBJECT</option>');
                    $('#edit_subject_select').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                });
            })


             $('#edit_faculty_select').change( function(){
            var faculty =$(this).val();
           
               //alert(batch);
                $.ajax({
                    url: "controller/timetable_controller.php",
                    type: "POST", //send it through get method
                    data: {faculty_selected: faculty},
                    
                    success: function(response) {
                    $('#edit_day_select').empty();
                    $('#edit_day_select').append('<option value="" selected disabled>SELECT DAY</option>');
                    $('#edit_day_select').append(response);
                    //Do Something
                    },
                    error: function(result) {                     
                        //Do Something to handle error
                    }
                })
            })


             //EDIT ENDS

        }) //Doc Ends
    </script>


</html>