<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();
?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/table-data-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:23 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>MNTC || View Payment</title>
    <!-- This Page CSS -->
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css"
        href="assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- sweet alert starts -->
    <link href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- sweet alert ends -->
</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">View Payment Details</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            
                           
                         <button type="button" class="btn btn-info" id='btnCreteNew'><i class="fa fa-plus-circle"></i> Create New</button>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"></h4>
                               
                                <div class="table-responsive m-t-40">
                                    <table id="example23"
                                        class="display nowrap table table-hover table-striped table-bordered"
                                        cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sl No</th>
                                                <th>Student Name</th>
                                                <th>Batch Name</th>
                                                <th>Paid Amount</th>
                                                <th>Balance Amount</th>
                                                <th>Details</th>
                                                <th>Action</th>  
                                                <th style='display:none;'>key</th>
                                                 <th style='display:none;'>key</th>
                                            </tr>
                                        </thead>                                        
                                        <tbody>
                                        <?php
                                        $stmt = $admin->get_payment();
                                        $i=1;
                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                            ?>
                                            <tr>
                                            <td> <?php echo $i++; ?></td>
                                            <td><?php echo $row['StudentName']; ?></td>
                                            <td><?php echo $row['BatchName']; ?></td>
                                            <td><?php echo $row['PaidAmount'].".00"; ?></td>
                                            <td><?php echo $row['BalanceAmount'].".00"; ?></td>                                                        
                                            <td><a title="Generate Receipt" class="btn btn-warning generate">Generate Receipt</a></td>
                                          <td> <a href="controller/student_controller.php?delete_student_id=<?php echo $row['KeyCode'] ?>" title="Delete" onclick="return confirm('Are you Sure want to Delete the Student'); " class="btn btn-warning"><i class="fa fa-trash"></i></a></td>
                                            
                                            <td style='display:none;'><?php echo $row['KeyCode']; ?></td>
                                            <td style='display:none;'><?php echo $row['StudentKeyCode']; ?></td>   
                                        </tr>
                                        <?php }?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>                        
                        
                        <!-- table responsive -->
                       
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                        <form class="needs-validation" novalidate method='POST' action="controller/subject_controller.php">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">  
                                                                         
                                            <div class="modal-body" id='printThis' style='padding:5px;' > <div style='border:2px solid black;padding:30px;'>      

                                            <div class='row' style='font-size:35px;'>
                                            <div class='col-md-12'n style='text-align: center;font-weight:500;font-variant:petite-caps'>M N Traing Centre</div>                                            
                                            </div>     
                                            <div class='row' style='font-size:20px;'>
                                            <div class='col-md-12'n style='text-align: center;'>Madanthyar, Belthangady (tq),D.K.,Karnataka - 574228<br>
                                            Mob : 9988776655</div>                                            
                                            </div> <br>
                                            <div class='row'>
                                            <div class='col-md-4' style='font-weight:500;font-size:25px;' id='invoice_no'></div>
                                            <div class='col-md-4' style='text-align: center;font-weight:500;font-size:30px;'><u> RECEIPT </u></div>
                                            <div class='col-md-4' id='current_date' style='font-weight:500;font-size:25px;text-align: right;'></div>
                                            </div><br>
                                               <div class='row'>
                                               <div class='col-md-2' style='font-size:25px;'>Name</div>
                                               <div class='col-md-10' id='std_name' style='font-size:25px;text-align: center;border-bottom:1px dotted black;'></div>     
                                               </div> <br>
                                               <div class='row'>
                                               <div class='col-md-2' style='font-size:25px;'>Roll No </div>
                                               <div class='col-md-4' style='font-size:22px;text-align: center;border-bottom:1px dotted black;' id='rollNo'></div>   
                                               <div class='col-md-2' style='font-size:25px;'>Phone No </div>
                                               <div class='col-md-4' style='font-size:25px;border-bottom:1px dotted black;' id='phone'></div>       
                                               </div> <br>
                                               <div class='row'>
                                               <div class='col-md-2' style='font-size:25px;'>Course</div>
                                               <div class='col-md-10' style='font-size:25px;border-bottom:1px dotted black;' id='course'></div>     
                                               </div> <br>
                                               <div class='row'>
                                               <div class='col-md-4' style='font-size:25px;'>Amount in words </div>
                                               <div class='col-md-8' style='font-size:25px;border-bottom:1px dotted black;' id='amt_word'></div>     
                                               </div> <br><br><br><br>
                                               <div class='row'>                                              
                                               <div class='col-md-3' style='font-size:25px;border:1px solid black;' id='paid_amt'>&#8377;</div><div class='col-md-7'></div>   
                                               <div class='col-md-2' style='font-size:25px;border-top:1px dotted black;text-align:right'>Signature</div>       
                                               </div> <br>
                                               </div>                           
                                           </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal" id='add_close'>Close</button>
                                               
                                                <button class="btn btn-primary" type="submit" name='subject_save'>Save</button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
    <!--This page plugins -->
    <script src="assets/node_modules/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="assets/node_modules/datatables.net-bs4/js/dataTables.responsive.min.js"></script>
    <!-- start - This is for export functionality only -->
    <script src="cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script src="cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
    <!-- end - This is for export functionality only -->

    <!-- Sweet-Alert starts  -->
    <script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <script src="assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
    <!-- sweet alert ends -->

    <?php $control->sessionMessage(); ?>

    <script>
        $(function () {
            $('#myTable').DataTable();
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function (settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;
                    api.column(2, {
                        page: 'current'
                    }).data().each(function (group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group + '</td></tr>');
                            last = group;
                        }
                    });
                }
            });
            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function () {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
            // responsive table
            $('#config-table').DataTable({
                responsive: true
            });
            $('#example23').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel').addClass('btn btn-primary mr-1');
        });

        (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();

    </script>

    <script>
        $(document).ready(function(){

            var a = ['', 'One ', 'Two ', 'Three ', 'Four ', 'Five ', 'Six ', 'Seven ', 'Eight ', 'Nine ', 'Ten ', 'eleven ', 'twelve ', 'thirteen ', 'fourteen ', 'fifteen ', 'sixteen ', 'seventeen ', 'eighteen ', 'nineteen '];
            var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

            $('#add_close').click(function(){
                $('#S_Code').val('');
                $('#S_Name').val('');
            });
            $('.close').click(function(){
                $('#S_Code').val('');
                $('#S_Name').val('');
            });

            $('#btnCreteNew').click(function(){
                window.open('GenerateReceipt.php','_self');
            });

            //print receipt
            $('#example23 tbody tr').on('click','td:nth-child(6) .generate',function(){
                var result=confirm('Are You sure want to print the receipt');
                if(result)
                {
                    var Key=$(this).parent().parent().find('td:nth-child(7)').text();
                    var student_name=$(this).parent().parent().find('td:nth-child(2)').text();
                    var paid=$(this).parent().parent().find('td:nth-child(4)').text();
                    var std_key=$(this).parent().parent().find('td:nth-child(9)').text();
                    //alert(student_name);
                    $('#std_name').text(student_name);
                    $('#paid_amt').append(' '+paid + '/-');
                    $('#invoice_no').text('NO : 2020' + Key);
                    $.ajax({
                        url: "controller/receipt_controller.php",
                        type: "POST", //send it through get method
                        async:false,
                        dataType : "json",
                        data: {student_key: std_key},                    
                        success: function(response) {
                            console.log(response);
                            $('#rollNo').text(response.RegisterNo);
                            $('#phone').text(response.PhoneNumber);
                            $('#course').text(response.CourseName);
                        // $('#batch_select').append('<option value="" selected disabled>SELECT BATCH</option>');
                        // $('#batch_select').append(response);
                        //Do Something
                        },
                        error: function(result) {                     
                            //Do Something to handle error
                        }
                    });
                    inWords(parseInt(paid));
                    //$('#exampleModal').modal('show');
                     printModal();
                }else{
                    return false;
                }               
            });

            function inWords(num) {
                if ((num = num.toString()).length > 9) return 'overflow';
                n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
                if (!n) return;
                var str = '';
                str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
                str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
                str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
                str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
                str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + '' : '';
                $('#amt_word').text(str + 'Only')
            }

            function printModal()
            {
                var headstr = "<html><head><title></title></head><body>";
                var footstr = "</body>";
                var newstr = document.all.item('printThis').innerHTML;
                var oldstr = document.body.innerHTML;
                document.body.innerHTML=headstr + newstr + footstr;
                window.print();
                document.body.innerHTML = oldstr;
                location.reload('true');
                return false;
            }

            var d = new Date();
            var month = d.getMonth()+1;
            var day = d.getDate();
            var output = ((''+day).length<2 ? '0' : '') + day + '/' +((''+month).length<2 ? '0' : '') + month + '/' +d.getFullYear();

            $('#current_date').text("Date :" + output);
        });
    </script>
</body>
</html>