<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();

$id = $_GET['id'];
$res = $admin->getStudentID_H($id);



?>


<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/form-bootstrap-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:06 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>MNTC || Edit Student</title>
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">

    <!-- sweet alert starts -->
    <link href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    
    <link href="bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!-- <link href="select2.min.css" rel="stylesheet" type="text/css" media="all" /> -->

    <link href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <style>
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
    background-color: #e4e4e4;
    border: 1px solid #aaa;
    border-radius: 4px;
    cursor: default;
    float: left;
    margin-right: 5px;
    margin-top: 5px;
    padding: 0 5px;
    color: black;
}

.select2-container {
    box-sizing: border-box;
    display: inline-block;
    margin: 0;
    position: relative;
    vertical-align: middle;
    width:100% !important;
}
    </style>

   

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
   
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Edit Student</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                           
                            <button type="button" id='btnViewStudent' class="btn btn-info d-none d-lg-block m-l-15"> View Student</button>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                
                                <form class="needs-validation" method='POST' action='controller/student_controller.php' novalidate>
                                    <div class="form-row">
                                        <div class="col-md-4 mb-3">
                                            <label for="validationCustom01">Register No.</label>
                                            <input type="text" class="form-control" id='validationCustom01' name="reg_no" placeholder="Register No."  value='<?php echo $res['RegisterNo'] ?>' required>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>

                                            <div class="invalid-feedback">
                                                Please enter Register N.
                                            </div>

                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="validationCustom02">Student Name</label>
                                            <input type="text" class="form-control" id='validationCustom02' name="std_name" placeholder="Student Name" value='<?php echo $res['StudentName'] ?>'  required>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please enter Student Name..
                                            </div>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="joindate">Date Of Birth</label>
                                            <input type="date" class="form-control" id='dob' name="dob"  value='<?php echo $res['DateOfBirth'] ?>' required>
                                            
                                                <div class="invalid-feedback">
                                                    Choose DOB.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>


                                        <div class="col-md-4 mb-3">
                                            <label for="std_gender">Gender</label>
                                            <select name="std_gender" id="std_gender" class='form-control' required>
                                                  
                                                     <option value="male"  <?php if($res["Gender"]=='male') echo 'selected' ?> >Male</option>
                                                     <option value="female" <?php if($res["Gender"]=='female') echo 'selected' ?> >Female</option>
                                                </select>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please choose Gender..
                                            </div>

                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="validationCustomUsername">Phone No</label>
                                            <input type="text" class="form-control" id='validationCustomUsername' name="phone_no" placeholder="Phone No"  value='<?php echo $res['PhoneNumber'] ?>'  required>
                                                <div class="invalid-feedback">
                                                    Choose Phone No.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="email">Emai</label>
                                            <input type="email" class="form-control" id='email' name="email" placeholder="Email" value='<?php echo $res['Email'] ?>'  required>
                                                <div class="invalid-feedback">
                                                    Choose Email.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="address">Address</label>
                                            <input type="text" class="form-control" id='address' name="address" placeholder="Address"  value='<?php echo $res['Address'] ?>' required>
                                                <div class="invalid-feedback">
                                                    Choose Address.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="qualification">Qualification</label>
                                            <select name="qualification" id="qualification"  class='form-control'  required>
                                            <option value="" selected disabled>SELECT QUALIFICATION</option>
                                                  
                                            <?php
                                                        $stmt = $admin->get_qualification();
                                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                            if($row["KeyCode"]==$res['QualificationKeyCode'])
                                                            {
                                                            
                                                    ?>
                                                      <option value=<?php echo $row["KeyCode"]  ?> selected> <?php echo $row["Qualification"] ?> </option>
                                            <?php } else { ?>
                                                <option value=<?php echo $row["KeyCode"]  ?> > <?php echo $row["Qualification"] ?> </option>
                                            <?php }} ?>
                                             </select>
                                            
                                                <div class="invalid-feedback">
                                                    Choose Qualification.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="course">Course Type</label>
                                            <select name="course_type" id="course_type"  class='form-control'  required>
                                                     <option value="Shorterm" <?php if($res["CourseType"]=='Shorterm') echo 'selected' ?> >Shorterm Course</option>
                                                     <option value="Diploma" <?php if($res["CourseType"]=='Diploma') echo 'selected' ?> >Diploma Course</option>
                                             </select>
                                            
                                                <div class="invalid-feedback">
                                                    Choose Course.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>




                                        <div class="col-md-4 mb-3" id='normalCourseDiv'>
                                            <label for="normal_course">Course</label>
                                            <select name="normal_course" id="normal_course" class='form-control'>
                                                    <option value="" selected disabled>SELECT COURSE</option>

                                                  
                                                    <?php
                                                        $stmt = $admin->get_course_diploma();
                                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                            
                                                    ?>
                                                     <?php if(($row["KeyCode"] == $res['CourseKeyCode']) &&  $res['CourseType']=='Diploma')
                                                     {
                                                      ?>
                                                     <option value='<?php echo $row["KeyCode"] ?>' <?php echo 'selected' ?> > <?php echo $row["CourseName"] ?> </option>
                                                     <?php }else { ?>
                                                    
                                                        <option value=<?php echo $row["KeyCode"] ?> > <?php echo $row["CourseName"] ?> </option>
                                                     <?php } ?>
                                                    
                                                     <?php } ?>

                                                </select>
                                            <div class="invalid-feedback">
                                                Please provide Subject.
                                            </div>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                        </div>

                                        <div class="col-md-4 mb-3" id='Select2CourseDiv' >
                                            <label for="CourseSelect2">Course</label>
                                            <select name="CourseSelect2[]" id="CourseSelect2" class='form-control' multiple>
                                               
                                            <?php
                                                        $stmt = $admin->get_course_shorterm();
                                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                            
                                                    ?>

                                                    <?php $courseKeyArray=explode(",",$res['CourseKeyCode']); 
                                                    $isSelected='';
                                                    foreach($courseKeyArray as $s)
                                                    {
                                                        if(($s==$row["KeyCode"]) && $res['CourseType']=='Shorterm')
                                                        {
                                                            $isSelected ='selected';
                                                            break;
                                                        } 
                                                    }
                                                    ?>

                                                     <option value=<?php echo $row["KeyCode"] ?> <?php echo $isSelected ?> > <?php echo $row["CourseName"] ?> </option>
                                                     <?php } ?>
                                                </select>
                                            <div class="invalid-feedback">
                                                Please provide Subject.
                                            </div>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                        </div>


                                        <div class="col-md-4 mb-3">
                                            <label for="fees">Fees</label>
                                            <input type="text"  class="form-control" id='fees' name="fees" placeholder="Fees Amount" value='<?php echo $res['Fees'] ?>'  readonly required>
                                            
                                                <div class="invalid-feedback">
                                                    Choose Fees..
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="joindate">Join Date</label>
                                            <input type="date" class="form-control" id='joindate' name="joindate" value='<?php echo $res['JoinDate'] ?>'  required>
                                            
                                                <div class="invalid-feedback">
                                                    Choose Join Date.
                                                </div>
                                                <div class="valid-feedback">
                                                Looks good!
                                              </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name='keycode' value="<?php echo $res['KeyCode'] ?>">
                                   
                                    <button class="btn btn-primary" name='edit_student' type="submit">Update Student</button>
                                </form>
                                <script>
                                // Example starter JavaScript for disabling form submissions if there are invalid fields
                                (function() {
                                    'use strict';
                                    window.addEventListener('load', function() {
                                        // Fetch all the forms we want to apply custom Bootstrap validation styles to
                                        var forms = document.getElementsByClassName('needs-validation');
                                        // Loop over them and prevent submission
                                        var validation = Array.prototype.filter.call(forms, function(form) {
                                            form.addEventListener('submit', function(event) {
                                                if (form.checkValidity() === false) {
                                                    event.preventDefault();
                                                    event.stopPropagation();
                                                }
                                                form.classList.add('was-validated');
                                            }, false);
                                        });
                                    }, false);
                                })();
                                </script>
                            </div>
                        </div>
                    </div>
                    
                </div>

                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>

    <!-- Sweet-Alert starts  -->
    <script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
    <script src="assets/node_modules/sweetalert2/sweet-alert.init.js"></script>
    <!-- sweet alert ends -->

 <script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js"></script>

  
<!-- 
    <script type="text/javascript" src='select2.min.js'></script> 
    <script src="bootstrap.min.js"></script> -->

    <?php $control->sessionMessage(); ?>


    <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
    </script>

    <script>
        $(document).ready(function(){
            $('#course_type').change(function(){
               var courseValue=$(this).val()
               if(courseValue =='Shorterm')
               {
                   $('#Select2CourseDiv').show()
                   $('#normalCourseDiv').hide()
                   $('#normal_course').val('');
                   $('#fees').val('');
               }
               else
               {
                   $('#Select2CourseDiv').hide()
                   $('#normalCourseDiv').show()
                   $('#CourseSelect2').val(null).trigger('change');
                   $('#fees').val('');
                   
               }
            })

            $('#CourseSelect2').select2({
            placeholder: "SELECT COURSES"
            
          }).change(function () {
            var selectedIDs = $.map($('#CourseSelect2').select2('data'), function (val, i) {
              return val.id;
            }).join(",");
         //   $('#selectedIDs').text(selectedIDs);
          });

            // $('#Select2CourseDiv').show()
            // $('#normalCourseDiv').hide()
            $('#btnViewCourse').click(function(){
                window.open('ViewCourse.php'); 
            })

            $('#normal_course').change(function (){

                var courseValue=$(this).val()
               
                $.ajax({
                    url: "controller/student_controller.php",
                    type: "POST", //send it through get method
                    data: {course_selected_normal: courseValue},
                    
                    success: function(response) {
                     $('#fees').val('');    
                    $('#fees').val(response);
                    //Do Something
                    },
                    error: function(result) {  
                        alert(result)                   
                        //Do Something to handle error
                    }
                });

            })
            
            $('#CourseSelect2').on("select2:select", function(e) { 
                var fees=0;
                $('#fees').val(''); 
                var subs =$(this).val()+'';
                var myarr = subs.split(",");
               
                
                 for(i=0;i<myarr.length;i++)
                 {
                     
                     var courseValue=myarr[i];
                    $.ajax({
                    url: "controller/student_controller.php",
                    async:false,
                    type: "POST", //send it through get method
                    data: {course_selected_normal: courseValue},
                    
                    success: function(response) {
                       
                       fees = parseFloat(fees) + parseFloat(response);
                    //Do Something
                    },
                    error: function(result) {  
                              
                        //Do Something to handle error
                    }
                });
            }
           
            if(isNaN(fees))
             {
                $('#fees').val(0);
             }
             else{
                $('#fees').val(fees);  
             }

            });

            $('#CourseSelect2').on('select2:unselect', function (e) {
                var fees=0;
                $('#fees').val(''); 
                var subs =$(this).val()+'';
                var myarr = subs.split(",");
               
                
                 for(i=0;i<myarr.length;i++)
                 {
                     
                     var courseValue=myarr[i];
                    $.ajax({
                    url: "controller/student_controller.php",
                    async:false,
                    type: "POST", //send it through get method
                    data: {course_selected_normal: courseValue},
                    
                    success: function(response) {
                       
                       fees = parseFloat(fees) + parseFloat(response);
                    //Do Something
                    },
                    error: function(result) {  
                              
                        //Do Something to handle error
                    }
                });
            }

             if(isNaN(fees))
             {
                $('#fees').val(0);
             }
             else{
                $('#fees').val(fees);  
             }
          
            });

            $('#btnViewStudent').click(function(){
                window.open('ViewStudent.php','_self');
              
            })


        }) //Doc End
    </script>

<?php 
                        if($res['CourseType'] =='Shorterm')
                        {
                        
                            echo "<script>  $('#Select2CourseDiv').show(); $('#normalCourseDiv').hide(); </script>";
                        }
                        else
                        {
                        echo "<script>  $('#normalCourseDiv').show(); $('#Select2CourseDiv').hide(); </script>";
                        }
                    ?>


</body>


<!-- Mirrored from eliteadmin.themedesigner.in/demos/bt4/inverse/form-bootstrap-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Mar 2020 02:42:06 GMT -->
</html>