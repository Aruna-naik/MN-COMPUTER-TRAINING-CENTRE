<?php

define('DIR', '../');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->notLogged('admin', '../index');
$admin = new Admin();

$id = $_GET['keycode'];
$res = $admin->getStudentID_H($id);

?>




<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon.png"> 
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <title>MNTC || View Student Profile</title>
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <style type="text/css">
        b, strong {
                font-weight: bolder;
                font-variant: petite-caps;
                font-weight: bold;
                font-size: 14px;
                font-family: verdana;
            }
    </style>

</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
 
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include '../header.html';?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
         <?php include '../nav.html';?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Student Profile</h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                         
                            <button type="button" id='btnCreteNew' class="btn btn-info d-none d-lg-block m-l-15"> Add New Student</button>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30"> 
                                    <h3 class="card-title  m-t-10" style='font-variant: petite-caps;'><?php echo $res['StudentName'] ?></h3>
                                    <h6 class="card-subtitle">Roll No: <?php echo $res['RegisterNo'] ?></h6>
                                    <div class="row text-center justify-content-md-center">
                                      
                                    </div>
                                </center>
                            </div>
                            <div>
                                <hr> </div>
                            <div class="card-body"> <small class="text-muted" style='color: #33a5f9 !important;'>Email address </small>
                                <h6><?php echo $res['Email'] ?></h6> <small class="text-muted p-t-30 db" style='color: #33a5f9 !important;'>Phone</small>
                                <h6><?php echo $res['PhoneNumber'] ?></h6> <small class="text-muted p-t-30 db" style='color: #33a5f9 !important;'>Address</small>
                                <h6><?php echo $res['Address'] ?></h6>
                                
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Details</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Marks</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Settings</a> </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                     <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Register No.</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['RegisterNo'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Full Name</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['StudentName'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Date Of Birth</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['DateOfBirth'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6"> <strong>Gender</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['Gender'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Phone Number</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['PhoneNumber'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Email</strong>
                                                <br>
                                                <p class="text-muted"> <?php echo $res['Email'] ?> </p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Address</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['Address'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6"> <strong>Qualification</strong>
                                                <br>

                                                 <?php
                                                        $stmt = $admin->get_qualification();
                                                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                          if($row["KeyCode"]==$res['QualificationKeyCode'])
                                                            {
                                                            
                                                           ?>

                                                <p class="text-muted"><?php echo $row["Qualification"] ?></p>
                                            <?php }}  ?>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Course Type</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['CourseType'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Course</strong>
                                                <br>
                                                <?php 
                                                $courseName='';
                                                $courseKey=$res['CourseKeyCode'];
                                                $courseKeyArray=explode(",",$courseKey);
                                                foreach($courseKeyArray as $s)
                                                {
                                                    $stmtCourse = $admin->get_course_by_id($s);
                                                    while ($row1 = $stmtCourse->fetch(PDO::FETCH_ASSOC)) {
                                                        $courseName=$courseName.$row1['CourseName']."   , ";
                                                    }
                                                }
                                            ?>

                                                <p class="text-muted"><?php echo $courseName ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6 b-r"> <strong>Fees</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['Fees'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6"> <strong>Join Date </strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['JoinDate'] ?></p>
                                            </div>
                                            <div class="col-md-4 col-xs-6"> <strong>Student Registered On</strong>
                                                <br>
                                                <p class="text-muted"><?php echo $res['SavedDate'] ?></p>
                                            </div>
                                        </div>
                                        <hr>
                                       
                                       
                                    </div>
                                </div>
                                <!--second tab-->
                                <div class="tab-pane" id="profile" role="tabpanel">
                                    <div class="card-body">

                                        <?php 
                                            $courseName='';
                                            $courseKey=$res['CourseKeyCode'];
                                            $courseKeyArray=explode(",",$courseKey);
                                            foreach($courseKeyArray as $s)
                                            {
                                                $stmtCourse = $admin->get_course_by_id($s);
                                                while ($row1 = $stmtCourse->fetch(PDO::FETCH_ASSOC)) {

                                                    $keycode =$s;

                                                    $stmtSubject = $admin->get_marks_student_course_by_id($s,$id);


                                                  
                                               
                                        ?>

                                        
                                        
                                      
                                       <div class='col-md-12'>
                                            <h4 class="font-medium m-t-30" style='margin-top: 10px;'><?php echo $row1['CourseName'] ?></h4>

                                             <?php 
                                              $totmarks = 0;
                                              $finMarks = 0;
                                             while ($row2 = $stmtSubject->fetch(PDO::FETCH_ASSOC)) {
                                               
                                                $totmarks = $totmarks + $row2['Mark'];
                                                $finMarks +=100;


                                            ?>

                                           
                                            
                                            <h5 class="m-t-30" style='margin-top: 13px;'><?php echo $row2['SubjectName'] ?>
                                            <span class="pull-right"> <?php echo $row2['Mark'] ?> / 100</span>    
                                            </h5>
                                            

                                            <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $row2['Mark']?>%; height:6px;"> </div>
                                            </div>



                                        <?php } ?>

                                         <h5 class="m-t-30" style='margin-top: 13px;font-size: 18px;font-weight: 600;;'>Total Marks : 
                                           <span class="pull-right"><?php echo  $totmarks.' / '.$finMarks ?></span> 
                                            </h5>


                                           
                                          


                                           <!--  <h5 class="m-t-30"   style='margin-top: 13px;'>HTML 5 </h5>
                                            <div class="progress">
                                                <div class="progress-bar bg-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width:100%; height:6px;">  </div>
                                            </div>
                                            <h5 class="m-t-30"  style='margin-top: 13px;'>jQuery</h5>
                                            <div class="progress">
                                                <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:100%; height:6px;">  </div>
                                            </div>
                                            <h5 class="m-t-30" style='margin-top: 13px;'>Photoshop</h5>
                                            <div class="progress">
                                                <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:100%; height:6px;"> </div>
                                            </div> -->
                                        </div>
                                        <hr>

                                    <?php }} ?>


                                    </div>
                                </div>
                            



                                <div class="tab-pane" id="settings" role="tabpanel">
                                    <div class="card-body">
                                        
                                        <?php 
                                            $courseName='';
                                            $courseKey=$res['CourseKeyCode'];
                                            $courseKeyArray=explode(",",$courseKey);
                                            foreach($courseKeyArray as $s)
                                            {
                                                $stmtCourse = $admin->get_course_by_id($s);
                                                while ($row1 = $stmtCourse->fetch(PDO::FETCH_ASSOC)) {

                                                    $keycode =$s;

                                                    $stmtSubject = $admin->get_student_attendencePRO($id,$s);


                                                  
                                               
                                        ?>

                                        
                                        
                                      
                                       <div class='col-md-12'>
                                            <h4 class="font-medium m-t-30" style='margin-top: 10px;'><?php echo $row1['CourseName'] ?></h4>

                                             <?php 
                                              $PresentCount = 0;
                                              $finMarks = 0;
                                             while ($row2 = $stmtSubject->fetch(PDO::FETCH_ASSOC)) {
                                               
                                                $PresentCount = $totmarks + $row2['PresentCount'];
                                               // $finMarks +=100;


                                            ?>

                                           
                                            
                                            <h5 class="m-t-30" style='margin-top: 13px;'><?php echo $row2['SubjectName'] ?>
                                            <span class="pull-right"> <?php echo $row2['PresentCount'] ?> / <?php echo $row2['PresentCount']+ $row2['AbsentCount'] ?></span>    
                                            </h5>
                                            

                                            <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $row2['Mark']?>%; height:6px;"> </div>
                                            </div>



                                        <?php } ?>

                                         <h5 class="m-t-30" style='margin-top: 13px;font-size: 18px;font-weight: 600;;'>Total Marks : 
                                           <span class="pull-right"><?php echo  $totmarks.' / '.$finMarks ?></span> 
                                            </h5>


                                           
                                          


                                           
                                        </div>
                                        <hr>

                                    <?php }} ?>
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
               
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php include '../footer.html';?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/node_modules/popper/popper.min.js"></script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>

      <script>
        $(document).ready(function(){
          

            $('#btnCreteNew').click(function(){
                window.open('AddStudent.php','_self'); 
               
            })
        });
    </script>

</body>

</html>