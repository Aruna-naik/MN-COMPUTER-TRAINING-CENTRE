-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2020 at 08:12 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mnct`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `KeyCode` int(50) NOT NULL,
  `UserName` varchar(250) NOT NULL,
  `Password` varchar(250) NOT NULL,
  `PhoneNumber` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`KeyCode`, `UserName`, `Password`, `PhoneNumber`) VALUES
(1, 'admin', 'admin', 9481671193);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assignstudent`
--

CREATE TABLE `tbl_assignstudent` (
  `KeyCode` int(50) NOT NULL,
  `StudentKeyCode` int(50) NOT NULL,
  `BatchKeyCode` int(50) NOT NULL,
  `CourseKeyCode` int(50) NOT NULL,
  `SavedDate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_assignstudent`
--

INSERT INTO `tbl_assignstudent` (`KeyCode`, `StudentKeyCode`, `BatchKeyCode`, `CourseKeyCode`, `SavedDate`) VALUES
(1, 5, 3, 1, 0),
(2, 6, 3, 1, 0),
(3, 1, 7, 5, 0),
(4, 2, 7, 5, 0),
(5, 3, 8, 5, 0),
(6, 4, 8, 5, 0),
(7, 2, 1, 2, 0),
(8, 3, 1, 2, 0),
(9, 4, 1, 2, 0),
(10, 1, 4, 3, 0),
(11, 3, 4, 3, 0),
(12, 4, 5, 3, 0),
(13, 7, 6, 4, 0),
(14, 8, 6, 4, 0),
(15, 9, 9, 6, 0),
(16, 10, 9, 6, 0),
(17, 11, 9, 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_batch`
--

CREATE TABLE `tbl_batch` (
  `KeyCode` int(50) NOT NULL,
  `CourseKeyCode` int(50) NOT NULL,
  `BatchName` varchar(250) NOT NULL,
  `SavedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_batch`
--

INSERT INTO `tbl_batch` (`KeyCode`, `CourseKeyCode`, `BatchName`, `SavedDate`) VALUES
(1, 2, 'A', '2020-06-21 11:41:04'),
(2, 2, 'B', '2020-06-21 11:41:17'),
(3, 1, 'A', '2020-06-21 11:41:30'),
(4, 3, 'A', '2020-06-21 11:41:47'),
(5, 3, 'B', '2020-06-21 11:41:57'),
(6, 4, 'A', '2020-06-21 11:42:09'),
(7, 5, 'A', '2020-06-21 11:42:26'),
(8, 5, 'B', '2020-06-21 11:42:39'),
(9, 6, 'A', '2020-06-21 11:43:16'),
(10, 6, 'B', '2020-06-21 11:43:26'),
(11, 6, 'C', '2020-06-21 11:43:38');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE `tbl_course` (
  `KeyCode` int(50) NOT NULL,
  `CourseCode` varchar(250) NOT NULL,
  `CourseName` varchar(250) NOT NULL,
  `CourseType` varchar(250) NOT NULL,
  `CourseDuration` varchar(250) NOT NULL,
  `Fees` double NOT NULL,
  `SubjectKeyCode` varchar(100) NOT NULL,
  `SavedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`KeyCode`, `CourseCode`, `CourseName`, `CourseType`, `CourseDuration`, `Fees`, `SubjectKeyCode`, `SavedDate`) VALUES
(1, 'CO01', 'BSA', 'Diploma', '2year', 50000, '1,2', '2020-06-21 11:34:53'),
(2, 'CO02', 'JAVA', 'Shorterm', '3month', 5000, '1', '2020-06-21 11:35:34'),
(3, 'CO03', 'GAME', 'Shorterm', '6month', 5000, '2', '2020-06-21 11:36:56'),
(4, 'CO04', 'BA', 'Diploma', '1year', 50000, '4,6', '2020-06-21 11:37:56'),
(5, 'CO05', 'WEB', 'Shorterm', '6month', 6000, '4', '2020-06-21 11:39:05'),
(6, 'CO06', 'BBM', 'Diploma', '2year', 70000, '2,4,6', '2020-06-21 11:40:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faculty`
--

CREATE TABLE `tbl_faculty` (
  `KeyCode` int(11) NOT NULL,
  `FacultyCode` varchar(250) NOT NULL,
  `FacultyName` varchar(250) NOT NULL,
  `FacultyType` varchar(250) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Gender` varchar(250) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Available` varchar(250) NOT NULL,
  `Salary` double NOT NULL,
  `PhoneNumber` bigint(20) NOT NULL,
  `JoiningDate` date NOT NULL,
  `SavedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_faculty`
--

INSERT INTO `tbl_faculty` (`KeyCode`, `FacultyCode`, `FacultyName`, `FacultyType`, `DateOfBirth`, `Gender`, `Email`, `Address`, `Available`, `Salary`, `PhoneNumber`, `JoiningDate`, `SavedDate`) VALUES
(1, 'F01', 'Drona', 'Permenent', '1988-01-01', 'male', 'Drona2@gmail.com', 'Drona2@gmail.com', 'Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday', 60000, 9486113254, '2020-06-20', '2020-06-21 12:19:14'),
(2, 'F02', 'Parhasurana', 'Permenent', '2020-06-13', 'male', 'Parhasurana2@gmail.com', 'Tulu nadu', 'Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday', 90000, 9435795142, '2020-06-20', '2020-06-21 12:21:05'),
(3, 'F03', 'Bishma', 'Temporary', '1999-01-01', 'male', 'Bishma2@gmail.com', 'Faculty of Pandu', 'Tuesday,Wednesday,Thursday', 40000, 9481223344, '2020-06-16', '2020-06-21 12:23:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_facultyattendance`
--

CREATE TABLE `tbl_facultyattendance` (
  `KeyCode` int(50) NOT NULL,
  `FacultyKeyCode` int(50) NOT NULL,
  `CourseKeyCode` int(50) NOT NULL,
  `BatchKeyCode` int(50) NOT NULL,
  `TimeTableKeyCode` int(50) NOT NULL,
  `AttendanceDate` date NOT NULL,
  `Status` varchar(250) NOT NULL,
  `SavedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mark`
--

CREATE TABLE `tbl_mark` (
  `KeyCode` int(50) NOT NULL,
  `CourseKeyCode` int(50) NOT NULL,
  `BatchKeyCode` int(50) NOT NULL,
  `StudentKeyCode` int(50) NOT NULL,
  `SubjectKeyCode` int(50) NOT NULL,
  `Mark` int(11) NOT NULL,
  `SaveDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_mark`
--

INSERT INTO `tbl_mark` (`KeyCode`, `CourseKeyCode`, `BatchKeyCode`, `StudentKeyCode`, `SubjectKeyCode`, `Mark`, `SaveDate`) VALUES
(1, 2, 1, 2, 1, 50, '2020-08-16 11:39:16'),
(2, 1, 3, 5, 1, 50, '2020-08-16 11:41:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_qualification`
--

CREATE TABLE `tbl_qualification` (
  `KeyCode` int(50) NOT NULL,
  `Qualification` varchar(250) NOT NULL,
  `SavedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_qualification`
--

INSERT INTO `tbl_qualification` (`KeyCode`, `Qualification`, `SavedDate`) VALUES
(1, 'BCA', '2020-03-08 15:21:04'),
(2, 'MCA', '2020-03-08 15:37:14'),
(3, 'MCOM', '2020-03-08 17:01:53'),
(4, 'BBA', '2020-03-08 18:26:46');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recipt`
--

CREATE TABLE `tbl_recipt` (
  `KeyCode` int(50) NOT NULL,
  `StudentKeyCode` int(50) NOT NULL,
  `BatchKeyCode` int(50) NOT NULL,
  `PaidAmount` double NOT NULL,
  `BalanceAmount` double NOT NULL,
  `SaveDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `KeyCode` int(50) NOT NULL,
  `RegisterNo` varchar(250) NOT NULL,
  `StudentName` varchar(250) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Gender` varchar(250) NOT NULL,
  `PhoneNumber` bigint(20) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Address` text NOT NULL,
  `QualificationKeyCode` int(50) NOT NULL,
  `CourseType` varchar(100) NOT NULL,
  `CourseKeyCode` varchar(100) NOT NULL,
  `Fees` double NOT NULL,
  `JoinDate` date NOT NULL,
  `Balance` double NOT NULL DEFAULT '0',
  `Image` text NOT NULL,
  `SavedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`KeyCode`, `RegisterNo`, `StudentName`, `DateOfBirth`, `Gender`, `PhoneNumber`, `Email`, `Address`, `QualificationKeyCode`, `CourseType`, `CourseKeyCode`, `Fees`, `JoinDate`, `Balance`, `Image`, `SavedDate`) VALUES
(1, '101', 'Abhi', '2020-01-01', 'male', 9481671193, 'Abi2@gmail.com', 'aaaaaaa', 1, 'Shorterm', '3,5', 11000, '2020-02-01', 0, '', '2020-06-21 11:46:50'),
(2, '102', 'Rama', '1999-06-04', 'male', 94817821456, 'Rama2@gmail.com', 'RRRRRR', 2, 'Shorterm', '2,5', 11000, '2020-06-20', 0, '', '2020-06-21 11:48:50'),
(3, '104', 'Rajani', '2000-01-01', 'female', 9874563254, 'Rajani2@gmail.com', 'Rajani home', 3, 'Shorterm', '2,3,5', 16000, '2020-12-11', 0, '', '2020-06-21 11:51:08'),
(4, '105', 'Ravi', '1997-08-01', 'female', 9513578524, 'Ravi2@gmail.com', 'Ravi Home', 1, 'Shorterm', '2,3,5', 16000, '1998-12-01', 0, '', '2020-06-21 11:53:08'),
(5, '106', 'Nisha', '1998-01-01', 'female', 9481671112, 'Nisha2@gmail.com', 'Nisha Home', 1, 'Diploma', '1', 50000, '2020-12-01', 0, '', '2020-06-21 11:55:08'),
(6, '107', 'Arjuna', '1998-10-10', 'male', 9418671194, 'Arjuna2@gmail.com', 'Arjuna', 2, 'Diploma', '1', 50000, '2020-01-01', 0, '', '2020-06-21 11:57:42'),
(7, '108', 'Darmaraya', '1999-04-01', 'male', 9481672345, 'Darmaraya2@GMAIL.COM', 'Darmaraya Home', 1, 'Diploma', '4', 50000, '2020-06-27', 0, '', '2020-06-21 12:00:21'),
(8, '109', 'Bhima', '2000-05-01', 'male', 9481671165, 'Bhima2@gmail.com', 'Bhima Home', 4, 'Diploma', '4', 50000, '2020-06-20', 0, '', '2020-06-21 12:09:21'),
(9, '110', 'Nakula', '1988-01-01', 'male', 9481671115, 'Nakula2@gmail.com', 'Nakula Home', 4, 'Diploma', '6', 70000, '2020-06-14', 0, '', '2020-06-21 12:11:11'),
(10, '111', 'Sahadheva', '1988-09-09', 'male', 9481112229, 'Sahadheva2@gmail.com', 'Sahadheva Home', 4, 'Diploma', '6', 70000, '2020-06-20', 0, '', '2020-06-21 12:13:33'),
(11, '103', 'Karna', '1999-02-01', 'male', 9481777333, 'Karna2@gmail.com', 'Dana shura ', 4, 'Diploma', '6', 70000, '2020-06-19', 0, '', '2020-06-21 12:15:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_studentattendance`
--

CREATE TABLE `tbl_studentattendance` (
  `KeyCode` int(50) NOT NULL,
  `StudentKeyCode` int(50) NOT NULL,
  `CourseKeyCode` int(50) NOT NULL,
  `BatchKeyCode` int(50) NOT NULL,
  `SubjectKeyCode` int(25) NOT NULL,
  `TimeTableKeyCode` int(50) NOT NULL,
  `AttendanceDate` date NOT NULL,
  `Status` varchar(250) NOT NULL,
  `SavedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_studentattendance`
--

INSERT INTO `tbl_studentattendance` (`KeyCode`, `StudentKeyCode`, `CourseKeyCode`, `BatchKeyCode`, `SubjectKeyCode`, `TimeTableKeyCode`, `AttendanceDate`, `Status`, `SavedDate`) VALUES
(1, 2, 2, 1, 1, 2, '2020-08-02', 'Present', '2020-08-15 23:01:04'),
(2, 3, 2, 1, 1, 2, '2020-08-02', 'Present', '2020-08-15 23:01:04'),
(3, 4, 2, 1, 1, 2, '2020-08-02', 'Absent', '2020-08-15 23:01:05'),
(4, 2, 2, 1, 1, 2, '2020-08-09', 'Present', '2020-08-16 13:00:57'),
(5, 3, 2, 1, 1, 2, '2020-08-09', 'Present', '2020-08-16 13:00:57'),
(6, 4, 2, 1, 1, 2, '2020-08-09', 'Present', '2020-08-16 13:00:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subject`
--

CREATE TABLE `tbl_subject` (
  `KeyCode` int(50) NOT NULL,
  `SubjectCode` varchar(250) NOT NULL,
  `SubjectName` varchar(250) NOT NULL,
  `SavedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subject`
--

INSERT INTO `tbl_subject` (`KeyCode`, `SubjectCode`, `SubjectName`, `SavedDate`) VALUES
(1, 'SUB001', 'Java', '2020-03-07 20:21:07'),
(2, 'SUB002', 'c++', '2020-03-08 11:10:33'),
(4, 'SUB456', 'PHP', '2020-03-08 12:26:18'),
(6, 'SUB126', 'KANNADA', '2020-03-08 12:26:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_timetable`
--

CREATE TABLE `tbl_timetable` (
  `KeyCode` int(50) NOT NULL,
  `CourseKeyCode` int(50) NOT NULL,
  `BatchKeyCode` int(50) NOT NULL,
  `SubjectKeyCode` int(50) NOT NULL,
  `FacultyKeyCode` int(50) NOT NULL,
  `Day` varchar(100) NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL,
  `SavedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_timetable`
--

INSERT INTO `tbl_timetable` (`KeyCode`, `CourseKeyCode`, `BatchKeyCode`, `SubjectKeyCode`, `FacultyKeyCode`, `Day`, `StartTime`, `EndTime`, `SavedDate`) VALUES
(1, 1, 3, 1, 1, 'Sunday', '09:30:00', '11:30:00', '2020-06-21 06:58:52'),
(2, 2, 1, 1, 1, 'Sunday', '02:00:00', '03:00:00', '2020-06-21 07:08:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_assignstudent`
--
ALTER TABLE `tbl_assignstudent`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_batch`
--
ALTER TABLE `tbl_batch`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_faculty`
--
ALTER TABLE `tbl_faculty`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_facultyattendance`
--
ALTER TABLE `tbl_facultyattendance`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_mark`
--
ALTER TABLE `tbl_mark`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_qualification`
--
ALTER TABLE `tbl_qualification`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_recipt`
--
ALTER TABLE `tbl_recipt`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_studentattendance`
--
ALTER TABLE `tbl_studentattendance`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  ADD PRIMARY KEY (`KeyCode`);

--
-- Indexes for table `tbl_timetable`
--
ALTER TABLE `tbl_timetable`
  ADD PRIMARY KEY (`KeyCode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_assignstudent`
--
ALTER TABLE `tbl_assignstudent`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_batch`
--
ALTER TABLE `tbl_batch`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_course`
--
ALTER TABLE `tbl_course`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_faculty`
--
ALTER TABLE `tbl_faculty`
  MODIFY `KeyCode` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_facultyattendance`
--
ALTER TABLE `tbl_facultyattendance`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_mark`
--
ALTER TABLE `tbl_mark`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_qualification`
--
ALTER TABLE `tbl_qualification`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_recipt`
--
ALTER TABLE `tbl_recipt`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_studentattendance`
--
ALTER TABLE `tbl_studentattendance`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_timetable`
--
ALTER TABLE `tbl_timetable`
  MODIFY `KeyCode` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
