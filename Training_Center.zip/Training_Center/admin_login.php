<?php define('DIR', '');
require_once DIR . 'config.php';

$admin = new Admin();

if (isset($_POST['admin_login_btn'])) 
{
  $username = $_POST['username'];  
  $password = $_POST['password']; 

   if(strlen(trim($username))>1 && strlen(trim($password))>1){
      $res=$admin->loginAdmin($username,$password);
      if($res){
      	 $_SESSION['success_message'] = "Welcome to Dashboard..";
         $admin->redirect('admin/home');
      }else{
		    $_SESSION['error_message'] = "Invalid Username Password";
         $admin->redirect('index');
      }
   }
}

?>


     