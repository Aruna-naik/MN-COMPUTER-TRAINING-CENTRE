<?php


class Admin extends Main
{
	protected $id;

  	public function __construct()
	{
		if(isset( $_SESSION['admin']))
		{
	   		$this->id = $_SESSION['admin'];
		}
	   parent::__construct();
	}




		public function loginAdmin($username,$password)
		{
			try{
				$stmnt=$this->conn->prepare("select KeyCode from tbl_admin where  UserName=:username AND Password=:password");
				$stmnt->bindParam("username", $username,PDO::PARAM_STR) ;
				$stmnt->bindParam("password", $password,PDO::PARAM_STR) ;
				$stmnt->execute();
				$count=$stmnt->rowCount();
				$res=$stmnt->fetch(PDO::FETCH_ASSOC);
				$id = $res['KeyCode'];
				if($count){
					$_SESSION['admin']= $id;
					return true;
				}else{
					return false;
				}
	
			}catch(PDOException $e) {
				echo $e->getMessage();
				  return false;
			}
	
		}
	
	public function changeloginAdmin($npassword)
		{
			try{
				$stmnt = $this->conn->prepare("UPDATE tbl_admin SET Password=:npassword");
				$stmnt->bindparam(":npassword", $npassword);
				$stmnt->execute();
					return true;
				} catch (PDOException $e) {
					echo $e->getMessage();
					return false;
				}
			}


		// displaying all subject
		public function get_subject(){
			try {
				$stmt = $this->conn->prepare("SELECT * FROM `tbl_subject`");
				$stmt->execute();
				return $stmt;	
			} catch (PDOException $e) {
				echo $e->getMessage();
				return false;
			}
		}
	
		//student count for graph
		public function is_course_code_exist($course_code)
		{
			try {
				$stmt = $this->conn->prepare("SELECT * FROM `tbl_course` WHERE CourseCode='$course_code'" );
				$stmt->execute();
				$count=$stmt->rowCount();
				return $count;
			} catch (PDOException $e) {
				echo $e->getMessage();
				return -1;
			}
		}

		/*public function view_marks($SubjectKeyCode)
		{
			try {
				$stmt = $this->conn->prepare("SELECT * FROM `tbl_mark` WHERE `SubjectKeyCode` =$SubjectKeyCode");
				$stmt->execute();
				return $stmt;	
			} catch (PDOException $e) {
				echo $e->getMessage();
				return false;
			}
		}*/
			// inserting individualstudent
		public function add_course($course_code,$course_name,$course_type,$finalSubject,$duration,$course_fees){
			try {
				$stmt = $this->conn->prepare("INSERT INTO tbl_course(CourseCode,CourseName,CourseType,CourseDuration,Fees,SubjectKeyCode) VALUES(:course_code,:course_name,:course_type,:duration,:course_fees,:finalSubject)");
				$stmt->bindparam(":course_code", $course_code);
				$stmt->bindparam(":course_name", $course_name);
				$stmt->bindparam(":course_type", $course_type);
				$stmt->bindparam(":finalSubject", $finalSubject);
				$stmt->bindparam(":duration", $duration);
				$stmt->bindparam(":course_fees", $course_fees);
				
				$stmt->execute();
				return true;
			} catch (PDOException $e) {
				echo $e->getMessage();
				return $e->getMessage();;
			}
		}
	
	
		// displaying all student
		public function get_course(){
			try {
				$stmt = $this->conn->prepare("SELECT * FROM tbl_course ");
				$stmt->execute();
				return $stmt;	
			} catch (PDOException $e) {
				echo $e->getMessage();
				return false;
			}
		}
	
		public function delete_course($id)
		{
			try {
				$stmt=$this->conn->prepare("DELETE FROM `tbl_course` WHERE `tbl_course`.`KeyCode` = $id ");
				$stmt->execute();
				return true;
			}
			catch (PDOException $e) 
			{
				echo $e->getMessage();
				return false;
			}
			
		}
	
		// displaying all student
		public function get_subject_by_id($id){
			try {
				$stmt = $this->conn->prepare("SELECT SubjectName FROM tbl_subject WHERE KeyCode=$id ");
				$stmt->execute();
				return $stmt;	
			} catch (PDOException $e) {
				echo $e->getMessage();
				return false;
			}
		}
	
		public function getCourseID($id){
			try {
				$stmt = $this->conn->prepare("SELECT * FROM tbl_course WHERE KeyCode=:id");
				$stmt->execute(array(':id'=>$id));
				$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
				return $editRow;
			} catch (PDOException $e) {
				echo $e->getMessage();
				return false;
			}
		}

			//8/03/2020 starts
			public function edit_course($course_code,$course_name,$course_type,$finalSubject,$duration,$course_fees,$keycode){
				try {
					$stmt = $this->conn->prepare("UPDATE tbl_course SET CourseCode=:course_code,CourseName=:course_name,CourseType=:course_type,CourseDuration=:duration,Fees=:course_fees,SubjectKeyCode=:finalSubject WHERE KeyCode=:keycode");
					$stmt->bindparam(":course_code", $course_code);
					$stmt->bindparam(":course_name", $course_name);
					$stmt->bindparam(":course_type", $course_type);
					$stmt->bindparam(":finalSubject", $finalSubject);
					$stmt->bindparam(":duration", $duration);
					$stmt->bindparam(":course_fees", $course_fees);
					$stmt->bindparam(":keycode", $keycode);
				   
					$stmt->execute();
					return true;
				} catch (PDOException $e) {
					echo $e->getMessage();
					return false;
				}
			}

			public function is_course_code_exist_edit($course_code,$keycode)
				{
					try {
						$stmt = $this->conn->prepare("SELECT * FROM `tbl_course` WHERE CourseCode='$course_code' AND KeyCode <> $keycode" );
						$stmt->execute();
						$count=$stmt->rowCount();
						return $count;
					} catch (PDOException $e) {
						echo $e->getMessage();
						return -1;
					}
				}

				public function delete_batch_from_course($id)
					{
						try {
							$stmt=$this->conn->prepare("DELETE FROM `tbl_batch` WHERE CourseKeyCode = $id ");
							$stmt->execute();
							return true;
						}
						catch (PDOException $e) 
						{
							echo $e->getMessage();
							return false;
						}
						
					}

					public function add_qualification($qualification_name){
						try {
							$stmt = $this->conn->prepare("INSERT INTO tbl_qualification(Qualification) VALUES(:qualification_name)");
							$stmt->bindparam(":qualification_name", $qualification_name);
							
							
							$stmt->execute();
							return true;
						} catch (PDOException $e) {
							echo $e->getMessage();
							return $e->getMessage();;
						}
					}

					public function get_course_shorterm(){
						try {
							$stmt = $this->conn->prepare("SELECT * FROM tbl_course  WHERE CourseType='Shorterm'");
							$stmt->execute();
							return $stmt;	
						} catch (PDOException $e) {
							echo $e->getMessage();
							return false;
						}
					}

					public function get_course_diploma(){
						try {
							$stmt = $this->conn->prepare("SELECT * FROM tbl_course  WHERE CourseType='Diploma'");
							$stmt->execute();
							return $stmt;	
						} catch (PDOException $e) {
							echo $e->getMessage();
							return false;
						}
					}


					public function get_qualification(){
						try {
							$stmt = $this->conn->prepare("SELECT * FROM tbl_qualification");
							$stmt->execute();
							return $stmt;	
						} catch (PDOException $e) {
							echo $e->getMessage();
							return false;
						}
					}

					public function get_course_fee($keycode){
						try {
							$stmt = $this->conn->prepare("SELECT Fees from tbl_course  where KeyCode=$keycode");
							$stmt->execute();
							// $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
							return $stmt;
						} catch (PDOException $e) {
							echo $e->getMessage();
							return false;
						}
					}

					public function is_reg_no_exist($reg_no)
						{
							try {
								$stmt = $this->conn->prepare("SELECT * FROM `tbl_student` WHERE 	RegisterNo	='$reg_no' " );
								$stmt->execute();
								$count=$stmt->rowCount();
								return $count;
							} catch (PDOException $e) {
								echo $e->getMessage();
								return -1;
							}
						}

						public function add_student($reg_no,$std_name,$dob,$std_gender,$phone_no,$email,$address,$qualification,$finalCourse,$fees,$joindate,$course_type){
							try {
								$stmt = $this->conn->prepare("INSERT INTO tbl_student(RegisterNo,StudentName,DateOfBirth,Gender,PhoneNumber,Email,Address,QualificationKeyCode,	CourseKeyCode,	Fees,JoinDate,Balance,CourseType) VALUES(:reg_no,:std_name,:dob,:std_gender,:phone_no,:email,:address,:qualification,:finalCourse,:fees,:joindate,:fees1,:course_type)");
								$stmt->bindparam(":reg_no", $reg_no);
								$stmt->bindparam(":std_name", $std_name);
								$stmt->bindparam(":dob", $dob);
								$stmt->bindparam(":std_gender", $std_gender);
								$stmt->bindparam(":phone_no", $phone_no);
								$stmt->bindparam(":email", $email);
								$stmt->bindparam(":address", $address);
								$stmt->bindparam(":qualification", $qualification);
								$stmt->bindparam(":finalCourse", $finalCourse);
								$stmt->bindparam(":fees", $fees);
								$stmt->bindparam(":fees1", $fees);
								$stmt->bindparam(":joindate", $joindate);
								
								$stmt->bindparam(":course_type", $course_type);
								
								$stmt->execute();
								return true;
							} catch (PDOException $e) {
								echo $e->getMessage();
								return $e->getMessage();;
							}
						}

						public function get_student_H(){
							try {
								$stmt = $this->conn->prepare("SELECT *,(select Qualification FROM tbl_qualification WHERE KeyCode=QualificationKeyCode) AS QualificationName FROM tbl_student");
								$stmt->execute();
								return $stmt;	
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}

						public function get_course_by_id($id){
							try {
								$stmt = $this->conn->prepare("SELECT * FROM tbl_course WHERE KeyCode=$id ");
								$stmt->execute();
								return $stmt;	
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}


						public function get_course_by_id_new($id){
							try {
								$stmt = $this->conn->prepare("SELECT CourseName FROM tbl_course WHERE FIND_IN_SET(`KeyCode`,'$id')");
								$stmt->execute();
								return $stmt;	
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}


						public function delete_student_H($id)
						{
							try {
								$stmt=$this->conn->prepare("DELETE FROM `tbl_student` WHERE `KeyCode` = $id ");
								$stmt->execute();
								return true;
							}
							catch (PDOException $e) 
							{
								echo $e->getMessage();
								return false;
							}
							
						}

						public function getStudentID_H($id){
							try {
								$stmt = $this->conn->prepare("SELECT * FROM tbl_student WHERE KeyCode=:id");
								$stmt->execute(array(':id'=>$id));
								$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
								return $editRow;
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}

						public function is_reg_no_exist_edit($reg_no,$keycode)
						{
							try {
								$stmt = $this->conn->prepare("SELECT * FROM `tbl_student` WHERE RegisterNo='$reg_no' AND KeyCode <> $keycode " );
								$stmt->execute();
								$count=$stmt->rowCount();
								return $count;
							} catch (PDOException $e) {
								echo $e->getMessage();
								return -1;
							}
						}

						public function edit_student($reg_no,$std_name,$dob,$std_gender,$phone_no,$email,$address,$qualification,$finalCourse,$fees,$joindate,$course_type,$keycode){
							try {
								$stmt = $this->conn->prepare("UPDATE tbl_student SET RegisterNo=:reg_no,StudentName=:std_name,DateOfBirth=:dob,Gender=:std_gender,PhoneNumber=:phone_no,Email=:email,Address=:address,QualificationKeyCode=:qualification,CourseType=:course_type,CourseKeyCode=:finalCourse,Fees=:fees,JoinDate=:joindate WHERE KeyCode=:keycode");
								$stmt->bindparam(":reg_no", $reg_no);
								$stmt->bindparam(":std_name", $std_name);
								$stmt->bindparam(":dob", $dob);
								$stmt->bindparam(":std_gender", $std_gender);
								$stmt->bindparam(":phone_no", $phone_no);
								$stmt->bindparam(":email", $email);
								$stmt->bindparam(":address", $address);
								$stmt->bindparam(":qualification", $qualification);
								$stmt->bindparam(":finalCourse", $finalCourse);
								$stmt->bindparam(":fees", $fees);
								$stmt->bindparam(":joindate", $joindate);
								$stmt->bindparam(":course_type", $course_type);
								$stmt->bindparam(":keycode", $keycode);
							   
								$stmt->execute();
								return true;
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}



	
					

				
			//8/03/2020 starts

			// 9/09/2020 starts

			
		public function is_faculty_code_exist($faculty_code)
		{
			try {
				$stmt = $this->conn->prepare("SELECT * FROM `tbl_faculty` WHERE FacultyCode='$faculty_code' " );
				$stmt->execute();
				$count=$stmt->rowCount();
				return $count;
			} catch (PDOException $e) {
				echo $e->getMessage();
				return -1;
			}
		}
	
		public function add_faculty($faculty_code,$faculty_name,$dob,$faculty_gender,$phone_no,$email,$address,$salary,$select2_faculty,$faculty_type,$joindate)
		{
			try {
				$stmt = $this->conn->prepare("INSERT INTO tbl_faculty(FacultyCode,FacultyName,FacultyType,DateOfBirth,Gender,Email,Address,Available,Salary,PhoneNumber,JoiningDate) VALUES(:faculty_code,:faculty_name,:faculty_type,:dob,:faculty_gender,:email,:address1,:select2_faculty,:salary,:phone_no,:joindate)");
				$stmt->bindparam(":faculty_code", $faculty_code);
				$stmt->bindparam(":faculty_name", $faculty_name);
				$stmt->bindparam(":faculty_type", $faculty_type);
				$stmt->bindparam(":dob", $dob);
				$stmt->bindparam(":faculty_gender", $faculty_gender);
				$stmt->bindparam(":email", $email);
				$stmt->bindparam(":address1", $address);
				$stmt->bindparam(":select2_faculty", $select2_faculty);
				$stmt->bindparam(":salary", $salary);
				$stmt->bindparam(":phone_no", $phone_no);
				$stmt->bindparam(":joindate", $joindate);	
				$stmt->execute();
				return true;
			} catch (PDOException $e) {
				echo $e->getMessage();
				return $e->getMessage();;
			}
		}
			//9/03/2020 Ends


			//10/03/2020 Starts
			public function get_faculty_H()
			{
				try {
					$stmt = $this->conn->prepare("SELECT * FROM tbl_faculty");
					$stmt->execute();
					return $stmt;	
				} catch (PDOException $e) {
					echo $e->getMessage();
					return false;
				}
			}

			public function delete_faculty_id_H($id){
				try {
					$stmt = $this->conn->prepare("DELETE FROM `tbl_faculty` WHERE `KeyCode` = $id");
					$stmt->execute();
					return $stmt;	
				} catch (PDOException $e) {
					echo $e->getMessage();
					return false;
				}
			}

			public function getFacultyID_H($id){
				try {
					$stmt = $this->conn->prepare("SELECT * FROM tbl_faculty WHERE KeyCode=:id");
					$stmt->execute(array(':id'=>$id));
					$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
					return $editRow;
				} catch (PDOException $e) {
					echo $e->getMessage();
					return false;
				}
			}

			public function is_faculty_code_exist_edit($faculty_code,$keycode)
			{
				try {
					$stmt = $this->conn->prepare("SELECT * FROM `tbl_faculty` WHERE FacultyCode='$faculty_code' AND KeyCode <> $keycode" );
					$stmt->execute();
					$count=$stmt->rowCount();
					return $count;
				} catch (PDOException $e) {
					echo $e->getMessage();
					return -1;
				}
			}

			public function edit_faculty($faculty_code,$faculty_name,$dob,$faculty_gender,$phone_no,$email,$address,$salary,$select2_faculty,$faculty_type,$join_date,$keycode)
			{
				try {
					$stmt = $this->conn->prepare("UPDATE tbl_faculty SET FacultyCode=:faculty_code,	FacultyName=:faculty_name,FacultyType=:faculty_type,DateOfBirth=:dob,Gender=:faculty_gender,Email=:email,Address=:address,Available=:select2_faculty,Salary=:salary,PhoneNumber=:phone_no,JoiningDate=:join_date WHERE KeyCode=:keycode");
					$stmt->bindparam(":faculty_code", $faculty_code);
					$stmt->bindparam(":faculty_name", $faculty_name);
					$stmt->bindparam(":faculty_type", $faculty_type);
					$stmt->bindparam(":dob", $dob);
					$stmt->bindparam(":faculty_gender", $faculty_gender);
					$stmt->bindparam(":email", $email);
					$stmt->bindparam(":address", $address);
					$stmt->bindparam(":select2_faculty", $select2_faculty);
					$stmt->bindparam(":salary", $salary);
					$stmt->bindparam(":phone_no", $phone_no);
					$stmt->bindparam(":join_date", $join_date);
					$stmt->bindparam(":keycode", $keycode);
				   
					$stmt->execute();
					return true;
				} catch (PDOException $e) {
					echo $e->getMessage();
					return false;
				}
			}



			//10/03/2020 Ends 

			//11/03/2020 Starts
				

				// displaying all student
				public function get_subject_by_course($course){
					try {
						$stmt = $this->conn->prepare("SELECT SubjectKeyCode FROM tbl_course WHERE KeyCode=$course ");
						$stmt->execute();
						return $stmt;	
					} catch (PDOException $e) {
						echo $e->getMessage();
						return false;
					}
				}

			//11/03/2020 Ends

			//14/03/2020 Starts//
			// displaying all student
					public function get_faculty(){
						try {
							$stmt = $this->conn->prepare("SELECT * FROM tbl_faculty");
							$stmt->execute();
							return $stmt;	
						} catch (PDOException $e) {
							echo $e->getMessage();
							return false;
						}
					}
			//14/03/2020 Ends//get_faculty_by_course


					//15/03/2020/ starts

						public function get_faculty_days($faculty_selected){
						try {
							$stmt = $this->conn->prepare("SELECT Available FROM tbl_faculty WHERE KeyCode =$faculty_selected ");
							$stmt->execute();
							return $stmt;	
						} catch (PDOException $e) {
							echo $e->getMessage();
							return false;
						}
					}

					public function is_faculty_day_exists($faculty_select,$batch_select,$day_select)
					{
						try {
							$stmt = $this->conn->prepare("SELECT * FROM `tbl_timetable` WHERE FacultyKeyCode='$faculty_select' AND BatchKeyCode='$batch_select' AND Day='$day_select'" );
							$stmt->execute();
							
							return $stmt ;
						} catch (PDOException $e) {
							echo $e->getMessage();
							return -1;
						}
					}

					public function is_Batch_day_exists($faculty_select,$batch_select,$day_select)
					{
						try {
							$stmt = $this->conn->prepare("SELECT * FROM `tbl_timetable` WHERE  FacultyKeyCode='$faculty_select' and BatchKeyCode='$batch_select' AND Day='$day_select'" );
							$stmt->execute();
							
							return $stmt ;
						} catch (PDOException $e) {
							echo $e->getMessage();
							return -1;
						}
					}

					public function add_time_table($add_course,$batch_select,$subject_select,$faculty_select,$day_select,$start_time,$end_time)
						{
							try {
								$stmt = $this->conn->prepare("INSERT INTO `tbl_timetable`(`CourseKeyCode`, `BatchKeyCode`, `SubjectKeyCode`, `FacultyKeyCode`, `Day`, `StartTime`, `EndTime`) VALUES (:add_course,:batch_select,:subject_select,:faculty_select,:day_select,:start_time,:end_time)");
								$stmt->bindparam(":add_course", $add_course);
								$stmt->bindparam(":batch_select", $batch_select);
								$stmt->bindparam(":subject_select", $subject_select);
								$stmt->bindparam(":faculty_select", $faculty_select);
								$stmt->bindparam(":day_select", $day_select);
								$stmt->bindparam(":start_time", $start_time);
								$stmt->bindparam(":end_time", $end_time);	
								$stmt->execute();
								return true;
							} catch (PDOException $e) {
								echo $e->getMessage();
								return $e->getMessage();;
							}
						}

						public function get_all_time_table(){
							try {
								$stmt = $this->conn->prepare("SELECT *,(select CourseName FROM tbl_course WHERE KeyCode=CourseKeyCode) AS CourseName,(select BatchName FROM tbl_batch WHERE KeyCode=BatchKeyCode) AS BatchName,(select SubjectName  FROM tbl_subject WHERE KeyCode=SubjectKeyCode) AS SubjectName,(select FacultyName FROM tbl_faculty WHERE KeyCode=FacultyKeyCode) AS FacultyName FROM tbl_timetable ");
								$stmt->execute();
								return $stmt;	
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}

						public function delete_timetable_id_H($id){
							try {
								$stmt = $this->conn->prepare("DELETE FROM `tbl_timetable` WHERE `KeyCode` = $id");
								$stmt->execute();
								return $stmt;	
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}



					//15/03/2020 ends//

						//16/03/2020 starts
						

						public function is_faculty_day_exists_edit($faculty_select,$day_select,$KeyCode)
							{
								try {
									$stmt = $this->conn->prepare("SELECT * FROM `tbl_timetable` WHERE FacultyKeyCode='$faculty_select' AND Day='$day_select' AND KeyCode <> $KeyCode" );
									$stmt->execute();
									
									return $stmt ;
								} catch (PDOException $e) {
									echo $e->getMessage();
									return -1;
								}
							}

							public function is_Batch_day_exists_edit($batch_select,$day_select,$KeyCode)
								{
									try {
										$stmt = $this->conn->prepare("SELECT * FROM `tbl_timetable` WHERE  BatchKeyCode=$batch_select AND Day='$day_select' AND KeyCode <> $KeyCode" );
										$stmt->execute();
										
										return $stmt ;
									} catch (PDOException $e) {
										echo $e->getMessage();
										return -1;
									}
								}

								public function edit_time_table($CourseKeyCode,$BatchKeyCode,$SubjectKeyCode,$FacultyKeyCode,$day,$start_time,$end_time,$KeyCode)
								{
									try {
										$stmt = $this->conn->prepare("UPDATE tbl_timetable SET CourseKeyCode=:CourseKeyCode,BatchKeyCode=:BatchKeyCode,SubjectKeyCode=:SubjectKeyCode,FacultyKeyCode=:FacultyKeyCode,Day=:day,StartTime=:start_time,EndTime=:end_time WHERE KeyCode=:KeyCode");
										$stmt->bindparam(":CourseKeyCode", $CourseKeyCode);
										$stmt->bindparam(":BatchKeyCode", $BatchKeyCode);
										$stmt->bindparam(":SubjectKeyCode", $SubjectKeyCode);
										$stmt->bindparam(":FacultyKeyCode", $FacultyKeyCode);
										$stmt->bindparam(":day", $day);
										$stmt->bindparam(":start_time", $start_time);
										$stmt->bindparam(":end_time", $end_time);
										$stmt->bindparam(":KeyCode", $KeyCode);
									   
										$stmt->execute();
										return true;
									} catch (PDOException $e) {
										echo $e->getMessage();
										return false;
									}
								}

						//16/03/2020 ends


								//18/03/2020 starts

								public function StudentCount(){
									try {
										$stmt = $this->conn->prepare("SELECT COUNT(*) As StudentCount FROM tbl_student");
										$stmt->execute();
										$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
										return $editRow;
									} catch (PDOException $e) {
										echo $e->getMessage();
										return false;
									}
								}

								public function FacultyCount(){
									try {
										$stmt = $this->conn->prepare("SELECT COUNT(*) As FacultyCount FROM tbl_faculty");
										$stmt->execute();
										$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
										return $editRow;
									} catch (PDOException $e) {
										echo $e->getMessage();
										return false;
									}
								}

								public function CourseCount(){
									try {
										$stmt = $this->conn->prepare("SELECT COUNT(*) As CourseCount FROM tbl_course");
										$stmt->execute();
										$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
										return $editRow;
									} catch (PDOException $e) {
										echo $e->getMessage();
										return false;
									}
								}

								public function AluminiStudentCount(){
									try {
										$stmt = $this->conn->prepare("SELECT COUNT(*) As AluminiStudentCount FROM tbl_alumini");
										$stmt->execute();
										$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
										return $editRow;
									} catch (PDOException $e) {
										echo $e->getMessage();
										return false;
									}
								}


								//18/03/2020 Ends

								//20/03/2020 Starts
								public function get_marks_student_course_by_id($CourseKeyCode,$StudentKeyCode){
									try {
										$stmt = $this->conn->prepare("SELECT Mark,SubjectKeyCode,(SELECT SubjectName FROM tbl_subject WHERE KeyCode =SubjectKeyCode) AS SubjectName,(SELECT CourseName FROM tbl_course WHERE KeyCode =CourseKeyCode) AS CourseName FROM tbl_mark WHERE CourseKeyCode=$CourseKeyCode AND StudentKeyCode = $StudentKeyCode ");
										$stmt->execute();
										return $stmt;	
									} catch (PDOException $e) {
										echo $e->getMessage();
										return false;
									}
								}

								public function get_student_attendenceMar($CourseKeyCode,$StudentKeyCode,$sub){
									try {
										$stmt = $this->conn->prepare("SELECT Mark,SubjectKeyCode,(SELECT SubjectName FROM tbl_subject WHERE KeyCode =SubjectKeyCode) AS SubjectName,(SELECT CourseName FROM tbl_course WHERE KeyCode =CourseKeyCode) AS CourseName FROM tbl_mark WHERE CourseKeyCode=$CourseKeyCode AND StudentKeyCode = $StudentKeyCode AND SubjectKeyCode = $sub");
										$stmt->execute();
										return $stmt;	
									} catch (PDOException $e) {
										echo $e->getMessage();
										return false;
									}
								}


								//20/03/2020 Ends


	
		// //  CHANGES ENDS ///





	

	// starts//


	public function add_assignbatch($BatchName,$CourseKeyCode){
		try {
			$stmt = $this->conn->prepare("INSERT INTO tbl_batch(CourseKeyCode,BatchName) VALUES(:CourseKeyCode,:BatchName)");
			$stmt->bindparam(":CourseKeyCode", $CourseKeyCode);
			$stmt->bindparam(":BatchName", $BatchName);
			$stmt->execute();
			return true;
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	public function get_course_code($id){
		try {
			$stmt = $this->conn->prepare("SELECT * FROM tbl_course WHERE KeyCode=:id");
			$stmt->execute(array(':id'=>$id));
			$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
			return $editRow;
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}
	

	public function get_all_batch(){
		try {
			$stmt = $this->conn->prepare("select KeyCode,BatchName,(select CourseCode FROM tbl_course WHERE KeyCode = CourseKeyCode) AS CourseCode,(select CourseName FROM tbl_course WHERE KeyCode = CourseKeyCode) AS CourseName,(select KeyCode FROM tbl_course WHERE KeyCode = CourseKeyCode) AS CourseKeyCode FROM tbl_batch");
			
			$stmt->execute();
			return $stmt;	
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	public function delete_batch($id){
		$stmt=$this->conn->prepare("DELETE FROM tbl_batch WHERE KeyCode=:id");
		$stmt->bindparam(":id",$id);
		$stmt->execute();
		return true;
	}

	// 8/3/2020
	public function update_assignbatch($course,$batch,$id){
		try {
			$stmt = $this->conn->prepare("UPDATE tbl_batch SET CourseKeyCode=:course,BatchName=:batch where KeyCode=:id");
			$stmt->bindparam(":course", $course);
			$stmt->bindparam(":batch", $batch);
            $stmt->bindparam(":id", $id);
           
            $stmt->execute();
            return true;
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	
	public function get_course_batch($batch,$course){
		try {
			$stmnt=$this->conn->prepare("select KeyCode from tbl_batch where  BatchName=:batch AND 	CourseKeyCode=:course");
				$stmnt->bindParam("batch", $batch,PDO::PARAM_STR) ;
				$stmnt->bindParam("course", $course,PDO::PARAM_STR) ;
				$stmnt->execute();
				$count=$stmnt->rowCount();
				//$res=$stmnt->fetch(PDO::FETCH_ASSOC);
				//$id = $res['KeyCode'];
				if($count){
					return true;
				}else{
					return false;
				}
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}
//
	public function get_course_batch_KeyCode($course,$batch,$KeyCode){
		try {
			$stmnt=$this->conn->prepare("select * from tbl_batch where BatchName=:batch AND CourseKeyCode=:course");
				$stmnt->bindParam("batch", $batch,PDO::PARAM_STR);
				$stmnt->bindParam("course", $course,PDO::PARAM_STR) ;
				$stmnt->execute();
				$count=$stmnt->rowCount();
				$res=$stmnt->fetch(PDO::FETCH_ASSOC);
				$idk = $res['KeyCode'];
				if($count){
					if($idk==$KeyCode){
				 return false;

					 }else{
						return true;
					 }
					
				}else{
					return false;
				}
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	public function get_Batch_ID_S($course_key){
    try {
        $stmt = $this->conn->prepare("SELECT * FROM tbl_batch WHERE CourseKeyCode=:course");
        $stmt->execute(array(':course'=>$course_key));
        // $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
        return $stmt;
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
}
//LECT * FROM tbl_student WHERE CourseKeyCode LIKE CONCAT('%','3','%')
public function get_course_student_S($course){
    try {
        $stmt = $this->conn->prepare("SELECT * FROM tbl_student WHERE CourseKeyCode like ? AND Keycode NOT IN (select StudentKeyCode FROM tbl_assignstudent)");
		$stmt->execute(array("%".$course."%"));
        //$stmt->execute();
        // $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
        return $stmt;
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
}

public function add_student_batch($std_key,$course,$batch){
			try {
				$stmt = $this->conn->prepare("INSERT INTO tbl_assignstudent(StudentKeyCode,CourseKeyCode,BatchKeyCode) VALUES(:std_key,:course,:batch)");
				$stmt->bindparam(":std_key", $std_key);
				$stmt->bindparam(":course", $course);
				$stmt->bindparam(":batch", $batch);
				$stmt->execute();
				return true;
			} catch (PDOException $e) {
				echo $e->getMessage();
				return $e->getMessage();;
			}
		}

public function get_student_batch(){
		try {
			$stmt = $this->conn->prepare("select KeyCode,(select CourseCode FROM tbl_course WHERE KeyCode = CourseKeyCode) AS CourseCode,(select CourseName FROM tbl_course WHERE KeyCode = CourseKeyCode) AS CourseName,CourseKeyCode,StudentKeyCode,BatchKeyCode,(select StudentName FROM tbl_student WHERE KeyCode = StudentKeyCode) AS StudentName,(select RegisterNo FROM tbl_student WHERE KeyCode = StudentKeyCode) AS RegisterNo,(select BatchName FROM tbl_batch WHERE KeyCode = BatchKeyCode) AS BatchName FROM tbl_assignstudent WHERE tbl_assignstudent.StudentKeyCode=(SELECT KeyCode FROM tbl_student WHERE tbl_student.KeyCode=tbl_assignstudent.StudentKeyCode)");
			
			$stmt->execute();
			return $stmt;	
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}
	

	public function delete_batch_student($id){
		$stmt=$this->conn->prepare("DELETE FROM tbl_assignstudent WHERE KeyCode=:id");
		$stmt->bindparam(":id",$id);
		$stmt->execute();
		return true;
	}

//end  2020/8/


	//final  starts///

					// 2020/9

	public function get_id_assignstudent($s_id,$course_id){

		try {
			$stmnt=$this->conn->prepare("select * from tbl_assignstudent where StudentKeyCode=:s_id AND 	CourseKeyCode=:course_id");
				$stmnt->bindParam("s_id", $s_id,PDO::PARAM_STR) ;
				$stmnt->bindParam("course_id", $course_id,PDO::PARAM_STR) ;
				$stmnt->execute();
				$count=$stmnt->rowCount();
				//$res=$stmnt->fetch(PDO::FETCH_ASSOC);
				//$id = $res['KeyCode'];
				/*if($count){
					return true;
				}else{
					return false;
				}*/
				return $count;
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}



	//2020/9
	//2020/15
	//update_assignbatchStudent
	public function update_assignbatchStudent($CourseKeyCode,$BatchName,$StudentKeyCode,$KeyCode){
		try {
			$stmt = $this->conn->prepare("UPDATE tbl_assignstudent SET CourseKeyCode=:course,BatchKeyCode=:BatchName,StudentKeyCode=:StudentKeyCode where KeyCode=:id");
			$stmt->bindparam(":course", $CourseKeyCode);
			$stmt->bindparam(":BatchName", $BatchName);
			$stmt->bindparam(":StudentKeyCode", $StudentKeyCode);
            $stmt->bindparam(":id", $KeyCode);
           
            $stmt->execute();
            return true;
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	public function get_Batch_ID_TIME($day,$BatchKeyCode,$SubjectCode,$Adate){
    try {
        $stmt = $this->conn->prepare("SELECT *,TIME_FORMAT(StartTime,'%H:%i')  AS ST,TIME_FORMAT(EndTime,'%H:%i')  AS ET FROM tbl_timetable WHERE BatchKeyCode=:BatchKeyCode AND Day=:Day AND SubjectKeyCode=:SubjectCode AND KeyCode NOT IN (SELECT  TimeTableKeyCode FROM tbl_studentattendance WHERE AttendanceDate=:Adate) ");
        $stmt->bindparam(":BatchKeyCode", $BatchKeyCode);
        $stmt->bindparam(":Day", $day);
        $stmt->bindparam(":SubjectCode", $SubjectCode);
         $stmt->bindparam(":Adate", $Adate);
           
            $stmt->execute();
        //$stmt->execute(array(':BatchKeyCode'=>$BatchKeyCode));
        // $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
        return $stmt;
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
}

	public function get_student_assign($batch){
		try {
			$stmt = $this->conn->prepare("SELECT *,(SELECT StudentName FROM tbl_student WHERE KeyCode = `StudentKeyCode`) AS StudentName,(SELECT RegisterNo FROM tbl_student WHERE KeyCode = `StudentKeyCode`) AS RegisterNo FROM `tbl_assignstudent` WHERE BatchKeyCode =:batch");
			$stmt->bindparam(":batch", $batch);
			$stmt->execute();
			return $stmt;	
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	public function put_attendance($std_key,$status,$course,$batch,$subject,$time,$attendancedate_at){
			try {
				$stmt = $this->conn->prepare("INSERT INTO tbl_studentattendance(StudentKeyCode,CourseKeyCode,BatchKeyCode,SubjectKeyCode,TimeTableKeyCode,AttendanceDate,	Status) VALUES(:std_key,:course,:batch,:subject,:time1,:attendancedate_at,:status)");
				$stmt->bindparam(":std_key", $std_key);
				$stmt->bindparam(":course", $course);
				$stmt->bindparam(":batch", $batch);
				$stmt->bindparam(":subject", $subject);
				$stmt->bindparam(":time1", $time);
				$stmt->bindparam(":attendancedate_at", $attendancedate_at);
				$stmt->bindparam(":status", $status);
				$stmt->execute();
				return true;
			} catch (PDOException $e) {
				echo $e->getMessage();
				return $e->getMessage();;
			}
		}

	//2020/15

		// 2020/16
		public function get_sub_name_S($sub_key){
	try {
		$stmt = $this->conn->prepare("SELECT * from tbl_subject where KeyCode=:subject");
		$stmt->execute(array(':subject'=>$sub_key));

		 $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}
		//end sachith 2020/16

//start sachith 2020/18
	public function get_student_attendence($batch,$student,$subject){
	try {
		$stmt = $this->conn->prepare("SELECT StudentKeyCode,SUM(CASE WHEN (Status ='Present') THEN 1 ELSE 0 END) AS PresentCount,SUM(CASE WHEN (Status ='Absent') THEN 1 ELSE 0 END) AS AbsentCount,(SELECT StudentName FROM tbl_student WHERE KeyCode=`StudentKeyCode`) AS StudentName,(SELECT RegisterNo FROM tbl_student WHERE KeyCode=StudentKeyCode)AS RegisterNo FROM `tbl_studentattendance` WHERE BatchKeyCode=:batch and SubjectKeyCode=:subject  AND StudentKeyCode=:student GROUP BY `StudentKeyCode` ");
		//$stmt->execute(array(':subject'=>$sub_key));
		$stmt->bindparam(":batch", $batch);
		$stmt->bindparam(":subject", $subject);
		$stmt->bindparam(":student", $student);
		$stmt->execute();
		 $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

public function get_student_attendencePRO($student,$StudentKeyCode){
	try {
		$stmt = $this->conn->prepare("SELECT StudentKeyCode,SUM(CASE WHEN (Status ='Present') THEN 1 ELSE 0 END) AS PresentCount,SUM(CASE WHEN (Status ='Absent') THEN 1 ELSE 0 END) AS AbsentCount,(SELECT StudentName FROM tbl_student WHERE KeyCode=`StudentKeyCode`) AS StudentName,(SELECT RegisterNo FROM tbl_student WHERE KeyCode=StudentKeyCode)AS RegisterNo FROM `tbl_studentattendance` WHERE  SubjectKeyCode=:subject  AND StudentKeyCode=:student GROUP BY `StudentKeyCode` ");
		//$stmt->execute(array(':subject'=>$sub_key));
		//$stmt->bindparam(":batch", $batch);
		$stmt->bindparam(":subject", $StudentKeyCode);
		$stmt->bindparam(":student", $student);
		$stmt->execute();
		 $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

public function get_Batch_ID_TIME_EDIT($day,$BatchKeyCode,$SubjectCode,$Adate){
    try {
        $stmt = $this->conn->prepare("SELECT *,TIME_FORMAT(StartTime,'%H:%i')  AS ST,TIME_FORMAT(EndTime,'%H:%i')  AS ET FROM tbl_timetable WHERE BatchKeyCode=:BatchKeyCode AND Day=:Day AND SubjectKeyCode=:SubjectCode AND KeyCode IN (SELECT  TimeTableKeyCode FROM tbl_studentattendance WHERE AttendanceDate=:Adate) ");
        $stmt->bindparam(":BatchKeyCode", $BatchKeyCode);
        $stmt->bindparam(":Day", $day);
        $stmt->bindparam(":SubjectCode", $SubjectCode);
         $stmt->bindparam(":Adate", $Adate);
           
            $stmt->execute();
        //$stmt->execute(array(':BatchKeyCode'=>$BatchKeyCode));
        // $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
        return $stmt;
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
}

public function get_coursebatch($id){
		try {
			$stmt = $this->conn->prepare("SELECT * FROM tbl_batch WHERE KeyCode=:id");
			$stmt->execute(array(':id'=>$id));
			$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
			return $editRow;
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	public function get_course_time_id_S($id){
		try {
			$stmt = $this->conn->prepare("SELECT *,TIME_FORMAT(StartTime,'%H:%i')  AS ST,TIME_FORMAT(EndTime,'%H:%i')  AS ET FROM tbl_timetable WHERE KeyCode=:id");
			$stmt->execute(array(':id'=>$id));
			$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
			return $editRow;
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	/*SELECT *,(SELECT StudentName FROM tbl_student WHERE KeyCode=StudentKeyCode) As StudentName,(SELECT RegisterNo FROM tbl_student WHERE KeyCode=StudentKeyCode) As RegisterNo FROM `tbl_studentattendance` WHERE `CourseKeyCode`='6' AND `BatchKeyCode`='11' AND `SubjectKeyCode`='5' AND `AttendanceDate`='2020-03-15' AND `TimeTableKeyCode`='1'*/
	public function get_student_attendence_ById($BatchCode,$SubjectCode,$Adate,$Atime){
    try {
        $stmt = $this->conn->prepare("SELECT *,(SELECT StudentName FROM tbl_student WHERE KeyCode=StudentKeyCode) As StudentName,(SELECT RegisterNo FROM tbl_student WHERE KeyCode=StudentKeyCode) As RegisterNo FROM `tbl_studentattendance` WHERE  BatchKeyCode=:BatchCode AND SubjectKeyCode=:SubjectCode AND AttendanceDate=:Adate AND TimeTableKeyCode=:Atime");
        $stmt->bindparam(":BatchCode", $BatchCode);
        $stmt->bindparam(":SubjectCode", $SubjectCode);
        $stmt->bindparam(":Adate", $Adate);
         $stmt->bindparam(":Atime", $Atime);
           
            $stmt->execute();
        //$stmt->execute(array(':BatchKeyCode'=>$BatchKeyCode));
        // $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
        return $stmt;
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
}

	public function edit_StudentAttendance($key,$stause_name){
	try {
		$stmt = $this->conn->prepare("UPDATE tbl_studentattendance set Status=:stause_name where KeyCode=:key");
		$stmt->bindparam(":stause_name", $stause_name);
		$stmt->bindparam(":key", $key);
		$stmt->execute();
		return true;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}


//end sachith 2020/18

	//Final sachith Ends//

	// Sachith Ends//


	//vinod starts/////////////////////////////////////////////
	
// checking if subject already exist
public function check_subject($sub_code){
	try {
		$stmt = $this->conn->prepare("SELECT * from tbl_subject where SubjectCode=:sub_code");
		$stmt->bindParam("sub_code", $sub_code,PDO::PARAM_STR) ;
		$stmt->execute();
		$count=$stmt->rowCount();
		return $count;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return -1;
	}
}

// inserting subjects
public function add_subject($sub_code,$sub_name){
	try {
		$stmt = $this->conn->prepare("INSERT INTO tbl_subject(SubjectCode,SubjectName) VALUES(:sub_code,:sub_name)");
		$stmt->bindparam(":sub_code", $sub_code);
		$stmt->bindparam(":sub_name", $sub_name);
		$stmt->execute();
		return true;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// displaying all subject
public function delete_sub($sub_key){
	$stmt=$this->conn->prepare("DELETE FROM tbl_subject WHERE KeyCode=:Keycode");
		$stmt->bindparam(":Keycode",$sub_key);
		$stmt->execute();
		return true;
}

//get subject info for edit
public function get_subjectID($sub_key){
	try {
		$stmt = $this->conn->prepare("SELECT * FROM tbl_subject WHERE KeyCode=:Keycode");
		$stmt->execute(array(':Keycode'=>$sub_key));
		$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// updating subjects
public function edit_subject($sub_code,$sub_name,$key){
	try {
		$stmt = $this->conn->prepare("UPDATE tbl_subject set SubjectCode=:sub_code,SubjectName=:sub_name where KeyCode=$key");
		$stmt->bindparam(":sub_code", $sub_code);
		$stmt->bindparam(":sub_name", $sub_name);
		$stmt->execute();
		return true;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

/// 08/03/2020///vinod//////////////

//get batch info based on course
public function get_batchID($course_key){
	try {
		$stmt = $this->conn->prepare("SELECT * FROM tbl_batch WHERE CourseKeyCode=:course");
		$stmt->execute(array(':course'=>$course_key));
		// $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

//get student info based on batch
public function get_student_ID($batch_key){
	try {
		$stmt = $this->conn->prepare("SELECT tbl_student.StudentName,tbl_student.KeyCode from tbl_assignstudent INNER JOIN tbl_student on tbl_student.KeyCode=tbl_assignstudent.StudentKeyCode where tbl_assignstudent.BatchKeyCode=:batch");
		$stmt->execute(array(':batch'=>$batch_key));
		// $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

//get subject info based on student
public function get_corse_ID($student_key){
	try {
		$stmt = $this->conn->prepare("SELECT CourseKeyCode from tbl_student INNER JOIN tbl_course on tbl_course.KeyCode=tbl_student.CourseKeyCode where tbl_student.KeyCode=:student");
		$stmt->execute(array(':student'=>$student_key));
		$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

//get student info based on batch
public function get_sub_ID($course_key){
	try {
		$stmt = $this->conn->prepare("SELECT * from tbl_course where KeyCode=:subject");
		$stmt->execute(array(':subject'=>$course_key));
		// $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

//get subject name based on subject keycode
public function get_sub_name($sub_key){
	try {
		$stmt = $this->conn->prepare("SELECT * from tbl_subject where KeyCode=:subject");
		$stmt->execute(array(':subject'=>$sub_key));
		// $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// checking if subject and student already exist
public function check_mark($student,$subject){
	try {
		$stmt = $this->conn->prepare("SELECT * from tbl_mark where StudentKeyCode=:std_code and SubjectKeyCode=:sub_code");
		$stmt->bindParam("std_code", $student,PDO::PARAM_STR) ;
		$stmt->bindParam("sub_code", $subject,PDO::PARAM_STR) ;
		$stmt->execute();
		$count=$stmt->rowCount();
		return $count;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return -1;
	}
}

// inserting subjects
public function add_mark($course,$batch,$student,$subject,$mark){
	try {
		$stmt = $this->conn->prepare("INSERT INTO tbl_mark(CourseKeyCode,BatchKeyCode,StudentKeyCode,SubjectKeyCode,Mark) VALUES(:course,:batch,:student,:subject,:mark)");
		$stmt->bindparam(":course", $course);
		$stmt->bindparam(":batch", $batch);
		$stmt->bindparam(":student", $student);
		$stmt->bindparam(":subject", $subject);
		$stmt->bindparam(":mark", $mark);
		$stmt->execute();
		//echo $stmt;
		return true;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// displaying all mark details
public function get_mark(){
	try {
		$stmt = $this->conn->prepare("SELECT tbl_mark.KeyCode,tbl_course.CourseName,tbl_batch.BatchName,tbl_student.StudentName,tbl_subject.SubjectName,tbl_mark.Mark from tbl_mark INNER JOIN tbl_course on tbl_course.KeyCode=tbl_mark.CourseKeyCode INNER JOIN tbl_batch on tbl_batch.KeyCode=tbl_mark.BatchKeyCode INNER JOIN tbl_student on tbl_student.KeyCode=tbl_mark.StudentKeyCode INNER JOIN tbl_subject on tbl_subject.KeyCode=tbl_mark.SubjectKeyCode");
		$stmt->execute();
		return $stmt;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// displaying all subject
public function delete_mark($mark_key){
	$stmt=$this->conn->prepare("DELETE FROM tbl_mark WHERE KeyCode=:Keycode");
		$stmt->bindparam(":Keycode",$mark_key);
		$stmt->execute();
		return true;
}

// displaying all mark details based on keycode
public function get_allMarks($mark_keycode){
	try {
		$stmt = $this->conn->prepare("SELECT * FROM tbl_mark WHERE KeyCode=:key");
		$stmt->execute(array(':key'=>$mark_keycode));
		$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}


// updating subjects
public function edit_mark($course1,$batch1,$student1,$subject1,$mark1,$m_key){
	try {
		$stmt = $this->conn->prepare("UPDATE tbl_mark set CourseKeyCode=:course,BatchKeyCode=:batch,StudentKeyCode=:student,SubjectKeyCode=:subject,Mark=:mark where KeyCode=$m_key");
		$stmt->bindparam(":course", $course1);
		$stmt->bindparam(":batch", $batch1);
		$stmt->bindparam(":student", $student1);
		$stmt->bindparam(":subject", $subject1);
		$stmt->bindparam(":mark", $mark1);
		$stmt->execute();
		return true;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// get feess based on student keycode
public function get_studentDetail($std_keycode){
	try {
		$stmt = $this->conn->prepare("SELECT Fees FROM tbl_student WHERE KeyCode=:key");
		$stmt->execute(array(':key'=>$std_keycode));
		$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

///// 08/03/2020///vinod   ends//////////////

///Vinod Final Starts///

		////09/03/2020////vinod/////////



// get the balance based on paid amount
public function get_balance($std_key){
	try {
		$stmt = $this->conn->prepare("SELECT Fees,Balance FROM tbl_student WHERE KeyCode=:key");
		$stmt->execute(array(':key'=>$std_key));
		$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// checking if subject and student already exist
public function check_balance($student){
	try {
		$stmt = $this->conn->prepare("SELECT Balance from tbl_student where KeyCode=:std_key");
		$stmt->execute(array(':std_key'=>$student));
		$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return -1;
	}
}

// inserting fees
public function pay_fees($batch_id,$student_id,$paid_amt,$balance_amt,$status){
	try {
		$stmt = $this->conn->prepare("INSERT INTO tbl_recipt(BatchKeyCode,StudentKeyCode,PaidAmount,BalanceAmount) VALUES(:batch,:student,:paid,:balance)");
		
		$stmt->bindparam(":batch", $batch_id);
		$stmt->bindparam(":student", $student_id);
		$stmt->bindparam(":paid", $paid_amt);
		$stmt->bindparam(":balance", $balance_amt);
		$stmt->execute();
		$stmt1 = $this->conn->prepare("UPDATE tbl_student SET Balance=:balance_amt WHERE KeyCode=:keycode");
					$stmt1->bindparam(":balance_amt", $balance_amt);
					$stmt1->bindparam(":keycode", $student_id);
				   
					$stmt1->execute();
		/*$stmt1 = $this->conn->prepare("UPDATE tbl_student set Balance=:balance_amt where KeyCode=$student");
		$stmt1->bindparam(":balance_amt", $balance_amt);
		$stmt1->execute();*/
		//echo $stmt;
		return true;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// displaying payment details
public function get_payment(){
	try {
		$stmt = $this->conn->prepare("SELECT tbl_recipt.KeyCode,tbl_student.StudentName,tbl_batch.BatchName,PaidAmount,BalanceAmount,StudentKeyCode from tbl_recipt INNER JOIN tbl_student on tbl_student.KeyCode=tbl_recipt.StudentKeyCode INNER JOIN tbl_batch on tbl_batch.KeyCode=tbl_recipt.BatchKeyCode");
		$stmt->execute();
		return $stmt;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// displaying Student details
public function get_student_dtl($std){
	try {
		$stmt = $this->conn->prepare("SELECT RegisterNo,PhoneNumber,CourseKeyCode,tbl_course.CourseName from tbl_student LEFT OUTER JOIN tbl_course on tbl_course.KeyCode=tbl_student.CourseKeyCode WHERE tbl_student.KeyCode=$std");
		$stmt->execute();
		return $stmt;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}


public function get_stu_name_cor($cor_key){
	try {
		$stmt = $this->conn->prepare("SELECT * FROM `tbl_course` WHERE `KeyCode` IN ($cor_key)");
		//$stmt->execute(array(':cor_key'=>$cor_key));
		//$stmt->bindparam(":cor_key", $cor_key);
		 $stmt->execute();
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}
public function get_stu_name_sub($cor_key){
	try {
		$stmt = $this->conn->prepare("SELECT * FROM `tbl_subject` WHERE `KeyCode` IN ($cor_key)");
		//$stmt->execute(array(':cor_key'=>$cor_key));
		//$stmt->bindparam(":cor_key", $cor_key);
		 $stmt->execute();
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

public function get_stu_name_sub_mar($cor_key,$stu){
	try {
		$stmt = $this->conn->prepare("SELECT *,(SELECT Mark FROM tbl_mark WHERE tbl_mark.SubjectKeyCode=tbl_subject.KeyCode AND tbl_mark.StudentKeyCode=:stu)as mark FROM `tbl_subject` WHERE `KeyCode` IN ($cor_key)");
		$stmt->bindparam(":stu", $stu);
		//$stmt->execute(array(':cor_key'=>$cor_key));
		//$stmt->bindparam(":cor_key", $cor_key);
		 $stmt->execute();
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}
public function get_faculty_code($stu){
	try {
		$stmt = $this->conn->prepare("SELECT * FROM `tbl_faculty` WHERE KeyCode=:stu ");
		$stmt->bindparam(":stu", $stu);
		//$stmt->execute(array(':cor_key'=>$cor_key));
		//$stmt->bindparam(":cor_key", $cor_key);
		 $stmt->execute();
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

public function check_faculty_attendance($faculty_KeyCode,$faculty_dat){
	try {
		$stmt = $this->conn->prepare("SELECT * from tbl_facultyattendance where FacultyKeyCode=:faculty_KeyCode and AttendanceDate=:faculty_dat");
		$stmt->bindParam("faculty_KeyCode", $faculty_KeyCode);
		$stmt->bindParam("faculty_dat", $faculty_dat);
		$stmt->execute();
		$count=$stmt->rowCount();
		return $count;	
	} catch (PDOException $e) {
		echo $e->getMessage();
		return -1;
	}
}


public function add_faculty_attendance($faculty_KeyCode,$faculty_dat,$attendance_status){
	try {
		$stmt = $this->conn->prepare("INSERT INTO tbl_facultyattendance(FacultyKeyCode,AttendanceDate,Status) VALUES(:faculty_KeyCode,:faculty_dat,:attendance_status)");
		$stmt->bindparam(":faculty_KeyCode", $faculty_KeyCode);
		$stmt->bindparam(":faculty_dat", $faculty_dat);
		$stmt->bindparam(":attendance_status", $attendance_status);
		$stmt->execute();
		return true;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

public function get_facultyname_att(){
try {
	$stmt = $this->conn->prepare("SELECT *,(SELECT FacultyCode FROM tbl_faculty WHERE tbl_faculty.KeyCode=tbl_facultyattendance.FacultyKeyCode) as FacultyCode,(SELECT Keycode FROM tbl_faculty WHERE tbl_faculty.KeyCode=tbl_facultyattendance.FacultyKeyCode) as FacultyKeycode FROM tbl_facultyattendance GROUP BY `FacultyKeyCode`");
	$stmt->execute();
	return $stmt;	
	} catch (PDOException $e) {
	echo $e->getMessage();
		return false;
	}
}
public function get_faculty_getdate($stu){
try {
		$stmt = $this->conn->prepare("SELECT * FROM `tbl_facultyattendance` WHERE FacultyKeyCode=:stu ");
		$stmt->bindparam(":stu", $stu);
		//$stmt->execute(array(':cor_key'=>$cor_key));
		//$stmt->bindparam(":cor_key", $cor_key);
		 $stmt->execute();
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

public function get_faculty_code_st($stu){
try {
		$stmt = $this->conn->prepare("SELECT * FROM `tbl_facultyattendance` WHERE KeyCode=:stu ");
		$stmt->bindparam(":stu", $stu);
		//$stmt->execute(array(':cor_key'=>$cor_key));
		//$stmt->bindparam(":cor_key", $cor_key);
		 $stmt->execute();
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

// updating subjects
public function edit_fac_Att($edit_faculty_status,$key){
	try {
		$stmt = $this->conn->prepare("UPDATE tbl_facultyattendance set Status=:Status where KeyCode=$key");
		$stmt->bindparam(":Status", $edit_faculty_status);
		
		$stmt->execute();
		return true;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

public function get_faculty_attendance(){
try {
		$stmt = $this->conn->prepare("SELECT SUM(CASE WHEN (Status ='present') THEN 1 ELSE 0 END) AS PresentCount,SUM(CASE WHEN (Status ='absent') THEN 1 ELSE 0 END) AS AbsentCount,COUNT(*) AS Handled,(select FacultyName From tbl_faculty WHERE tbl_faculty.KeyCode=tbl_facultyattendance.FacultyKeyCode) as FacultyName,FacultyKeyCode,(SELECT FacultyCode FROM tbl_faculty WHERE tbl_faculty.KeyCode=tbl_facultyattendance.FacultyKeyCode) AS FacultyCode FROM `tbl_facultyattendance`  GROUP BY `FacultyKeyCode`");
		//$stmt->execute(array(':cor_key'=>$cor_key));
		//$stmt->bindparam(":cor_key", $cor_key);
		 $stmt->execute();
		return $stmt;
	} catch (PDOException $e) {
		echo $e->getMessage();
		return false;
	}
}

public function add_alumini($reg_no,$std_name,$dob,$std_gender,$phone_no,$email,$address,$qualification,$finalCourse,$fees,$joindate,$course_type,$marks,$grade,$avg){
							try {
								$stmt = $this->conn->prepare("INSERT INTO tbl_alumini(RegisterNo,StudentName,DateOfBirth,Gender,PhoneNo,Email,Address,Qualification,CourseName,Fees,Marks,Grade,JoinDate,CourseType,Avg) VALUES(:reg_no,:std_name,:dob,:std_gender,:phone_no,:email,:address,:qualification,:finalCourse,:fees,:marks,:grade,:joindate,:course_type,:avg)");
								$stmt->bindparam(":reg_no", $reg_no);
								$stmt->bindparam(":std_name", $std_name);
								$stmt->bindparam(":dob", $dob);
								$stmt->bindparam(":std_gender", $std_gender);
								$stmt->bindparam(":phone_no", $phone_no);
								$stmt->bindparam(":email", $email);
								$stmt->bindparam(":address", $address);
								$stmt->bindparam(":qualification", $qualification);
								$stmt->bindparam(":finalCourse", $finalCourse);
								$stmt->bindparam(":fees", $fees);
								$stmt->bindparam(":marks", $marks);
								$stmt->bindparam(":grade", $grade);
								$stmt->bindparam(":joindate", $joindate);
								
								$stmt->bindparam(":course_type", $course_type);
								$stmt->bindparam(":avg", $avg);
								
								$stmt->execute();
								return true;
							} catch (PDOException $e) {
								echo $e->getMessage();
								return $e->getMessage();;
							}
						}

public function getStudentID_Alumini($id){
  try {
	$stmt = $this->conn->prepare("SELECT *,(select Qualification from tbl_qualification where tbl_qualification.KeyCode=tbl_student.QualificationKeyCode) as Qualification FROM tbl_student WHERE KeyCode=:id");
	$stmt->execute(array(':id'=>$id));
	$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
	return $editRow;
	} catch (PDOException $e) {
	echo $e->getMessage();
	return false;
		}
	}

public function get_alumini(){
							try {
								$stmt = $this->conn->prepare("SELECT * FROM tbl_alumini");
								$stmt->execute();
								return $stmt;	
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}

		public function delete_alumini($id)
						{
							try {
								$stmt=$this->conn->prepare("DELETE FROM `tbl_alumini` WHERE `KeyCode` = $id ");
								$stmt->execute();
								return true;
							}
							catch (PDOException $e) 
							{
								echo $e->getMessage();
								return false;
							}
							
						}
public function get_student_H_class($cursscode){
							try {
								$stmt = $this->conn->prepare("SELECT *,(select Qualification FROM tbl_qualification WHERE KeyCode=QualificationKeyCode) AS QualificationName FROM tbl_student WHERE FIND_IN_SET('$cursscode',`CourseKeyCode`)");
								$stmt->execute();
								return $stmt;	
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}
	public function get_student_markaddalu($stu_key,$subkeu){
								try {
									$stmt = $this->conn->prepare("SELECT *,(SELECT Mark FROM tbl_mark WHERE tbl_mark.SubjectKeyCode=tbl_subject.KeyCode and tbl_mark.StudentKeyCode='$stu_key') as markes FROM `tbl_subject` WHERE FIND_IN_SET(`KeyCode`,'$subkeu')");
									$stmt->execute();
									return $stmt;	
								} catch (PDOException $e) {
									echo $e->getMessage();
									return false;
								}
							}


public function get_batch_student_count($batchkeycode)
		{
			try {
				$stmt = $this->conn->prepare("SELECT * FROM `tbl_assignstudent` WHERE BatchKeyCode='$batchkeycode'" );
				$stmt->execute();
				$count=$stmt->rowCount();
				return $count;
			} catch (PDOException $e) {
				echo $e->getMessage();
				return -1;
			}
		}
		public function countstudentbach($bath_code,$studencode)
		{
			try {
				$stmt = $this->conn->prepare("SELECT * FROM `tbl_assignstudent` WHERE BatchKeyCode='$bath_code' AND StudentKeyCode <> $studencode" );
				$stmt->execute();
				$count=$stmt->rowCount();
				return $count;
			} catch (PDOException $e) {
				echo $e->getMessage();
				return -1;
			}
		}

		public function get_feesdetails(){
							try {
								$stmt = $this->conn->prepare("SELECT * FROM tbl_student where Balance!='null'");
								$stmt->execute();
								return $stmt;	
							} catch (PDOException $e) {
								echo $e->getMessage();
								return false;
							}
						}
	
////09/03/2020///////////




// final Ends//////

//end vinod/////////////////////////////



}