<?php
/**
 * Created by PhpStorm.
 * User: your name
 * Date: todays date
 * Time: todays time
 */

class Controller extends Main
{
    public function forgot($pno){
		try {
			
			$stmt = $this->conn->prepare("SELECT * FROM tbl_admin where PhoneNumber='$pno'");
			$stmt->execute();
			$editRow = $stmt->fetch(PDO::FETCH_ASSOC);
			
			return $editRow;	
		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

}