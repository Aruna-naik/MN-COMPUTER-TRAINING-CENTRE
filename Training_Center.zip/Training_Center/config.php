<?php
/**
 
 * User: 
 * Date: todays date
 * Time: todays time
 */

ob_start();
session_start();
//=========== database connection variables ====================
define('DB_SERVER', "localhost"); // database host name eg. localhost or 127.0.0.1
define('DB_USER', "root"); // database user name eg. root
define('DB_DATABASE', "mnct"); //database name
define('DB_PASSWORD', ""); //database user password
define('DB_TYPE', 'mysql'); //database drive eg. mysql, pgsql, mongodb etc




//========== site details described here ========================
define('SITE_TITLE', 'MNTC');
define('SITE_TAG_LINE', 'We Provide best Education to oyr beloved Students..');

//contact ifnormation
define('SITE_CONTACT', '');
//email information
define('SITE_EMAIL_INFO', '');
//url information
define('BASE_URL', 'http://localhost/Training_Center/');

// included main class
require_once 'app/Main.php';

/**
 * @param $class
 */
function __autoload($class) {
    require_once 'app/' . $class.'.php';
}