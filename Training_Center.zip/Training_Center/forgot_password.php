<?php define('DIR', '');
require_once DIR . 'config.php';


$control =new Controller();

//recover password---
if (isset($_POST['Reset'])) 
{
  $ResetPhone = $_POST['ResetPhone'];  
 // $pno=$_POST['pno'];
  
  
      $res=$control->forgot($ResetPhone);
      $pass=$res['Password'];

     if($pass != ''){
         require('textlocal.class.php');

			$textlocal = new Textlocal('sachithkulal2@gmail.com', 'Sachith108');

			$numbers = array($ResetPhone);
			$sender = 'TXTLCL';
			$message = 'Phone number matched!! Your password is ' .$pass;

			try {
             $result = $textlocal->sendSms($numbers, $message, $sender);
             $_SESSION['success_message'] = "Successfully Reset ! Plz Check Message";
			} catch (Exception $e) {
            $_SESSION['success_message'] = $e->getMessage();
            
             
			}
      	
         echo"
			<script>
			window.location='index.php';
			</script>
         ";
         
      }else{
         
		    $_SESSION['error_message'] ='Error While Sending Message! Please Check Phone NO / Internet Connection';
          echo"
          <script>
          window.location='index.php';
          </script>
          ";
      }
     
   
}

?>


     