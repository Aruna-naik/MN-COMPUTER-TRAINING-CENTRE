<?php define('DIR', '');
require_once DIR . 'config.php';

$admin = new Admin();

if (isset($_POST['add'])) 
{  
  $npassword = $_POST['npassword']; 

   if(strlen(trim($npassword))>1){
      $res=$admin->changeloginAdmin($npassword);
      if($res){
      	 $_SESSION['success_message'] = "Password Changed";
         $admin->redirect('index');
      }else{
		    $_SESSION['error_message'] = "Invalid Username Password";
         $admin->redirect('index');
      }
   }
}

?>
